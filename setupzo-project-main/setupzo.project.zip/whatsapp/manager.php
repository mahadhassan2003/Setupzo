<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manager Visa Services | Setupzo</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
      * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 90vh;
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .content-section {
         width: 90%;
      margin: auto;
    }
    .content-section h1{
      text-align:center ;
      color: #1E2355;
    } 
    .FAQS h1{
       text-align:center ;
      color: #1E2355;
    }

    .FAQS h5{
      color: black; 
    }
    .FAQS{
       width: 80%;
      margin: auto;
      padding: 20px;
      background-color: #ffffff; 
    }
    .FAQS p{
      padding-left: 20px;
    }
    
  </style>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:;font-family: 'Times New Roman', Times, serif;">

<?php include_once("navbar.php") ?>
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Manager Visa">
  </div>

<div class="col-lg-10 col-md-10 col-sm-12 mx-auto py-5" style=" background-color:#FBFBFB;">
    <h1 class="text-center text-decoration-underline"><b>MANAGER VISA SERVICES</b></h1>
  <h4 class="text-center mb-4">Comprehensive Manager Visa Solutions for UAE Businesses</h4>
<p>Secure your company's leadership in the UAE with our expert Manager Visa processing - ensuring compliance and smooth onboarding for your management team</p>
 <a href="manager_visa_page.php" class="btn btn-primary py-2 my-2" style="background-color: #1e2355;">Apply Online</a>
  
  <h2 class=" mt-5 mb-3">Benefits of Manager Visa in UAE</h2>
  <ul class=" mb-5">
    <li><h5>Legal Authorization:</h5> Full legal right to manage and operate your UAE company</li>
    <li><h5>Long-Term Residency:</h5> Typically issued for 2-3 years matching your company's license</li>
    <li><h5>Family Sponsorship:</h5> Ability to sponsor family members after meeting salary requirements</li>
    <li><h5>Banking Access:</h5> Open corporate and personal bank accounts in the UAE</li>
    <li><h5>Business Travel:</h5> Multiple entry privileges for business travel</li>
    <li><h5>Career Stability:</h5> Secure your executive position in the UAE market</li>
    <li><h5>Tax Advantages:</h5> Benefit from UAE's tax-free personal income policies</li>
    <li><h5>Pathway to Golden Visa:</h5> Potential eligibility for long-term residency programs</li>
  </ul>

  <h2 class="text mt-5 mb-3">Manager Visa Eligibility Requirements</h2>
  <ul class=" mb-5">
    <li><strong>Company Sponsorship:</strong> Must be employed by a UAE-registered company</li>
    <li><strong>Position Requirement:</strong> Must hold an approved managerial position</li>
    <li><strong>Educational Qualifications:</strong> Minimum bachelor's degree or equivalent experience</li>
    <li><strong>Salary Threshold:</strong> Minimum AED 15,000 monthly salary (varies by emirate)</li>
    <li><strong>Company Documents:</strong> Valid trade license and establishment card</li>
    <li><strong>Health Insurance:</strong> Mandatory health coverage as per UAE law</li>
  </ul>

  <h2 class="text-center mt-5 mb-3">Manager Visa Application Process</h2>
  <ol>
    <h5><li>Company Sponsorship Approval</h5>
    <p>Company applies for quota approval and prepares employment contract</p></li>
    
    <h5><li>Entry Permit Application</h5>
    <p>Submit manager's documents for entry permit processing</p></li>
    
    <h5><li>Medical Testing</h5>
    <p>Complete mandatory medical tests in UAE</p></li>
    
    <h5><li>Visa Stamping</h5>
    <p>Final visa stamping in passport</p></li>
    
    <h5><li>Emirates ID Registration</h5>
    <p>Biometric registration for national ID card</p></li>
  </ol>

  <h2 class="text-center mt-5 mb-3">Frequently Asked Questions</h2>
  <div class="accordion" id="accordionExample">
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
          What's the difference between Manager Visa and Employment Visa?
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse show">
        <div class="accordion-body">
          Manager Visa is specifically for executives and senior managers, often with higher salary requirements but providing greater authority to act on behalf of the company.
        </div>
      </div>
    </div>
    <!-- Additional FAQ items here -->
  </div>
</div>

<?php include_once("footer.php") ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>