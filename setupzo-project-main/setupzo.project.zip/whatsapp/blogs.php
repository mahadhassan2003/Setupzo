<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="icon" type="image/png" href="img/ahmer-setupzoo-again.png" />
      <link rel="icon" href="img/ahmer-setupzoo-again.png" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/ahmer-setupzoo-again.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/ahmer-setupzoo-again.png">
  <link rel="apple-touch-icon" sizes="180x180" href="img/ahmer-setupzoo-again.png">
  <link rel="manifest" href="img/ahmer-setupzoo-again.png">
    <title>All Blog Posts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
    /*    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@300;400;600&display=swap');*/

    /*    body {*/
    /*        font-family: 'Times New Roman', sans-serif;*/
    /*    }*/

    /*    .heading {*/
    /*        font-family: 'Playfair Display', serif;*/
    /*    }*/

    /*    .card {*/
    /*        transition: all 0.3s ease-in-out;*/
    /*    }*/

    /*    .card:hover {*/
    /*        transform: translateY(-5px);*/
    /*        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);*/
    /*    }*/
    /*     .navbar {*/
    /*  background: rgba(255, 255, 255, 0.3);*/
    /*  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);*/
    /*  backdrop-filter: blur(5.2px);*/
    /*  -webkit-backdrop-filter: blur(5.2px);*/
    /*}*/

    /*.nav-link {*/
    /*  color: #1e2355 !important;*/
    /*  font-weight: bold !important;*/
    /*}*/

    /*.mega-dropdown {*/
    /*  width: 100vw;*/
    /*  left: 0;*/
    /*  top: 100%;*/
    /*  position: absolute;*/
    /*  background: #fff;*/
    /*  padding: 30px;*/
    /*  display: none;*/
    /*  z-index: 9999;*/
    /*  box-shadow: 0 8px 20px rgba(0,0,0,0.1);*/
    /*  animation: fadeInDown 0.3s ease-in-out;*/
    /*}*/

    /*.mega-dropdown .dropdown-item {*/
    /*  font-weight: 500;*/
    /*  color: #1e2355;*/
    /*  transition: 0.3s;*/
    /*  white-space: nowrap;*/
    /*}*/

    /*.mega-dropdown .dropdown-item:hover {*/
    /*  background-color: #1e2355;*/
    /*  color: white;*/
    /*  padding-left: 10px;*/
    /*}*/

    /*.mega-dropdown h6 {*/
    /*  margin-bottom: 12px;*/
    /*  font-size: 14px;*/
    /*  color: #1e2355;*/
    /*  border-bottom: 1px solid #eee;*/
    /*  padding-bottom: 6px;*/
    /*}*/

    /*@keyframes fadeInDown {*/
    /*  from {*/
    /*    opacity: 0;*/
    /*    transform: translateY(-10px);*/
    /*  }*/
    /*  to {*/
    /*    opacity: 1;*/
    /*    transform: translateY(0px);*/
    /*  }*/
    /*}*/

    /*@media (max-width: 991px) {*/
    /*  .mega-dropdown {*/
    /*    display: none !important;*/
    /*    overflow-x: auto !important;*/
    /*    white-space: nowrap !important;*/
    /*    padding: 15px;*/
    /*  }*/

    /*  .mega-dropdown.show {*/
    /*    display: block !important;*/
    /*  }*/

    /*  .mega-dropdown .row {*/
    /*    display: flex !important;*/
    /*    flex-wrap: nowrap !important;*/
    /*  }*/

    /*  .mega-dropdown .col-md-2 {*/
    /*    flex: 0 0 auto !important;*/
    /*    width: 250px !important;*/
    /*    display: inline-block;*/
    /*    white-space: normal;*/
    /*    margin-right: 20px;*/
    /*  }*/
    /*}*/
    </style>
</head>
<body>
    <?php include_once('navbar.php');
    ?>
 <!-- Navbar -->
<!--<nav class="navbar navbar-expand-lg fixed-top">-->
<!--  <div class="container">-->
<!--    <a class="navbar-brand" href="index.php">-->
<!--      <img src="img/ahmer-setupzoo-again.png" width="100" alt="logo">-->
<!--    </a>-->
<!--    <button class="navbar-toggler me-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">-->
<!--      <i class="fa-solid fa-bars" style="color: #1e2355; font-size: 30px;"></i>-->
<!--    </button>-->
<!--    <div class="collapse navbar-collapse" id="navbarNav">-->
<!--      <ul class="navbar-nav mx-auto">-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="business-setup-dubai" style="color: #1e2355;"><p style="color: #1e2355">Home</p></a>-->
<!--        </li>-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="aboutus.php">About Us</a>-->
<!--        </li>-->
<!--        <li class="nav-item dropdown px-2 position-static">-->
<!--          <a class="nav-link dropdown-toggle" href="services.php" id="servicesDropdown"  style="color: #1e2355;">Services</a>-->
<!--          <button class="btn btn-sm btn-outline-primary d-lg-none my-2" id="toggleMegaMenu">-->
<!--            Show Services-->
<!--          </button>-->

<!--          <div class="dropdown-menu mega-dropdown" id="megaMenu">-->
<!--            <div class="row">-->
<!--              <div class="col-md-2">-->
<!--                <h6>Company Formation</h6>-->
<!--                <a class="dropdown-item" href="start-mainland-company-in-uae">Mainland</a>-->
<!--                <a class="dropdown-item" href="free-zone-company-uae">Free Zone</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Visa & Immigration</h6>-->
<!--                <a class="dropdown-item" href="uae-residence-visa">Residence Visa</a>-->
<!--                <a class="dropdown-item" href="uae-golden-visa">Golden Visa</a>-->
<!--                <a class="dropdown-item" href="services-freelance-visa-uae-dubai">Freelance Visa</a>-->
<!--                <a class="dropdown-item" href="bank_account_open.php">Bank Account Opening</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Financial Services</h6>-->
<!--                <a class="dropdown-item" href="payroll_page.php">Payroll</a>-->
<!--                <a class="dropdown-item" href="vat_service.php">Corporate Tax & VAT</a>-->
<!--                <a class="dropdown-item" href="compilance.php">Compliance</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Legal Services</h6>-->
<!--                <a class="dropdown-item" href="pro-services-dubai">PRO Services</a>-->
<!--                <a class="dropdown-item" href="will-preparation-uae">Will Preparation</a>-->
<!--                <a class="dropdown-item" href="trademark-vs-copyright-uae">Trademark & Copyright</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Additional Services</h6>-->
<!--                <a class="dropdown-item" href="health_insurance.php">Health Insurance</a>-->
<!--                <a class="dropdown-item" href="police_clearance.php">Police Clearance</a>-->
<!--                <a class="dropdown-item" href="dm_page.php">DM Approval</a>-->
<!--                <a class="dropdown-item" href="emirates_page.php">Emirates ID Update</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Nominee Services</h6>-->
<!--                <a class="dropdown-item" href="contactus.php">Shareholder</a>-->
<!--                <a class="dropdown-item" href="contactus.php">Manager</a>-->
<!--              </div>-->
<!--            </div>-->
<!--          </div>-->
<!--        </li>-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="blogs.php">Blog</a>-->
<!--        </li>-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="contactus.php">Contact</a>-->
<!--        </li>-->
<!--      </ul>-->
<!--      <a href="contactus.php" class="btn text-white py-2 px-3 ms-lg-4" style="background-color: #1e2355;">Apply Now</a>-->
<!--    </div>-->
<!--  </div>-->
<!--</nav>-->
<!-- Image Section -->
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Full Cover Image">
  </div>
    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-16 mb-12">
        <div class="max-w-6xl mx-auto px-4 text-center">
            <h1 class="heading text-5xl font-bold mb-4">Discover Stories & Ideas</h1>
            <p class="text-lg opacity-90">Explore insights, tips, and personal journeys shared by our community.</p>
        </div>
    </section>

    <!-- Search Bar -->
    <section class="max-w-4xl mx-auto px-4 mb-10">
        <form method="GET" class="flex items-center shadow-sm rounded-lg overflow-hidden bg-white">
            <input type="text" name="search" placeholder="Search blog posts..." class="w-full px-4 py-3 outline-none text-gray-700">
            <button type="submit" class="px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold">Search</button>
        </form>
    </section>

    <!-- Blog Cards -->
    <main class="max-w-6xl mx-auto px-4">
        <div class="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <?php
            // DB connection
      $servername = "localhost"; // Hostinger pe usually localhost
$username = "u259563098_setupzo"; // Aapka MySQL user
$password = "Setupzo123"; // Jo password aapne MySQL user banate waqt diya
$dbname = "u259563098_setupzo"; // Aapka database name

            try {
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
                $blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if (count($blogs) === 0) {
                    echo "<p class='text-center text-gray-500 text-lg col-span-full'>No blog posts found.</p>";
                } else {
                    foreach ($blogs as $blog) {
                        echo '<div class="card bg-white rounded-lg p-6 shadow-sm my-5">';
                        echo '<h2 class="text-xl font-semibold text-indigo-700 mb-2">' . htmlspecialchars($blog['title']) . '</h2>';
                        echo '<p class="text-gray-600 text-sm mb-1">By ' . htmlspecialchars($blog['author']) . ' • ' . date("F j, Y", strtotime($blog['created_at'])) . '</p>';
                        echo '<p class="text-gray-700 mb-3 text-sm"><strong>Category:</strong> ' . htmlspecialchars($blog['category']) . '</p>';
                        echo '<p class="text-gray-800 mb-4 text-sm leading-relaxed">' . nl2br(substr(htmlspecialchars($blog['content']), 0, 200)) . '...</p>';
                        if (!empty($blog['tags'])) {
                            echo '<p class="text-xs text-gray-500"><strong>Tags:</strong> ' . htmlspecialchars($blog['tags']) . '</p>';
                        }
                        echo '</div>';
                    }
                }

            } catch (PDOException $e) {
                echo "<div class='text-red-600 text-center'>Error: " . $e->getMessage() . "</div>";
            }

            $conn = null;
            ?>
        </div>
        <section class="bg-light py-5 mt-5">
  <div class="container text-center">
    <blockquote class="blockquote">
      <p class="mb-4 fs-4 fst-italic">“Blogs are the heartbeat of digital storytelling.”</p>
      <footer class="blockquote-footer">Setupzo Team</footer>
    </blockquote>
  </div>
</section>
    </main>

    <!-- Footer -->
     <?php  include_once("footer.php") ?>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
     <script>
  document.addEventListener("DOMContentLoaded", function () {
    const dropdown = document.querySelector('.nav-item.dropdown');
    const megaMenu = document.getElementById('megaMenu');
    const toggleButton = document.getElementById('toggleMegaMenu');

    // Toggle mega menu on mobile
    if (window.innerWidth < 992 && toggleButton && megaMenu) {
      toggleButton.addEventListener('click', function (e) {
        e.preventDefault();
        megaMenu.classList.toggle('show');
        toggleButton.textContent = megaMenu.classList.contains('show') ? 'Hide Services' : 'Show Services';
      });
    }

    // Hover effect for desktop
    if (window.innerWidth >= 992 && dropdown && megaMenu) {
      let timer;
      dropdown.addEventListener('mouseenter', () => {
        clearTimeout(timer);
        megaMenu.style.display = 'block';
      });
      dropdown.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });
      megaMenu.addEventListener('mouseenter', () => {
        clearTimeout(timer);
      });
      megaMenu.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });
    }
  });
</script>
</body>
</html>
