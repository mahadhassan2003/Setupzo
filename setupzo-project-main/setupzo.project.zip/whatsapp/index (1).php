<!---->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="description" content="Setupzo provides expert business setup in Dubai, UAE – mainland & free zone company formation, registration, and licensing with speed and transparency.">
<meta name="keywords" content="UAE Business Setup, Company Formation Dubai, Visa Services UAE, Legal Support">
<meta name="author" content="Setup Zo">
<meta property="og:title" content="Start Your UAE Business Journey | Setup Zo">
<meta property="og:description" content="Get legal licenses, visa support, company formation, and more.">
<meta property="og:image" content="img/ahmer-setupzoo-again.png">
  <title>Business Setup in Dubai, UAE – Setupzo </title>
    <meta name="description" content="Setupzo provides expert business setup in Dubai, UAE – mainland & free zone company formation, registration, and licensing with speed and transparency.">
    <!-- Canonical Tag -->
  <link rel="canonical" href="https://setupzo.com/" />
  <!--xml tag-->
  <?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

  <!-- Homepage -->
  <url>
    <loc>https://setupzo.com/</loc>
    <lastmod>2025-09-21</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- css file link -->
    <link rel="stylesheet" href="css.css">
    <!-- bootstrap css cdn -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
     <!--bootstrap java cdn -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
    <!-- css file link -->
    <link rel="stylesheet" href="css.css">
    <!-- fontawsome cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- AOS animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- google font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playball&display=swap" rel="stylesheet">
    <!-- google icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=location_on" />
    <!-- jquery slide cdn -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>


    <!-- Cube Portfolio CSS -->
<link rel="stylesheet" href="path-to-your-assets/cubeportfolio/css/cubeportfolio.min.css">

<!-- jQuery Library -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script>

<!-- Cube Portfolio JS -->
<script src="path-to-your-assets/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.css" />
   
    <!-- ✅ Favicon Logo -->
  <!--<link rel="icon" type="image/png" href="img/ahmer-setupzoo-again.png" />-->
  
<link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96" />Business Setup in Dubai, UAE – Setupzo
<link rel="icon" type="image/svg+xml" href="img/favicon.svg" />
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png" />
<link rel="manifest" href="img/site.webmanifest" />

  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"/>
  <!-- Swiper Testimonial Slider Start -->
<link
  rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
   
   <style>
    .navbar{
       /*background: white !important;*/
  background: rgba(255, 255, 255, 0)  !important;
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(5.2px);
  -webkit-backdrop-filter: blur(5.2px);
  }
   
   .container1{
       background-image: url('img/hero.jpg');
       background-attachment: fixed;
       background-size: cover;
       background-repeat: no-repeat;
       background-position: center;
   }

    .container3{
      background-image:url('img/bgimg2.jpg')
    }
    .container5{
      background-image:url('img/freezone.png')
    }
    #submitBtn.loading {
  position: relative;
  pointer-events: none;
  opacity: 0.7;
}

#submitBtn.loading::after {
  content: "";
  position: absolute;
  top: 50%;
  right: 10px;
  width: 16px;
  height: 16px;
  border: 2px solid #fff;
  border-top-color: transparent;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
#phone{
    width: 280px;
}
    .nav-link {
      color: #1e2355 !important;
      font-weight: bold !important;
    }
     .mega-dropdown {
      width: 100vw;
      left: 0;
      top: 100%;
      position: absolute;
      background: #fff;
      padding: 30px;
      display: none;
      z-index: 9999;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      animation: fadeInDown 0.3s ease-in-out;
    }

    .mega-dropdown .dropdown-item {
      font-weight: 500;
      color: #1e2355;
      transition: 0.3s;
      white-space: nowrap;
    }

    .mega-dropdown .dropdown-item:hover {
      background-color: #1e2355;
      color: white;
      padding-left: 10px;
    }

    .mega-dropdown h6 {
      margin-bottom: 12px;
      font-size: 14px;
      color: #1e2355;
      border-bottom: 1px solid #eee;
      padding-bottom: 6px;
    }

    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0px);
      }
    }
.w-90 {
      width: 90%;
    }
    h2 {
        text-align: justify;
        font-size: 20px;
        
    }
    h5 {
         text-align: justify;
         font-size: 15px;
    }
    
    
     .w-90 {
      width: 90%;
    }
    .card {
      border:5px solid:block;
      border-radius: 15px;
      overflow: hidden;
      transition: transform 0.3s, box-shadow 0.3s;
    }
    .card:hover {
      transform: translateY(-8px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    
    /* Utility for 90% width */
    .w-91 {
      width: 90%;
      margin-inline: auto;
    }

    /* Uniform image sizing for cards */
    .card2-img-top {
      height: 220px;            /* Change if needed */
      object-fit: cover;        /* Makes all images uniform */
      width: 100%;
      display: block;
    }

    /* Card styling with soft shadow */
    .card2 {
      border: 0;
      border-radius: 1rem;
      box-shadow: 0 6px 20px rgba(0,0,0,.08);
      transition: transform .2s ease, box-shadow .2s ease;
    }
    /*.card2-p {*/
    /*    text-align: center;*/
      
    }
        .w-90 {
      width: 90%;
      margin: 0 auto;
    }

    /* Uniform card image size */
    .card-img-top {
      height: 240px; /* Increased height */
      object-fit: cover;
      width: 100%;
    }

    /* Card design */
    .card {
      border: 0;
      border-radius: 1rem;
      box-shadow: 0 6px 18px rgba(0,0,0,.08);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    /*.card:hover {*/
    /*  transform: translateY(-4px);*/
    /*  box-shadow: 0 12px 28px rgba(0,0,0,.15);*/
    }

    /* Card content spacing */
    .card-body {
      padding: 1.5rem; /* More inner spacing */
    }

    /* Card title styling */
    .card-title {
      font-weight: 600;
      font-size: 1.25rem;
      margin-bottom: 0.75rem;
      /*color: #2c3e50;*/
    }

    .card-text {
      font-size: 0.95rem;
      color: #555;
      margin-bottom: 1rem;
    }
    
     .custom-card {
      border: 2pxdashed blue ;
      border-radius: 20px;
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      background: #ffffff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .custom-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }
    .custom-card-body {
      padding: 25px;
      text-align: center;
    }
    .custom-card-title {
      font-size: 1.5rem;
      font-weight: bold;
      color: #1e2355;
      margin-bottom: 10px;
    }
    .custom-card-text {
      font-size: 1rem;
      color: #555;
    }
    
   .accordion {
    width: 90%;
    margin: auto;
    background:white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}
.accordion-item {
    border-bottom: 1px solid #ddd;
}
.accordion-header {
    background:#1e2355 ;
    color: white;
    padding: 15px 20px;
    cursor: pointer;
    position: relative;
    font-weight: bold;
    transition: background 0.3s;
}
.accordion-header:hover {
    background: gray;
}
.accordion-header::after {
    content: '▶';
    position: absolute;
    right: 20px;
    font-size: 18px;
    transition: transform 0.3s;
}
.accordion-header.active::after {
    transform: rotate(90deg);
}
.accordion-header.active {
    background: white;        
    color: #1e2355;           
    border-bottom: 1px solid #1e2355;  
}

.accordion-body {
    display: none;
    padding: 15px 20px;
    background: white;
    color: #333;
    animation: fadeIn 0.3s ease-in-out;
}
.accordion-body.show {
    display: block;
}
@keyframes fadeIn {
    from {opacity: 0;}
    to {opacity: 1;}
}
    
    /* ✅ Responsive Mobile Scroll CSS */
    @media (max-width: 991px) {
      .mega-dropdown {
        display: none !important; /* hide by default */
        overflow-x: auto !important;
        white-space: nowrap !important;
        padding: 15px;
      }

      .mega-dropdown.show {
        display: block !important; /* show when toggled */
      }

      .mega-dropdown .row {
        display: flex !important;
        flex-wrap: nowrap !important;
      }

      .mega-dropdown .col-md-2 {
        flex: 0 0 auto !important;
        width: 250px !important;
        display: inline-block;
        white-space: normal;
        margin-right: 20px;
      }
    }
    .card-hover {
      transition: all 0.4s ease;
    }
     .card-hover:hover {
      transform: translateY(-10px);
      box-shadow: 0 0 30px rgba(0, 0, 0, 0.15);
    }
    .swiper {
      padding-bottom: 50px;
    }
    @media (max-width: 768px) {
      .testimonial-img {
        width: 70px;
        height: 70px;
      }
    }
    
  </style>
</head>
<body>
    <!-- navbar -->
   
    <nav class="navbar navbar-expand-lg fixed-top">
  <div class="container">
    <a class="navbar-brand" href=".">
      <img src="img/ahmer-setupzoo-again.png" width="100" alt="Setupzo">
    </a>
    <button class="navbar-toggler me-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <i class="fa-solid fa-bars" style="color: #1e2355; font-size: 30px;"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item px-2">
          <a class="nav-link" href=".">Home</a>
        </li>
        <li class="nav-item px-2">
          <a class="nav-link" href="about-us.php">About Us</a>
        </li>
        <li class="nav-item dropdown px-2 position-static">
          <a class="nav-link dropdown-toggle" href="services.php" id="servicesDropdown">Services</a>

          <!-- 🔘 Toggle Button for Mobile -->
          <button class="btn btn-sm btn-outline-primary d-lg-none my-2" id="toggleMegaMenu">
            Show Services
          </button>

          <!-- Mega Dropdown Menu -->
          <div class="dropdown-menu mega-dropdown" id="megaMenu">
            <div class="row">
              <div class="col-md-2">
                <h6>Company Formation</h6>
                <a class="dropdown-item" href="mainland-business-setup-in-dubai.php">Mainland</a>
                <a class="dropdown-item" href="business-setup-in-dubai-freezone.php">Free Zone</a>
              </div>
              <div class="col-md-2">
                <h6>Visa & Immigration</h6>
                <a class="dropdown-item" href="uae-residence-visa.php">Residence Visa</a>
                <a class="dropdown-item" href="uae-golden-visa.php">Golden Visa</a>
                <a class="dropdown-item" href="services-freelance-visa-uae-dubai.php">Freelance Visa</a>
                <a class="dropdown-item" href="bank_account_open.php">Bank Account Opening</a>
              </div>
              <div class="col-md-2">
                <h6>Financial Services</h6>
                <a class="dropdown-item" href="payroll_page.php">Payroll</a>
                <a class="dropdown-item" href="vat_service.php">Corporate Tax & VAT</a>
                <a class="dropdown-item" href="compilance.php">Compliance</a>
              </div>
              <div class="col-md-2">
                <h6>Legal Services</h6>
                <a class="dropdown-item" href="pro-services-dubai.php">PRO Services</a>
                <a class="dropdown-item" href="will-preparation-uae.php">Will Preparation</a>
                <a class="dropdown-item" href="trademark-vs-copyright-uae.php">Trademark & Copyright</a>
              </div>
              <div class="col-md-2">
                <h6>Additional Services</h6>
                <a class="dropdown-item" href="health_insurance.php">Health Insurance</a>
                <a class="dropdown-item" href="police_clearance.php">Police Clearance</a>
                <a class="dropdown-item" href="dm_page.php">DM Approval</a>
                <a class="dropdown-item" href="emirates_page.php">Emirates ID Update</a>
              </div>
              <div class="col-md-2">
                <h6>Nominee Services</h6>
                <a class="dropdown-item" href="contact-us.php">Shareholder</a>
                <a class="dropdown-item" href="contact-us.php">Manager</a>
              </div>
            </div>
          </div>
        </li>
        <li class="nav-item px-2">
          <a class="nav-link" href="#">Blog</a>
        </li>
        <li class="nav-item px-2">
          <a class="nav-link" href="contact-us.php">Contact Us</a>
        </li>
      </ul>
      <a href="contact-us.php" class="btn text-white py-2 px-3 ms-lg-4" style="background-color: #1e2355;">Apply Now</a>
    </div>
  </div>
</nav>
 
      <!-- navbar end -->

       <!-- container 1 start -->
        <div class="container1">
          <div class="containe1sub">
          <div class="container1sub1 mx-auto pt-5">
            <p id="welcome"
   style="text-align: justify; font-weight: bold; font-size: 25px; letter-spacing: 0px; color:white; 
          opacity: 0; transform: translateX(-100%); transition: all 1.5s ease-out;">
  <b style="color:#1e2355;  bold; font-size: 30px;"> Welcome To Setupzo</b> <br>Your Trusted Partner For Business Setup In Dubai, UAE. 
</p>
<!--           <button class="buttons btn btn-warning py-2 px-3 my-2 my-sm-0" onclick="window.location.href='contactus.php'">-->
  <!--<b>Check Your Eligibility</b>-->
<!--</button>-->

          </div>
        
        <!-- cards start -->
 <div class="container1sub2 mx-auto mt-5 pt-5">
  <h2 class="hero-text1" style="text-align: center;">
    <b>Apply Online Now</b>
  </h2>
  <div class="container1sub2sub row">

     <div class="offercard">
      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">
      <p class="offerhead">Company Formation</p>
      <div class="cradbtns">
     <a class="buttons2 btn btn-warning py-2 px-0 my-2 my-sm-1" href="mainland-business-setup-in-dubai.php">Mainland</a><br>
     <a class="buttons2 btn btn-warning py-2 px-0 my-2 my-sm-1" href="business-setup-in-dubai-freezone.php">Free Zone</a>
      </div>
     </div>

     <div class="offercard">
      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">

      <p class="offerhead">Visa & Immigration Services</p>
      <div class="cradbtns">
         <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="uae-residence-visa.php">Residence Visas</a><br>
         <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="uae-golden-visa.php">Golden Visa Program</a><br>
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="services-freelance-visa-uae-dubai.php">Freelance Visas</a><br>
      <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="bank_account_open.php">Bank Account Opening</a><br>
        </div>
     </div>

     <div class="offercard">
      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">
      <p class="offerhead">Financial & Compliance Services</p>
      <div class="cradbtns">
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="payroll_page.php">Accounting & Payroll</a><br>
         
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="vat_service.php">Corporate Tax & VAT</a><br>
       <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="compilance.php">Compliance</a>
        </div>
     </div>

     <div class="offercard">
      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">
      <p class="offerhead">Legal & Administrative Services</p>
      <div class="cradbtns">
         <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="pro-services-dubai.php">PRO Services</a><br>
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="will-preparation-uae.php">Will Preparation</a><br>
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="trademark-vs-copyright-uae.php">Trademark & Copyright Registration</a>
        </div>
     </div>

     <div class="offercard">
      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">
      <p class="offerhead">Additional Services</p>
      <div class="cradbtns">
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="health_insurance.php">Health Insurance</a><br>
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="police_clearance.php">Police Clearance Certificate</a><br>
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="dm_page.php">Dm Approval</a><br>
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="emirates_page.php">Emirates ID info Update</a>
        </div>
     </div>

     <div class="offercard">
      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">
      <p class="offerhead">Nominee Services</p>
      <div class="cradbtns">
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="contact-us.php">Shareholder</a><br>
        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="contact-us.php">Manager</a>
        </div>
     </div>

    </div>
     
 </div>
<!-- cards end -->
 </div>
</div>
   <!-- container 1 end -->

<!-- container4 start -->
<div class="container-fluid py-2 row mx-auto">
  <div class="col-lg-5 col-md-9 col-sm-12 py-5 mx-auto  h-auto">
    <!--<p class="smheading">Setupzo</p>-->
    <h1 style="font-size:22px;text-align: justify;"> <b> Business Setup in Dubai, UAE Hassle-Free & Fast with Setupzo </b></h1><br>
    <p style=" text-align: justify;">
        <!--<p class="container4text">-->
  Start and grow your business in the heart of the UAE with Setupzo your trusted partner for business setup in Dubai, UAE. Whether you’re launching a new venture, expanding your operations, or relocating your company, we make the process smooth, affordable, and compliant with local laws and regulations.
Dubai is one of the most vibrant business hubs in the world, and we help you tap into its unlimited opportunities – from mainland to free zone company formation. <br> <br> <br>
 <a href="contact-us.php" class="btn text-white py-2 px-3 ms-lg-4" style="background-color: #1e2355;">Get Free Consultation</a>

    </p>
  </div>
   <div class="col-lg-5 col-md-9 col-sm-12 py-5 mx-auto mt-1 rounded">
       
<div id="customCarousel" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/dubai.jpg" class="d-block w-100 rounded" style="height:400px" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/dubai1.jpg" class="d-block w-100 rounded" style="height:400px" alt="img not found">
    </div>
    <div class="carousel-item">
      <img src="img/dubai3.jpg" class="d-block w-100 rounded" style="height:400px" alt="...">
    </div>
  </div>
 
</div>
  </div>
</div>
<!-- Full Width Section -->
<div class="container-fluid my-0 bg-sky py-0">
  <!-- Content in 90% Width -->
  <div class="mx-auto" style="width: 100%; ">
    <div class="p-5 p-md-5 bg-white rounded" style="background: #0A4D80;
background: linear-gradient(90deg, rgba(10, 77, 128, 1) 0%, rgba(87, 199, 133, 0) 0%, rgba(10, 77, 128, 1) 100%);">
      <h2 style="color:#1e2355"><b>Setupzo: Your Trusted Partner for Business Setup in Dubai Mainland & Free Zone</b></h2>
      <p class="mb-3" style=" text-align: justify;">
        Setupzo is your reliable agency for business setup in Dubai mainland and free zones, offering end-to-end solutions from company formation to licensing and visa processing. Whether you want the flexibility of the mainland or the tax advantages of a free zone, our experts ensure a smooth, compliant, and cost-effective setup process tailored to your goals.
          
      </p>
      <h2 style="color:#1e2355"><b>Attractive Benefits & Services</b></h2>
       <p class="mb-3" style=" text-align: justify;">
        At Setupzo, we offer everything you need to launch and grow your business in Dubai. Enjoy 100% foreign ownership in eligible sectors. Choose between free zone business setup for tax benefits or mainland company formation in Dubai for full UAE market access. Get transparent guidance on Dubai company formation costs, and secure your Dubai business visa setup with us.
Our expert consultants guide you through freezone and mainland company formation, acquiring a Dubai business visa, and opening a corporate bank account in Dubai.

      </p>

      
    </div>
  </div>
</div>

<div class="container-fluid py-4">
  <div class="w-90 mx-auto">
    <div class="row align-items-center">
      
      <!-- Text Section -->
      <div class="col-md-6 col-12 p-4">
        <h2><b>Why Dubai is the Best Place for Starting a Business</b></h2>
        <p style=" text-align: justify;">
        Dubai has transformed into a global business destination with tax-friendly policies, modern infrastructure, and a strategic location between Europe, Asia, and Africa. Whether you want to serve the local market or expand internationally, starting a business in Dubai, UAE, offers:
        
        <ul>
           <h6><li>Zero personal income tax</li></h6>              
           <h6><li>	100% foreign ownership in many sectors</li></h6>
           <h6><li>World-class free zones for trade and tech</li></h6>
           <h6><li>Access to global markets</li></h6>
           <h6><li>Fast company registration process</li></h6>
       </ul>
        At Setupzo, we make your new business setup in Dubai, UAE, simple, guiding you through every step with clarity. </p>
      </div>

      <!-- Image Section -->
      <div class="col-md-6 col-12 p-0">
        <img src="img/dubai4.jpg" alt="Setupzo" class="img-fluid w-100 h-auto">
      </div>

    </div>
  </div>
</div>
<!--end-->

<!-- Main Div -->
<!-- Main Section -->
<div class="container-fluid py-5 bg-light">
  <div class="w-90 mx-auto ">
    
    <!-- Heading -->
    <h2><b>Company Formation & Registration Services in Dubai, UAE</b></h2>
    <p class="mb-5" style="  text-align: justify;">
      At Setupzo, we specialize in complete company formation and registration services in Dubai, UAE, making the process seamless for both local entrepreneurs and foreign investors. Whether you need a mainland business setup, a free zone company formation, or help with company registration in Dubai, UAE, we handle everything from start to finish.
    </p>
    <h2 style="text-align:center"> <b>Our services include:</b></h2> <br>
    
    <!-- Cards Row -->
    <div class="row g-4">
      
      <!-- Card 1 -->
      <div class="col-md-6 col-lg-6 col-12"style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
          
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5> <b>1.	Mainland Business Setup in Dubai, UAE</b></h5>
            <p style=" text-align: justify; ">Setting up a mainland company gives you access to the entire UAE market without restrictions. Our team specializes in company formation in the Dubai mainland, ensuring you meet all Department of Economic Development (DED) requirements.  </p>
              <ul>
           <h6><li>100% ownership in many activities</li></h6>              
           <h6><li>100% ownership in many activities</li></h6>
           <h6><li>No currency restrictions</li></h6>
           <h6><li>Ideal for retail, consultancy, and service-based businesses</li></h6>
           
       </ul>
       </p>
          </div>
        </div>
      </div>
      
      <!-- Card 2 -->
      <div class="col-md-6 col-lg-6 col-12"style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
          
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5><b>2.	Business Setup in Dubai Freezone</b> </h5>
            <p class="card-text" style=" text-align: justify;">If you want tax advantages, easy import/export facilities, and 100% ownership, a free zone company formation in Dubai, UAE, might be right for you. 
             <ul>
           <h6><li>Zero customs duty within the zone</li></h6>              
           <h6><li>Full repatriation of profits</li></h6>
           <h6><li> Strategic locations for logistics and tech industries</li></h6>
           <h6><li>Industry-specific zones for better networking</li></h6>
       </ul>
        We guide you in choosing the right free zone for your goals – whether it’s JAFZA, DMCC, IFZA, or others.</p>
            
          </div>
        </div>
      </div> <br>
      
      <!-- Card 3 -->
      <div class="col-md-6 col-lg-6 col-12" style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
          
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5><b>3.	Company Registration in Dubai, UAE</b></h5>
            <p class="card-text" style=" text-align: justify;">Our streamlined process for company registration in Dubai, UAE, ensures your business is legally compliant from day one. We handle:
             <ul>
           <h6><li>Trade name reservation</li></h6>              
           <h6><li>Initial approvals</li></h6>
           <h6><li>License issuance</li></h6>
           <h6><li>Documentation & notarization</li></h6>
       </ul>
       </p>
          
          </div>
        </div>
      </div>
      
      <!-- Card 4 -->
      <div class="col-md-6 col-lg-6 col-12" style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
         
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5><b>4.	Business Setup Consultation in Dubai, UAE</b></h5>
            <p class="card-text" style=" text-align: justify;">Our business consultation services help you start your company in Dubai with confidence. We guide you in:
            <ul>
           <h6><li>Legal Structure Selection – Mainland, free zone, or offshore.</li></h6>              
           <h6><li>	Market Entry Planning – Choosing the right location and strategy.</li></h6>
           <h6><li>Cost Optimization – Reducing setup and operational expenses.</li></h6>
           <h6><li>Compliance Guidance – Meeting UAE legal and tax requirements.</li></h6>
       </ul>
      <p style="text-align: justify;"> With Setupzo, you get a clear, cost-effective roadmap for your business setup in Dubai, UAE. With our expert team, you can start your business in Dubai confidently, knowing you’re fully compliant and ready to grow.</p>
          
            
          </div>
        </div>
      </div>

    </div>
    
  </div>
</div>

  <!-- Top Section: Full width with 90% work area -->
  <section class="py-4 bg-light">
    <div class="w-91">
      <h2><b> Why Choose Setupzo for Business Setup & Company Formation in Dubai, UAE?</b></h2>
      <p style="text-align:justify;">
        At Setupzo, we stand out in the competitive business setup industry with our exceptional service quality, extensive experience, and customer-centric approach. Whether you're looking for a seamless business setup in UAE or expert guidance for company formation in Dubai, we ensure a smooth and hassle-free experience.<br>
        We know that starting a business in Dubai can be overwhelming. That’s why we take care of the details so you can focus on your goals.
        <ul>
           <h6> <li>End-to-End Support – From consultation to licensing, we handle it all.</li></h6>    
           <h6> <li>Mainland & Free Zone Experts – Registered consultants with proven success.</li></h6>    
           <h6> <li>Fast Company Registration – Get your license in days, not weeks.</li></h6>    
           <h6><li>Transparent Pricing – No hidden fees or surprise costs.</li></h6>    
        </ul>
      
      </p>
      <div class="container" style="width:100%; margin:auto; padding:50px 0;  bg-primary">
      
  <div class="row g-4">

    <!-- Card 1 -->
    <div class="col-md-4">
      <div class="card border-primary shadow-sm rounded-4 h-100 ">
        <img src="img/Highly Qualified Professionals (1).jpg" class="card-img-top rounded-top-4" alt="Image 1">
        <div class="card-body">
          <h5 class="card-title ">Highly Qualified Professionals</h5>
          <p class="card-text "  style="  text-align: justify;">
          Our team of experts has years of experience in Dubai company formation and corporate services. We understand customer needs and deliver tailored solutions.
          </p>
        </div>
      </div>
    </div>

    <!-- Card 2 -->
    <div class="col-md-4">
      <div class="card border-primary shadow-sm rounded-4 h-100">
        <img src="img/stong government relations (1).jpg" class="card-img-top rounded-top-4" alt="Image 2">
        <div class="card-body">
          <h5 class="card-title  ">Strong Government and Industry Connections</h5>
          <p class="card-text"  style="  text-align: justify;">
          We work directly with UAE government authorities for fast company setup in Dubai and have Platinum Partnerships with top Free Zones to give clients exclusive benefits.
          </p>
        </div>
      </div>
    </div>

    <!-- Card 3 -->
    <div class="col-md-4">
      <div class="card border-primary shadow-sm rounded-4 h-100">
        <img src="img/Timely & Efficient Service Delivery (1).jpg" class="card-img-top rounded-top-4" alt="Image 3">
        <div class="card-body">
          <h5 class="card-title ">Timely and Efficient Service Delivery</h5>
          <p class="card-text"  style="  text-align: justify;">
          We focus on quick and smooth business setup with easy documentation and fast approvals, saving clients time and effort.
          </p>
        </div>
      </div>
    </div>

    <!-- Card 4 -->
    <div class="col-md-4">
      <div class="card border-primary shadow-sm rounded-4 h-100  " style="margin-top:10px;">
        <img src="img/Proven Track Record & Customer Trust (2).jpg" class="card-img-top rounded-top-4" alt="Image 4">
        <div class="card-body">
          <h5 class="card-title  ">Proven Track Record and Customer Trust</h5>
          <p class="card-text"  style="  text-align: justify;">
           Trusted by 15,000+ clients for company setup in the UAE, we provide personalized support to ensure every customer gets the attention they deserve.
          </p>
        </div>
      </div>
    </div>

    <!-- Card 5 -->
    <div class="col-md-4">
      <div class="card border-primary shadow-sm rounded-4 h-100" style="margin-top:10px;">
        <img src="img/Market Expertise & Visionary Leadership (1).jpg" class="card-img-top rounded-top-4" alt="Image 5">
        <div class="card-body">
          <h5 class="card-title  ">	Market Expertise and Visionary Leadership</h5>
          <p class="card-text"  style="  text-align: justify;">
           Our CEO knows the market, industry trends, and customer needs, offering direct interactions to build trust and give personalized guidance.
          </p>
        </div>
      </div>
    </div>

    <!-- Card 6 -->
    <div class="col-md-4">
      <div class="card border-primary shadow-sm rounded-4 h-100" style="margin-top:10px;">
        <img src="img/Commitment to Customer Success (1) (1).jpg" class="card-img-top rounded-top-4" alt="Image 6">
        <div class="card-body">
          <h5 class="card-title  ">Commitment to Customer Success</h5>
          <p class="card-text"  style="  text-align: justify;">
          We don’t just offer services; we share a vision for our customers’ future. Our goal is to help entrepreneurs succeed, not just finish transactions.
With Setupzo, starting a business in Dubai isn’t just paperwork—it’s the first step toward success with a trusted partner.

          </p>
        </div>
      </div>
    </div>

  </div>
</div>

 
    </div>
  </section>
  
  <div class="container">
       <h2><b> Why Choose Setupzo for Business Setup & Company Formation in Dubai, UAE?</b></h2><br>
        <h6 style="text-align:center;"><b>Here are some of our easy steps:</b></h6><br>
       
   <div style="display:flex; justify-content:center; gap:20px; flex-wrap:wrap; margin-bottom:30px;">

    <!-- Card 1 -->
    <div style="border:2px solid #1e2355; border-radius:10px; width:90%; max-width:350px; padding:20px; text-align:center; background:#fff; display:flex; flex-direction:column; justify-content:space-between;">
      <div style="font-weight:bold; color:#1e2355; margin-bottom:10px;">Step 1</div>
      <i class="fas fa-comments" style="font-size:40px; color:#1e2355; margin-bottom:15px;"></i>
      <h5>Consultation</h5>
      <p  style="  text-align: justify;">We start by understanding your business goals and suggesting the best setup option – mainland, freezone, or offshore.</p>
    </div>

    <!-- Card 2 -->
    <div style="border:2px solid #1e2355; border-radius:10px; width:90%; max-width:350px; padding:20px; text-align:center; background:#fff; display:flex; flex-direction:column; justify-content:space-between;">
      <div style="font-weight:bold; color:#1e2355; margin-bottom:10px;">Step 2</div>
      <i class="fas fa-map-marked-alt" style="font-size:40px; color:#1e2355; margin-bottom:15px;"></i>
      <h5>Choose Mainland or Free Zone</h5>
       <p  style="  text-align: justify;">We compare benefits, costs, and requirements so you can make the right choice.</p>
    </div>

    <!-- Card 3 -->
    <div style="border:2px solid #1e2355; border-radius:10px; width:90%; max-width:350px; padding:20px; text-align:center; background:#fff; display:flex; flex-direction:column; justify-content:space-between;">
      <div style="font-weight:bold; color:#1e2355; margin-bottom:10px;">Step 3</div>
      <i class="fas fa-building" style="font-size:40px; color:#1e2355; margin-bottom:15px;"></i>
      <h5>Company Registration in Dubai, UAE</h5>
       <p  style="  text-align: justify;">We prepare and submit all documents to the relevant authorities for quick approval.</p>
    </div>

  </div>

  <!-- Bottom 2 Cards -->
  <div style="display:flex; justify-content:center; gap:20px; flex-wrap:wrap;">

    <!-- Card 4 -->
    <div style="border:2px solid #1e2355; border-radius:10px; width:90%; max-width:350px; padding:20px; text-align:center; background:#fff; display:flex; flex-direction:column; justify-content:space-between;">
      <div style="font-weight:bold; color:#1e2355; margin-bottom:10px;">Step 4</div>
      <i class="fas fa-file-signature" style="font-size:40px; color:#1e2355; margin-bottom:15px;"></i>
      <h5>License Issuance & Bank Account Opening</h5>
      <p  style="  text-align: justify;">Once approved, we help you open a corporate bank account so you can start operations immediately.</p>
    </div>

    <!-- Card 5 -->
    <div style="border:2px solid #1e2355; border-radius:10px; width:90%; max-width:350px; padding:20px; text-align:center; background:#fff; display:flex; flex-direction:column; justify-content:space-between;">
      <div style="font-weight:bold; color:#1e2355; margin-bottom:10px;">Step 5</div>
      <i class="fas fa-rocket" style="font-size:40px; color:#1e2355; margin-bottom:15px;"></i>
      <h5>Start Operations</h5>
      <p  style="  text-align: justify;">You’re officially in business! Our support doesn’t stop here – we assist with renewals, visas, and more.</p>
    </div>

  </div>
   </div>
   
   <div class="container border rounded mt-5 px-4 py-4 border shadow">
       <!--<div class="col-lg-10 col-md-12 col-sm-12">-->
           <h2><b>How Much Does Business Setup in Dubai Cost?</b></h2>
           <p style="  text-align: justify;">The cost of setting up a business in Dubai can range from AED 12,900 to AED 35,000 or more, depending on several factors, including:</p>
           <ul>
               <li>The type of business</li>
               <li>Location (mainland or free zone)</li>
               <li>The need for visas</li>
           </ul>
           <p>Basic free zone company formation packages can start as low as AED 5,550, while mainland setups can start from AED 18,900.</p>
           
          <h2><b>Factors Influencing Cost:</b></h2>
          <ul>
              <li> <b>Mainland vs. Free Zone:</b></li>
          </ul>
          <p style="  text-align: justify;">Mainland setups generally offer more flexibility in terms of business activities and location, but can be more expensive, especially with office space requirements. Free zones offer cost-effective options with various packages, but may have limitations on where you can operate.</p>
           <ul>
           <li> <b>	Business Activity:</b></li>
          </ul>
          <p style="  text-align: justify;">The type of business license and the specific activities you intend to carry out will impact the cost.</p>
          <ul>
           <li> <b>Number of Visas:</b></li>
          </ul>
          <p style="  text-align: justify;">Each visa application will incur additional costs for processing and associated fees.</p>
           <ul>
           <li> <b>	Free Zone Selection:</b></li>
          </ul>
          <p style="  text-align: justify;">Different free zones have varying fee structures, so it's essential to compare options.</p>
           <ul>
           <li> <b>	Office Space:</b></li>
          </ul>
          <p style="  text-align: justify;">The type and size of office space (e.g., flexi-desk, dedicated office) will also affect the overall cost.</p>
            <ul>
           <li> <b>	Professional Fees:</b></li>
          </ul>
          <p style="  text-align: justify;">You may incur costs for legal, accounting, and other professional services related to company registration and ongoing operations.</p>
            <ul>
           <li> <b>Other Fees:</b></li>
          </ul>
          <p style="  text-align: justify;">There may be additional fees for things like immigration cards, medical checkups, and biometrics.</p>
          <h2><b>Cost Breakdown Examples:</b></h2>
           <ul>
               

           <li> Mainland Company Setup: AED 15,000 to AED 35,000, plus office rent.</li>
           <li> 	Free Zone Company Setup: AED 10,000–30,000, based on free zone and business type.</li>
           <li>Basic Free Zone Package (0 visas): AED 5,565. </li>
           <li> 	Basic Free Zone Package (1 visa): AED 12,010.</li>
           <li>LLC Company Formation: AED 20,000 to AED 30,000. </li>
           <li> Investor Visa: AED 4,000 to AED 5,500.</li>
          </ul>
           <h2><b> Tips for Saving Costs:</b></h2>
           <ul>
              <li> <b>Compare Free Zone Options:</b></li>
          </ul>
          <p style="  text-align: justify;">Research and compare different free zones to find the most cost-effective option for your business.</p>
           <ul>
           <li> <b>	Consider a Flexi-Desk:</b></li>
          </ul>
          <p style="  text-align: justify;">If you don't need a full-time office, a flexi-desk can be a more budget-friendly option.</p>
          <ul>
           <li> <b>	Utilize Shared Services:</b></li>
          </ul>
          <p style="  text-align: justify;">Some free zones offer shared services like reception and administrative support, which can help reduce costs.</p>
           <ul>
           <li> <b>Seek Expert Advice:</b></li>
          </ul>
          <p style="  text-align: justify;">Consulting with business setup experts can help you navigate the process and find the most cost-effective solutions for your specific needs.<br>
By carefully considering these factors and seeking professional guidance, you can effectively plan your business setup in Dubai and manage your costs.
</p>
          
       </div>
   </div>
    <section class="py-4 bg-light">
   <div class="container">
       <div>
        <h2><b>Best Business Setup Consultants in Dubai, UAE</b></h2>
         <p style="  text-align: justify;">When it comes to Dubai for company formation, experience matters. At Setupzo, our consultants have helped hundreds of entrepreneurs and corporations establish successful operations in the UAE.</p>
       <h6><b>We combine:</b></h6>
       <ul>
           <li><b>Local expertise</b> – We know Dubai’s laws, regulations, and best practices.</li>
            <li><b>Global perspective</b> – We work with investors from over 30 countries.</li>
             <li><b>Personalized service</b> – Every business is unique, so we tailor our solutions.</li>
       </ul>
       
       
   </div>
    </div>
    </section>
  
 
 <!--faq-->
 <div style="text-align:justify" class="container-fluid py-5">
  <div class="accordion">
      <h2 style="text-align:center;"> <b>Frequently Asked Questions(FAQs)</b></h2> <br>
  <!-- Q1 -->
  <div class="accordion-item">
    <div class="accordion-header active">Q1: What is the cost of company formation in Dubai, UAE?</div>
    <div class="accordion-body show">
      Costs vary depending on your chosen setup (mainland or free zone) and business activity. Setupzo provides transparent quotes with no hidden charges.
    </div>
  </div>

  <!-- Q2 -->
  <div class="accordion-item">
    <div class="accordion-header">Q2: How much does it cost to start a business in Dubai?</div>
    <div class="accordion-body">
      The cost of setting up a business in the UAE depends on factors such as:
      <ul>
        <li>Business Type</li>
        <li>Location</li>
        <li>License</li>
      </ul>
      Some licenses start from AED 12,900, while company registration in Dubai usually ranges between AED 15,000 and AED 28,000.
    </div>
  </div>

  <!-- Q3 -->
  <div class="accordion-item">
    <div class="accordion-header">Q3: Do I need a local sponsor for a mainland company in Dubai?</div>
    <div class="accordion-body">
      For most business activities, you may require a local service agent or partner. However, 100% foreign ownership is now allowed for many activities.
    </div>
  </div>

  <!-- Q4 -->
  <div class="accordion-item">
    <div class="accordion-header">Q4: How long does it take to set up a company in Dubai?</div>
    <div class="accordion-body">
      Company formation in Dubai can take anywhere between 3 to 10 working days, depending on the type of business and approvals needed.
    </div>
  </div>

  <!-- Q5 -->
  <div class="accordion-item">
    <div class="accordion-header">Q5: Can foreigners own 100% of a business in Dubai?</div>
    <div class="accordion-body">
      Yes, in many free zones and for specific mainland activities, 100% foreign ownership is allowed.
    </div>
  </div>

  <!-- Q6 -->
  <div class="accordion-item">
    <div class="accordion-header">Q6: What documents are required for business setup in Dubai?</div>
    <div class="accordion-body">
      Commonly required documents include:
      <ul>
        <li>Passport copies</li>
        <li>Business plan</li>
        <li>Visa copies</li>
        <li>Passport-sized photos</li>
      </ul>
    </div>
  </div>

  <!-- Q7 -->
  <div class="accordion-item">
    <div class="accordion-header">Q7: Can I open a corporate bank account in Dubai easily?</div>
    <div class="accordion-body">
      Yes, once your company is registered, Setupzo assists you in opening a corporate bank account with leading UAE banks.
    </div>
  </div>

  <!-- Q8 -->
  <div class="accordion-item">
    <div class="accordion-header">Q8: What are the benefits of setting up a business in Dubai?</div>
    <div class="accordion-body">
      Key benefits include:
      <ul>
        <li>Tax-friendly environment</li>
        <li>100% repatriation of profits</li>
        <li>Strategic global location</li>
      </ul>
    </div>
  </div>

  <!-- Q9 -->
  <div class="accordion-item">
    <div class="accordion-header">Q9: Is VAT registration mandatory in Dubai?</div>
    <div class="accordion-body">
      VAT registration is mandatory if your annual revenue exceeds AED 375,000.
    </div>
  </div>

  <!-- Q10 -->
  <div class="accordion-item">
    <div class="accordion-header">Q10: Can I get investor or partner visas through company formation?</div>
    <div class="accordion-body">
      Yes, company owners and their dependents are eligible for investor or partner visas.
    </div>
  </div>

  <!-- Q11 -->
  <div class="accordion-item">
    <div class="accordion-header">Q11: What is the difference between mainland and free zone companies?</div>
    <div class="accordion-body">
      Mainland companies allow you to do business across the UAE, while free zone companies are limited to specific zones but often provide 100% ownership.
    </div>
  </div>

  <!-- Q12 -->
  <div class="accordion-item">
    <div class="accordion-header">Q12: Do I need a physical office to register a company?</div>
    <div class="accordion-body">
      For most licenses, a physical or flexi-desk office is required.
    </div>
  </div>

  <!-- Q13 -->
  <div class="accordion-item">
    <div class="accordion-header">Q13: How does Setupzo help with legal paperwork?</div>
    <div class="accordion-body">
      We handle all the documentation, approvals, and legal requirements on your behalf.
    </div>
  </div>

  <!-- Q14 -->
  <div class="accordion-item">
    <div class="accordion-header">Q14: Can I start a business without visiting Dubai?</div>
    <div class="accordion-body">
      In many cases, yes. We offer remote business setup services.
    </div>
  </div>

  <!-- Q15 -->
  <div class="accordion-item">
    <div class="accordion-header">Q15: What is the cost of renewing a business license?</div>
    <div class="accordion-body">
      Renewal costs depend on your license type and location. Setupzo provides transparent renewal packages.
    </div>
  </div>

  <!-- Q16 -->
  <div class="accordion-item">
    <div class="accordion-header">Q16: Are there any hidden charges in company setup?</div>
    <div class="accordion-body">
      No, Setupzo offers clear and transparent pricing with no hidden costs.
    </div>
  </div>

  <!-- Q17 -->
  <div class="accordion-item">
    <div class="accordion-header">Q17: Do I need to hire local staff?</div>
    <div class="accordion-body">
      It depends on your license type. Some activities require hiring UAE nationals.
    </div>
  </div>

  <!-- Q18 -->
  <div class="accordion-item">
    <div class="accordion-header">Q18: Can I own multiple businesses under one license?</div>
    <div class="accordion-body">
      No, each business activity requires its own license, but some related activities can be grouped.
    </div>
  </div>

  <!-- Q19 -->
  <div class="accordion-item">
    <div class="accordion-header">Q19: What is the process for closing a company in Dubai?</div>
    <div class="accordion-body">
      Closing a company requires final audits, deregistration, and NOC approvals.
    </div>
  </div>

  <!-- Q20 -->
  <div class="accordion-item">
    <div class="accordion-header">Q20: Does Setupzo provide ongoing business support?</div>
    <div class="accordion-body">
      Yes, we offer full post-setup support including PRO services, renewals, and compliance assistance.
    </div>
  </div>
</div>
</div>
<!--faq end-->
 
<!-- container 5 strat -->
<div class="container5">
  <div class="container5sub1 mx-auto py-5">
    <h6 class="smheading">Contact Us</h6>
    <p class="container4head text-white">We love hearing from you</p>
    <form class="form-container row g-3 mx-auto" id="contactForm" action="save_contact.php">
      <div class="col-md-6 py-2">
          <input type="text" class="form-control" id="name" placeholder="Enter your name" name="name" required>
      </div>
       <div class="mb-3 col-md-6 py-2 phone-input-container">
        <input type="tel" class="form-control" id="phone" name="phone" required>
        <input type="hidden" id="dial_code" name="dial_code">
      </div>
      <div class="col-md-12 py-2">
        <input type="email" class="form-control" id="email" placeholder="Enter your email" name="email" required>
      </div>
      <div class="col-12 py-2">
          <textarea class="form-control" id="comments" rows="4" placeholder="Description..." name="comments"></textarea>
      </div>
      <div class="col-12 py-2 text-center">
         <button type="submit" class="buttons rounded px-5 btn submit w-100" id="submitBtn">
  <span id="submitText">Submit</span>
  <span id="processingText" style="display: none;">Processing...</span>
</button>
      </div>
  </form>
    
  </div>
 </div>
<!-- container 5 end -->


 <!-- Footer start -->
 <div class="footer">

  <div class="footer-container">
    <!-- About Us Column -->
    <div class="footer-column">
           <img src="img/ahmer-setupzoo-[white-color.png" width="100px" alt="logo">
      <p>Setupzo empowers entrepreneurs and investors with seamless company formation, visa processing, and smart administrative solutions.

</p>
    </div>
    <!-- Special Facilities Column -->
    <div class="footer-column">
      <h2>Quick Links</h2>
      <a href="index.php">Home</a>
      <a href="contact-us.php">Contact</a>
      <a href="services.php">Services</a>
      <a href="about-us.php">About</a>
    </div>
    <!-- Contact Column -->
    <div class="footer-column">
      <h2>Contact Us</h2>
        <!-- <p><i class="fas fa-map-marker-alt me-2"></i></p> -->
        <p><a href="tel:+971568677227"><i class="fas fa-phone me-2 mx-2"></i>+971 56 867 7227</a></p>
        <p><a href="mailto:info@setupzo.com"><i class="fas fa-envelope me-2 mx-2"></i>info@setupzo.com</a></p>
         <p style="font-size:20px" class="text-white"><i class="fa-brands fa-instagram text-white mx-3"></i>
      <i class="fa-brands fa-square-facebook mx-3"></i>
    <i class="fa-brands fa-linkedin-in mx-3"></i></p>
    </div>
    <!-- Social Media Column -->
  </div>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"></script>
<!-- Font Awesome for Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
<script>
const headers = document.querySelectorAll(".accordion-header");
headers.forEach(header => {
    header.addEventListener("click", () => {
        const openItem = document.querySelector(".accordion-header.active");
        if (openItem && openItem !== header) {
            openItem.classList.remove("active");
            openItem.nextElementSibling.classList.remove("show");
        }
        header.classList.toggle("active");
        header.nextElementSibling.classList.toggle("show");
    });
});
</script>
  <script>
      
    // Initialize phone input
  const input = document.querySelector("#phone");
  const iti = window.intlTelInput(input, {
    initialCountry: "auto",
    geoIpLookup: function(callback) {
      fetch("https://ipinfo.io?token=b8604525b76188")
        .then(response => response.json())
        .then(data => {
          const countryCode = data.country ? data.country : "US";
          callback(countryCode); // Do not convert to lowercase!
        })
        .catch(() => {
          callback("US");
        });
    },
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"
  });       
    // Initialize AOS
    AOS.init();
    
    // Contact form submission
    $('#contactForm').on('submit', function(e) {
        e.preventDefault(); // Prevent page reload

        $.ajax({
            type: 'POST',
            url: 'save_contact.php',
            data: $(this).serialize(),
            success: function(response) {
                alert(response); // Show success or error
                $('#contactForm')[0].reset(); // Reset form
            },
            error: function() {
                alert('An error occurred. Please try again.');
            }
        });
    });

  // Validate phone before submit
  document.querySelector("#contactForm").addEventListener("submit", function (e) {
    if (!phoneInput.isValidNumber()) {
      e.preventDefault();
      alert("Please enter a valid phone number.");
    } else {
      // Optionally replace raw value with full international format
      phoneInputField.value = phoneInput.getNumber();
    }
  });
  document.querySelector("#contactForm").addEventListener("submit", function (e) {
  const submitBtn = document.getElementById("submitBtn");
  const submitText = document.getElementById("submitText");
  const processingText = document.getElementById("processingText");

  // Show processing state
  submitBtn.classList.add("loading");
  submitText.style.display = "none";
  processingText.style.display = "inline";

   
});

    </script>
    <!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    
    <!--Welcome-->
   <script>
  const text = document.getElementById("welcome");

  // Scroll detect using Intersection Observer
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        text.style.opacity = "1";
        text.style.transform = "translateX(0)";
        observer.unobserve(text); // ایک بار ہی animate ہوگا
      }
    });
  });

  observer.observe(text);
</script>

 Counter animation script 
<script>
  document.addEventListener("DOMContentLoaded", () => {
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
      counter.innerText = '0';
      const updateCounter = () => {
        const target = +counter.innerText.replace(/\D/g, '') || +counter.dataset.target;
        const current = +counter.innerText.replace(/\D/g, '') || 0;
        const increment = target / 100;

        if (current < target) {
          counter.innerText = Math.ceil(current + increment);
          setTimeout(updateCounter, 30);
        } else {
          counter.innerText = target + (counter.innerText.includes('%') ? '%' : '+');
        }
      };
      updateCounter();
    });
  });
</script>

 
<script>
  (function () {
    var options = {
      whatsapp: "+971568677227",
      call_to_action: "Message us",
      position: "right",
    };
    var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
    var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
    s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
    document.getElementsByTagName('head')[0].appendChild(s);
  })();
</script> 
counter
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
  $('.counter').each(function () {
    var $this = $(this),
        countTo = $this.attr('data-count');
    
    $({ countNum: $this.text() }).animate({
      countNum: countTo
    },
    {
      duration: 2000,
      easing: 'swing',
      step: function () {
        $this.text(Math.floor(this.countNum));
      },
      complete: function () {
        $this.text(this.countNum);
      }
    });
  });
</script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

counters
<script>
document.addEventListener("DOMContentLoaded", () => {
  const counters = document.querySelectorAll(".counter");
  let started = false;

  function runCounter() {
    if (!started && window.scrollY + window.innerHeight > document.querySelector(".counter-section").offsetTop + 100) {
      counters.forEach(counter => {
        let target = +counter.getAttribute("data-count");
        let count = 0;
        let increment = target / 100;
        let update = setInterval(() => {
          count += increment;
          if (count >= target) {
            counter.innerText = target + "+";
            clearInterval(update);
          } else {
            counter.innerText = Math.ceil(count);
          }
        }, 30);
      });
      started = true;
    }
  }

  window.addEventListener("scroll", runCounter);
});
</script>
 Swiper JS 
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

 
nev
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const dropdown = document.querySelector('.nav-item.dropdown');
    const megaMenu = document.getElementById('megaMenu');

    if (window.innerWidth >= 992) {
      let timer;

      dropdown.addEventListener('mouseenter', () => {
        clearTimeout(timer);
        megaMenu.style.display = 'block';
      });

      dropdown.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });

      megaMenu.addEventListener('mouseenter', () => {
        clearTimeout(timer);
        megaMenu.style.display = 'block';
      });

      megaMenu.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });
    } else {
      const toggleButton = document.getElementById('toggleMegaMenu');
      toggleButton.addEventListener('click', function () {
        megaMenu.classList.toggle('show');
        toggleButton.textContent = megaMenu.classList.contains('show') ? 'Hide Services' : 'Show Services';
      });
    }
  });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
 


</body>
</html>