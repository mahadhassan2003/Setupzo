<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

// DB connection
$host = "localhost";
$username = "u259563098_setupzo";
$password = "Setupzo123";
$dbname = "u259563098_setupzo";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Upload folder
$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

function handleFileUpload($inputName) {
    global $uploadDir;
    if (isset($_FILES[$inputName]) && $_FILES[$inputName]['error'] === UPLOAD_ERR_OK) {
        $tmpPath = $_FILES[$inputName]['tmp_name'];
        $fileName = time() . '_' . basename($_FILES[$inputName]['name']);
        $destination = $uploadDir . $fileName;
        if (move_uploaded_file($tmpPath, $destination)) {
            return $destination;
        }
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $user_type = $_POST['user_type'] ?? '';

    // Visitor fields
    $unified_number = $_POST['unified_number'] ?? null;
    $certificate_purpose = $_POST['certificate_purpose'] ?? null;
    $requested_party_type = $_POST['requested_party_type'] ?? null;
    $certificate_language = $_POST['certificate_language'] ?? null;

    // Resident fields
    $emirates_id = $_POST['emirates_id'] ?? null;
    $certificate_purpose2 = $_POST['certificate_purpose2'] ?? null;
    $requested_party_type2 = $_POST['requested_party_type2'] ?? null;
    $certificate_language2 = $_POST['certificate_language2'] ?? null;

    // Validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format'); window.history.back();</script>";
        exit;
    }

    if (!preg_match('/^[0-9]{7,15}$/', $phone)) {
        echo "<script>alert('Invalid phone number. Enter 7-15 digits.'); window.history.back();</script>";
        exit;
    }

    // Check duplicate email
    $check = $pdo->prepare("SELECT COUNT(*) FROM police WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetchColumn() > 0) {
        echo "<script>alert('An application with this email already exists.'); window.history.back();</script>";
        exit;
    }

    $passport_path = handleFileUpload('passport');

    // Insert into DB
    $stmt = $pdo->prepare("
        INSERT INTO police 
        (fullname, email, phone, user_type, passport_path, unified_number, certificate_purpose, requested_party_type, certificate_language,
         emirates_id, certificate_purpose2, requested_party_type2, certificate_language2)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $fullname,
        $email,
        $phone,
        $user_type,
        $passport_path,
        $unified_number,
        $certificate_purpose,
        $requested_party_type,
        $certificate_language,
        $emirates_id,
        $certificate_purpose2,
        $requested_party_type2,
        $certificate_language2
    ]);

    // Email config
    $smtpHost = 'smtp.gmail.com';
    $smtpUsername = 'info@setupzo.com';
    $smtpPassword = 'gupy jyfz qydd xzau';
    $fromEmail = 'info@setupzo.com';
    $fromName = 'Setup zo';

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $smtpHost;
        $mail->SMTPAuth = true;
        $mail->Username = $smtpUsername;
        $mail->Password = $smtpPassword;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($email, $fullname);
        $mail->isHTML(true);
        $mail->Subject = 'Police Clearance Application Received';
        $mail->Body = "<p>Dear $fullname,<br>We have received your application. Our team will contact you soon.<br>Regards,<br>Setup zo</p>";
        $mail->send();
    } catch (Exception $e) {
        echo "<script>alert('Failed to send email to applicant: " . addslashes($mail->ErrorInfo) . "');</script>";
    }

    try {
        $adminMail = new PHPMailer(true);
        $adminMail->isSMTP();
        $adminMail->Host = $smtpHost;
        $adminMail->SMTPAuth = true;
        $adminMail->Username = $smtpUsername;
        $adminMail->Password = $smtpPassword;
        $adminMail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $adminMail->Port = 465;

        $adminMail->setFrom($fromEmail, $fromName);
        $adminMail->addAddress('info@setupzo.com', 'Setup zo');
        $adminMail->isHTML(true);
        $adminMail->Subject = 'New Police Clearance Application';
        $adminMail->Body = "<p>New application received from <strong>$fullname</strong> ($email)</p>";
        if ($passport_path) $adminMail->addAttachment($passport_path, 'Passport');
        $adminMail->send();
    } catch (Exception $e) {
        echo "<script>alert('Failed to send admin email: " . addslashes($adminMail->ErrorInfo) . "');</script>";
    }

    echo "<script>alert('Application submitted successfully!'); window.location.href = window.location.pathname;</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Police Clearance Form</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.css" />
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    .d-none { display: none; }
    .drop-zone {
      width: 100%;
      height: 100px;
      border: 2px dashed #aaa;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 10px;
      cursor: pointer;
      margin-bottom: 10px;
    }
    .drop-zone.dragover {
      border-color: #333;
      background: #f0f0f0;
    }
    .file-name {
      font-size: 14px;
      color: #555;
    }
    .loading::after {
      content: "";
      position: absolute;
      top: 50%;
      right: 10px;
      width: 16px;
      height: 16px;
      border: 2px solid #fff;
      border-top-color: transparent;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
      transform: translateY(-50%);
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    #phone {
  width: 100% !important;
  font-size: 1.2rem; /* Make text bigger */
  padding: 0.5rem 0.75rem; /* Add padding for nicer look */
}

.iti {
  width: 100% !important;
}
  </style>
</head>
<body>
<body style="font-family: 'Times New Roman', Times, serif;">

<!-- Navbar -->
<?php include_once("navbar.php") ?>
<!-- Image Section -->
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Full Cover Image" class="img-fluid">
  </div>
<div class="container py-5">
     <div class="col-lg-9 col-md-9 col-sm-10 mx-auto py-5" style=" background-color:#FBFBFB;">
  <h3 class="mb-4">Police Clearance Application</h3>
  <form action="police.php" method="POST" enctype="multipart/form-data" onsubmit="return validateForm();">
    
    <div class="mb-3">
      <label class="form-label">Full Name as Passport</label>
      <input type="text" class="form-control" name="fullname" required>
    </div>
    
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" name="email" required>
    </div>
    
    <div class="mb-3">
      <label class="form-label">Phone Number</label>
      <input type="tel" class="form-control" id="phone" name="phone" required>
    </div>
    
    <div class="mb-3">
      <label class="form-label">Upload Passport</label>
      <div class="drop-zone" id="passport-dropzone">
        <span class="file-name">Click or drag file to upload</span>
        <input type="file" name="passport" id="passport" hidden required accept="image/*,.pdf">
      </div>
    </div>
    
    <div class="mb-3">
      <label class="form-label">Select Type</label>
      <select class="form-select" id="userType" name="user_type" required>
        <option value="">-- Select --</option>
        <option value="visitor">Are you a visitor?</option>
        <option value="resident">Do you have resident?</option>
      </select>
    </div>
    
    <div id="visitorForm" class="d-none border p-3">
      <h5>Visitor Form</h5>
      <div class="mb-3">
        <label class="form-label">Unified Number</label>
        <input type="text" class="form-control" name="unified_number">
      </div>
      <div class="mb-3">
        <label class="form-label">Certificate Purpose</label>
        <input type="text" class="form-control" name="certificate_purpose">
      </div>
      <div class="mb-3">
        <label class="form-label">Type of Requested Party</label>
        <input type="text" class="form-control" name="requested_party_type">
      </div>
      <div class="mb-3">
        <label class="form-label">Certificate Language</label>
        <input type="text" class="form-control" name="certificate_language">
      </div>
    </div>

    <div id="residentForm" class="d-none border p-3">
      <h5>Resident Form</h5>
      <div class="mb-3">
        <label class="form-label">Emirates ID</label>
        <input type="text" class="form-control" name="emirates_id">
      </div>
      <div class="mb-3">
        <label class="form-label">Certificate Purpose</label>
        <input type="text" class="form-control" name="certificate_purpose2">
      </div>
      <div class="mb-3">
        <label class="form-label">Type of Requested Party</label>
        <input type="text" class="form-control" name="requested_party_type2">
      </div>
      <div class="mb-3">
        <label class="form-label">Certificate Language</label>
        <input type="text" class="form-control" name="certificate_language2">
      </div>
    </div>
    
    <button type="submit" class="btn btn-primary w-100" id="submitBtn">Submit</button>
  </form>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>
<script>
  const input = document.querySelector("#phone");
  const iti = window.intlTelInput(input, {
    initialCountry: "auto",
    geoIpLookup: function(callback) {
      fetch("https://ipinfo.io?token=b8604525b76188")
        .then(res => res.json())
        .then(data => callback(data.country || "US"))
        .catch(() => callback("US"));
    }
  });

  // Show/hide forms
  $('#userType').change(function() {
    const val = $(this).val();
    $('#visitorForm').addClass('d-none');
    $('#residentForm').addClass('d-none');
    if (val === 'visitor') {
      $('#visitorForm').removeClass('d-none');
    } else if (val === 'resident') {
      $('#residentForm').removeClass('d-none');
    }
  });

  // Drop zone logic
  const dropZone = document.getElementById("passport-dropzone");
  const fileInput = document.getElementById("passport");
  const fileNameDisplay = dropZone.querySelector(".file-name");

  dropZone.addEventListener("click", () => fileInput.click());

  dropZone.addEventListener("dragover", e => {
    e.preventDefault();
    dropZone.classList.add("dragover");
  });

  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
  });

  dropZone.addEventListener("drop", e => {
    e.preventDefault();
    dropZone.classList.remove("dragover");
    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      fileNameDisplay.textContent = e.dataTransfer.files[0].name;
    }
  });

  fileInput.addEventListener("change", () => {
    if (fileInput.files.length > 0) {
      fileNameDisplay.textContent = fileInput.files[0].name;
    } else {
      fileNameDisplay.textContent = "Click or drag file to upload";
    }
  });

  // Form validation
  function validateForm() {
    const submitBtn = document.getElementById("submitBtn");
    const phoneNumber = input.value.trim();
    if (!iti.isValidNumber()) {
      alert("❌ Please enter a valid phone number.");
      return false;
    }
    submitBtn.innerHTML = "Processing...";
    submitBtn.classList.add("loading");
    submitBtn.disabled = true;
    return true;
  }
</script>
</body>
</html>
