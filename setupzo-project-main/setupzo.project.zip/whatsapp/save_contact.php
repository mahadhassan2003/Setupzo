<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

// Database connection
$servername = "localhost"; // Hostinger pe usually localhost
$username = "u259563098_setupzo"; // Aapka MySQL user
$password = "Setupzo123"; // Jo password aapne MySQL user banate waqt diya
$dbname = "u259563098_setupzo"; // Aapka database name

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Form submission handler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
   $phone = $_POST['phone'] ?? '';
    $dialCode = $_POST['dial_code'] ?? '';
    $fullPhone = $dialCode . $phone;
    $email = $_POST['email'] ?? '';
    $comments = $_POST['comments'] ?? '';
    
    // Validate phone number
 

    // Validate email

    // Check for duplicate submission
    $check = $pdo->prepare("SELECT COUNT(*) FROM contact WHERE email = ? AND phone = ?");
    $check->execute([$email, $phone]);
    if ($check->fetchColumn() > 0) {
        echo "<script>alert('❌ You have already submitted this contact information!');</script>";
        exit;
    }

    // Insert into database
    try {
        $stmt = $pdo->prepare("INSERT INTO contact (name, phone, email, messsage) VALUES (:name, :phone, :email, :comments)");
        $stmt->execute([
            ':name' => $name,
            ':phone' => $fullPhone,
            ':email' => $email,
            ':comments' => $comments
        ]);
    } catch (PDOException $e) {
        echo "<script>alert('❌ Database error: " . addslashes($e->getMessage()) . "');</script>";
        exit;
    }

    // PHPMailer Configuration
    $smtpHost = 'smtp.gmail.com';
    $smtpUsername = 'info@setupzo.com';
    $smtpPassword = 'gupy jyfz qydd xzau';
    $fromEmail = 'info@setupzo.com';
    $fromName = 'Setup zo';
    $adminEmail = 'info@setupzo.com';

    // Send confirmation email to user
    try {
        $userMail = new PHPMailer(true);
        $userMail->isSMTP();
        $userMail->Host = $smtpHost;
        $userMail->SMTPAuth = true;
        $userMail->Username = $smtpUsername;
        $userMail->Password = $smtpPassword;
        $userMail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $userMail->Port = 465;

        $userMail->setFrom($fromEmail, $fromName);
        $userMail->addAddress($email, $name);
        $userMail->addReplyTo($fromEmail, $fromName);
        $userMail->isHTML(true);
        $userMail->Subject = 'Thank you for contacting us';
        $userMail->Body = "
            <h3>Dear $name,</h3>
            <p>Thank you for contacting Setup zoo. We have received your message and will get back to you soon.</p>
            <h4>Your message details:</h4>
            <ul>
                <li><strong>Name:</strong> $name</li>
                <li><strong>Phone:</strong> $fullPhone</li>
                <li><strong>Email:</strong> $email</li>
                <li><strong>Message:</strong> $comments</li>
            </ul>
            <p>We typically respond within 24-48 hours.</p>
            <p>Best regards,<br>Team Setup zo</p>
        ";
        $userMail->send();
    } catch (Exception $e) {
        error_log("User email failed: " . $userMail->ErrorInfo);
    }

    // Send notification email to admin
    try {
        $adminMail = new PHPMailer(true);
        $adminMail->isSMTP();
        $adminMail->Host = $smtpHost;
        $adminMail->SMTPAuth = true;
        $adminMail->Username = $smtpUsername;
        $adminMail->Password = $smtpPassword;
        $adminMail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $adminMail->Port = 465;

        $adminMail->setFrom($fromEmail, $fromName);
        $adminMail->addAddress($adminEmail, 'Admin');
        $adminMail->isHTML(true);
        $adminMail->Subject = 'New Contact Form Submission From Home Page';
        $adminMail->Body = "
            <h3>New Contact Request</h3>
            <p>You have received a new contact form submission:</p>
            <ul>
                <li><strong>Name:</strong> $name</li>
                <li><strong>Phone:</strong> $fullPhone</li>
                <li><strong>Email:</strong> $email</li>
                <li><strong>Message:</strong> $comments</li>
                <li><strong>Submitted:</strong> " . date('Y-m-d H:i:s') . "</li>
            </ul>
            <p>Please respond to this inquiry within 48 hours.</p>
        ";
        $adminMail->send();
    } catch (Exception $e) {
        error_log("Admin email failed: " . $adminMail->ErrorInfo);
    }

    // Success response
    sleep(2);
    echo "<script>alert('✅ Thank you for contacting us! A confirmation has been sent to your email.');</script>";
    exit;
}
?>