<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

// Database credentials
$servername = "localhost"; // Hostinger pe usually localhost
$username = "u259563098_setupzo"; // Aapka MySQL user
$password = "YOUR_PASSWORD_HERE"; // Jo password aapne MySQL user banate waqt diya
$dbname = "u259563098_setupzo"; // Aapka database name

// PDO connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Upload directory setup
$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// File upload handler
function handleFileUpload($inputName) {
    global $uploadDir;
    if (isset($_FILES[$inputName]) && $_FILES[$inputName]['error'] === UPLOAD_ERR_OK) {
        $tmpPath = $_FILES[$inputName]['tmp_name'];
        $fileName = time() . '_' . basename($_FILES[$inputName]['name']);
        $destination = $uploadDir . $fileName;
        if (move_uploaded_file($tmpPath, $destination)) {
            return $destination;
        }
    }
    return null;
}

// On form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $company = $_POST['company'] ?? '';
    $activity = $_POST['activity'] ?? '';

    // Duplicate email check
    $check = $pdo->prepare("SELECT COUNT(*) FROM cancellation WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetchColumn() > 0) {
        echo "<script>alert('An application with this email already submitted.Please try Some different Email adress.'); window.location.href = window.location.pathname;</script>";
        exit;
    }
    if (!preg_match('/^\+?[0-9]{7,15}$/', $phone)) {
    echo "<script>alert('Invalid phone number format. Please enter 7 to 15 digits, optionally starting with +'); window.location.href = window.location.pathname;</script>";
    exit;
}

    // File uploads
    $license = handleFileUpload('lic_copy');
    $moa = handleFileUpload('moa');
    $emiratesIdPath = handleFileUpload('emirates_id');
    $passportPath = handleFileUpload('passport_copy');

    // Database insert
    $stmt = $pdo->prepare("INSERT INTO cancellation (name, email, phone, company, activity, lic_copy, Moa, emirates_id_file, passport_copy) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $fullname,
        $email,
        $phone,
        $company,
        $activity,
        $license,
        $moa,
        $emiratesIdPath,
        $passportPath
    ]);

    // Email sending
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'info@setupzo.com';         // Your Gmail address
        $mail->Password = 'gupy jyfz qydd xzau';          // App-specific password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom('info@setupzo.com', 'Setup zo');
        $mail->isHTML(true);
 $email = $_POST['email'] ?? '';
        // ✅ Send to user
        $mail->addAddress($email);
        $mail->Subject = 'Application Received For Cancellation Services';
        $mail->Body = "
            <h3>Dear $fullname,</h3>
            <p>Thank you for your application to <strong>$company</strong>.</p>
            <p>We have received your details and documents. We will get back to you shortly.</p>
            <p>Best regards,<br>Your Business Team</p>
        ";
        $mail->send();

        // ✅ Send to admin
        $mail->clearAddresses();
        $mail->addAddress('info@setupzo.com', 'Admin');
        $mail->Subject = 'New Application Received';
        $mail->Body = "
            <h3>New Application Details</h3>
            <ul>
                <li><strong>Name:</strong> $fullname</li>
                <li><strong>Email:</strong> $email</li>
                <li><strong>Phone:</strong> $phone</li>
                <li><strong>Company:</strong> $company</li>
                <li><strong>Activity:</strong> $activity</li>
            </ul>
        ";
        if ($license) $mail->addAttachment($license, 'License');
        if ($moa) $mail->addAttachment($moa, 'MOA');
        if ($emiratesIdPath) $mail->addAttachment($emiratesIdPath, 'Emirates ID');
        if ($passportPath) $mail->addAttachment($passportPath, 'Passport');
        $mail->send();

        // ✅ Success message
        echo "<script>alert('✅ Application Submitted Successfully!'); window.location.href = window.location.pathname;</script>";
        exit;

    } catch (Exception $e) {
        echo "<script>alert('❌ Email could not be sent. Error: " . addslashes($mail->ErrorInfo) . "');</script>";
    }
}
?>


<!-- ✅ Example Form (can be in same file or separate HTML) -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Full Form Page</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.css" />
  <style>
    html, body {
      height: 100%;
      background: #f5f5f5;
      margin: 0;
      padding: 0;
    }

    .form-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .form-box {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      width: 100%;
    
    }
.drop-zone {
  width: 100%;
  height: 100px;
  border: 2px dashed #aaa;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 10px;
  cursor: pointer;
  user-select: none;
  border-radius:15px;
}
.drop-zone.dragover {
  border-color: #333;
  background-color: #eee;
}
.file-name {
  font-size: 14px;
  color: #555;
  pointer-events: none;
}

    /* New styles for phone input */
    .phone-input-container {
      width: 100%;
    }
    
    .iti {
      width: 100% !important;
    }
    
    .iti__selected-flag {
      padding: 0 6px 0 8px;
    }
    
    .iti__flag-container {
      width: 46px;
    }
    
    .iti input {
      width: 100% !important;
      padding-left: 60px !important;
    }
        * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 80vh; /* 80% of viewport height */
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Image covers full area */
      display: block;
    }
  </style>
</head>
<body>
<div class="image-container">
    <img src="uploads/mainland.webp" class="img-fluid" alt="Full Cover Image">
  </div>
<div class="col-lg-9 col-md-9 col-sm-10 mx-auto mt-5 my-5">
  <form class="form-box mx-auto" action="cancellation.php" method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label for="fullname" class="form-label">Full Name as per Passport</label>
      <input type="text" class="form-control form-control-lg" name="fullname" id="fullname" required>
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control form-control-lg" name="email" id="email" required>
    </div>

    <div class="mb-3 phone-input-container">
      <label for="phone" class="form-label">Phone Number</label>
      <input type="tel" class="form-control form-control-lg"  pattern="^\+?[0-9]{7,15}$" title="Enter a valid phone number (7 to 15 digits, optional +) name="phone" id="phone" required>
    </div>

    <div class="mb-3">
      <label for="company" class="form-label">License Freezone</label>
      <select name="company" id="company" class="form-select form-control-lg" required>
        <option value="">Select Company</option>
        <option value="IFZA">Mainland</option>
        <option value="RAKEZ">Freezone</option>
      </select>
    </div>
     <div class="mb-3 phone-input-container">
      <label for="phone" class="form-label">Activity</label>
      <input type="text" class="form-control form-control-lg" name="activity" required>
    </div>
    <label for="upload passport">Uplaod Your License Copy</label>
    <br><br>
<div class="drop-zone">
  <span class="file-name">Uplaod Your License Copy</span>
  <input type="file" name="lic_copy" hidden />
</div>
<label for="upload passport">Upload MOA</label>
<br><br>
<div class="drop-zone">
  <span class="file-name">Uplaod MOA</span>
  <input type="file" name="moa" hidden />
</div>
<label for="upload passport">Emirates ID of Shareholder</label>
<br><br>
<div class="drop-zone">
  <span class="file-name">Upload Emirates ID If have or visit visa</span>
  <input type="file" name="emirates_id" hidden />
</div>
<label for="upload passport">Passport Copy of Shareholder</label>
<br><br>
<div class="drop-zone">
  <span class="file-name">Passport Copy of Shareholdera</span>
  <input type="file" name="passport_copy" hidden />
</div>


   <div class="mb-3">
  <button type="submit" class="btn btn-primary btn-lg w-100">Submit</button>
</div>

  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>
<script>
  const phoneInput = document.querySelector("#phone");
  const iti = window.intlTelInput(phoneInput, {
    // your options here
    initialCountry: "auto",
    geoIpLookup: function(callback) {
      fetch('https://ipinfo.io/json')
        .then(resp => resp.json())
        .then(data => callback(data.country))
        .catch(() => callback('us'));
    },
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js",
    separateDialCode: false,
    preferredCountries: ['ae', 'us', 'gb', 'in', 'pk'],
    autoPlaceholder: "aggressive",
    customPlaceholder: function(selectedCountryPlaceholder, selectedCountryData) {
      return selectedCountryPlaceholder.replace(/[0-9]/g, 'x');
    },
  });

  // Auto open dropdown on focus
  phoneInput.addEventListener("focus", function () {
    const flagContainer = phoneInput.parentNode.querySelector(".iti__flag-container");
    if (flagContainer) flagContainer.click();
  });document.querySelectorAll('.drop-zone').forEach(dropZone => {
  const fileInput = dropZone.querySelector('input[type="file"]');
  const fileNameDisplay = dropZone.querySelector('.file-name');

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      fileNameDisplay.textContent = e.dataTransfer.files[0].name;
    }
  });

  // Clear input value on click, before file dialog opens
  fileInput.addEventListener('click', (e) => {
    e.target.value = '';
  });

  dropZone.addEventListener('click', () => {
    fileInput.click();
  });

  fileInput.addEventListener('change', () => {
    if (fileInput.files.length > 0) {
      fileNameDisplay.textContent = fileInput.files[0].name;
    } else {
      fileNameDisplay.textContent = 'No file chosen';
    }
  });
});


</script>
</body>
</html>