<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Blog Posts - Table View</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@300;400;600&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
        }
        .heading {
            font-family: 'Playfair Display', serif;
        }
    </style>
</head>
<body class="bg-gray-100 py-10 px-4">
    <div class="max-w-7xl mx-auto">
        <h1 class="heading text-4xl text-center font-bold text-gray-800 mb-8">All Blog Posts</h1>

        <div class="overflow-auto rounded-lg shadow-md bg-white">
            <table class="min-w-full text-sm text-left text-gray-700">
                <thead class="bg-indigo-600 text-white uppercase text-xs tracking-wider">
                    <tr>
                        <th class="px-6 py-3">#</th>
                        <th class="px-6 py-3">Title</th>
                        <th class="px-6 py-3">Author</th>
                        <th class="px-6 py-3">Email</th>
                        <th class="px-6 py-3">Category</th>
                        <th class="px-6 py-3">Tags</th>
                        <th class="px-6 py-3">Date</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php
            // DB connection
      $servername = "localhost"; // Hostinger pe usually localhost
$username = "u259563098_setupzo"; // Aapka MySQL user
$password = "Setupzo123"; // Jo password aapne MySQL user banate waqt diya
$dbname = "u259563098_setupzo"; // Aapka database name

                    try {
                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        $stmt = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
                        $blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        if (count($blogs) === 0) {
                            echo '<tr><td colspan="7" class="px-6 py-4 text-center text-gray-500">No blog posts found.</td></tr>';
                        } else {
                            $count = 1;
                            foreach ($blogs as $blog) {
                                echo "<tr class='hover:bg-gray-100'>";
                                echo "<td class='px-6 py-4'>{$count}</td>";
                                echo "<td class='px-6 py-4 font-medium text-indigo-700'>" . htmlspecialchars($blog['title']) . "</td>";
                                echo "<td class='px-6 py-4'>" . htmlspecialchars($blog['author']) . "</td>";
                                echo "<td class='px-6 py-4'>" . htmlspecialchars($blog['email']) . "</td>";
                                echo "<td class='px-6 py-4'>" . htmlspecialchars($blog['category']) . "</td>";
                                echo "<td class='px-6 py-4 text-sm text-gray-600'>" . htmlspecialchars($blog['tags']) . "</td>";
                                echo "<td class='px-6 py-4 text-sm'>" . date("M d, Y", strtotime($blog['created_at'])) . "</td>";
                                echo "</tr>";
                                $count++;
                            }
                        }
                    } catch (PDOException $e) {
                        echo "<tr><td colspan='7' class='px-6 py-4 text-red-500'>Database error: " . $e->getMessage() . "</td></tr>";
                    }

                    $conn = null;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
