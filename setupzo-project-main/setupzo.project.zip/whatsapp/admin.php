<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Navbar</title>
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .navbar-brand img {
      height: 40px;
      width: 40px;
      object-fit: cover;
    }
    .dropdown-menu {
      background-color: #AF47D2;
      border: none;
    }
    .dropdown-item {
      color: white !important;
      padding: 8px 16px;
    }
    .dropdown-item:hover, .dropdown-item:focus {
      background-color: #9c3cbf !important;
    }
    .nav-link {
      color: white !important;
      padding: 8px 15px;
    }
    .nav-link:hover, .nav-link:focus {
      color: #f0f0f0 !important;
    }
    .navbar-toggler {
      border-color: white !important;
    }
    .navbar-toggler-icon {
      background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 1%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
    }
    .navbar {
      background-color: #1e2355  !important;
      padding: 0.5rem 1rem;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
  <div class="container">
    <!-- Brand/Logo -->
    <a class="navbar-brand d-flex align-items-center" href="contact_admin.php">
      <img src="img/logo3.png" alt="Logo" class="me-2">
    </a>

    <!-- Mobile Toggle -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" 
      aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navbar Content -->
    <div class="collapse navbar-collapse" id="adminNavbar">
      <ul class="navbar-nav me-auto mx-auto">
        <li class="nav-item">
          <a class="nav-link" href="contact_admin.php">Home</a>
        </li>
        
        <!-- Visa Services Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="visaDropdown" role="button" 
             data-bs-toggle="dropdown" aria-expanded="false">
            Visa Services
          </a>
          <div class="dropdown-menu" aria-labelledby="visaDropdown">
            <a class="dropdown-item" href="mainland_admin.php">Mainland</a>
            <a class="dropdown-item" href="freezone_admin.php">Freezone</a>
            <a class="dropdown-item" href="residence_admin.php">Residence Visa</a>
            <a class="dropdown-item" href="golden_admin.php">Golden Visa</a>
            <a class="dropdown-item" href="freelance_admin.php">Freelance Visa</a>
            <a class="dropdown-item" href="empolyee_admin.php">Employee Visa</a>
          </div>
        </li>
        
        <!-- Other Services Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="servicesDropdown" role="button" 
             data-bs-toggle="dropdown" aria-expanded="false">
            Other Services
          </a>
          <div class="dropdown-menu" aria-labelledby="servicesDropdown">
            <a class="dropdown-item" href="payroll_admin.php">Payroll</a>
            <a class="dropdown-item" href="vat_admin.php">Vat Corporate</a>
            <a class="dropdown-item" href="compilance_admin.php">Compilance</a>
            <a class="dropdown-item" href="health_admin.php">Health</a>
            <a class="dropdown-item" href="police_admin.php">Police Clearance</a>
            <a class="dropdown-item" href="dm_admin.php">DM Approval</a>
            <a class="dropdown-item" href="emirates_admin.php">Emirates ID Updates</a>
          </div>
        </li>
        
        <!-- Company Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="companyDropdown" role="button" 
             data-bs-toggle="dropdown" aria-expanded="false">
            Company
          </a>
          <div class="dropdown-menu" aria-labelledby="companyDropdown">
            <a class="dropdown-item" href="shareholder_admin.php">Shareholder</a>
            <a class="dropdown-item" href="manager_admin.php">Manager</a>
          </div>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="contactus_admin.php">Contact Us</a>
        </li
                <li class="nav-item">
          <a class="nav-link" href="bank_account_admin.php">Bank Application</a>
        </li>
                        <li class="nav-item">
          <a class="nav-link" href="blogs_admin.php">Blogs</a>
        </li>
          <li class="nav-item">
           <a href="logout.php" class="nav-link">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- JavaScript at bottom of body -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Initialize dropdowns explicitly
  document.addEventListener('DOMContentLoaded', function() {
    var dropdownElements = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
    dropdownElements.forEach(function(dropdownToggleEl) {
      var dropdown = new bootstrap.Dropdown(dropdownToggleEl);
    });
  });
</script>

</body>
</html>