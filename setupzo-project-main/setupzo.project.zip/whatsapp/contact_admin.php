<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$con = mysqli_connect("localhost", "u259563098_setupzo", "Setupzo123", "u259563098_setupzo");
if (!$con) {
    die("DB Connection failed: " . mysqli_connect_error());
}

// Handle search
$searchQuery = "";
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $con->real_escape_string($_GET['search']);
    $searchQuery = "WHERE fullname LIKE '%$searchTerm%' OR email LIKE '%$searchTerm%' OR phone LIKE '%$searchTerm%' OR message LIKE '%$searchTerm%'";
}

// Handle multi-delete POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_selected'])) {
    if (!empty($_POST['selected_ids'])) {
        $ids = array_map('intval', $_POST['selected_ids']);
        $id_list = implode(',', $ids);
        $con->query("DELETE FROM contact WHERE id IN ($id_list)");
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Handle single delete via GET id
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $con->query("DELETE FROM contact WHERE id=$id");
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

// Fetch all data ordered by created_At descending
$result = $con->query("SELECT * FROM contact $searchQuery ORDER BY submitted_at DESC");

// Group data by date
$dataByDate = [];
while ($row = $result->fetch_assoc()) {
    $date = date('Y-m-d', strtotime($row['submitted_at']));
    $dataByDate[$date][] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home Page Submissions</title>
  <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
<style>
    h3.date-heading {
        margin-top: 2rem;
        margin-bottom: 1rem;
        border-bottom: 2px solid #0d6efd;
        padding-bottom: 0.25rem;
    }
    .action-buttons {
        white-space: nowrap;
    }
    .table-responsive {
        overflow-x: auto;
    }
    thead tr th{
    background-color: #1e2355 !important;
    color: white !important;
}
</style>
</head>
<body style="font-family:times-new-roman">
    <?php include_once("navbar2.php") ?>
<div class="container mt-4">
    <h1>Home Page Contact Submissions</h1>
    
    <!-- Search Form -->
    <form method="get" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by name, email, phone or message..." 
                   value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button class="btn btn-outline-primary" type="submit">Search</button>
            <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
                <a href="<?= strtok($_SERVER['REQUEST_URI'], '?') ?>" class="btn btn-outline-danger">Clear</a>
            <?php endif; ?>
        </div>
    </form>
    
    <form method="post" id="multiDeleteForm">
        <div class="mb-3">
            <button type="submit" name="delete_selected" class="btn btn-danger" onclick="return confirm('Delete selected records?')">
                <i class="bi bi-trash-fill"></i> Delete Selected
            </button>
        </div>
        
        <?php if (empty($dataByDate)): ?>
            <div class="alert alert-info">No data found<?= isset($_GET['search']) ? ' matching your search' : '' ?>.</div>
        <?php else: ?>
            <?php foreach ($dataByDate as $date => $rows): ?>
                <h3 class="date-heading"><?= htmlspecialchars($date) ?></h3>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered align-middle">
                        <thead>
                            <tr>
                                <th width="40"><input type="checkbox" class="selectAll" data-date="<?= $date ?>" /></th>
                                <th>#</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Message</th>
                                <th>Time</th>
                                <th class="action-buttons">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; foreach ($rows as $row): ?>
                                <tr>
                                    <td><input type="checkbox" name="selected_ids[]" value="<?= $row['id'] ?>" data-date="<?= $date ?>" /></td>
                                    <td><?= $i++ ?></td>
                                    <td><?= htmlspecialchars($row['fullname'] ?? $row['name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['phone'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($row['message'] ?? $row['messsage'] ?? '') ?></td>
                                    <td><?= date('H:i', strtotime($row['submitted_at'])) ?></td>
                                    <td class="action-buttons">
                                        <div class="d-flex gap-1 btn-group">
                                            <!-- View Button -->
                                            <button type="button" 
                                                    class="btn btn-info btn-sm m-1"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#viewModal"
                                                    data-fullname="<?= htmlspecialchars($row['fullname'] ?? $row['name'] ?? '', ENT_QUOTES) ?>"
                                                    data-email="<?= htmlspecialchars($row['email'] ?? '', ENT_QUOTES) ?>"
                                                    data-phone="<?= htmlspecialchars($row['phone'] ?? '', ENT_QUOTES) ?>"
                                                    data-message="<?= htmlspecialchars($row['message'] ?? $row['messsage'] ?? '', ENT_QUOTES) ?>"
                                                    title="View details">
                                                <i class="bi bi-eye-fill"></i>
                                            </button>
                                            
                                            <!-- WhatsApp Button -->
                                            <a href="https://wa.me/<?= htmlspecialchars($row['phone'] ?? '') ?>?text=Hello%20<?= urlencode($row['fullname'] ?? $row['name'] ?? '') ?>,%20I%20am%20contacting%20you%20regarding%20your%20message:%20<?= urlencode($row['message'] ?? $row['messsage'] ?? '') ?>"
                                               target="_blank"
                                               class="btn btn-success btn-sm m-1"
                                               title="Send WhatsApp message">
                                                <i class="bi bi-whatsapp"></i>
                                            </a>
                                            
                                            <!-- Delete Button -->
                                            <a href="?delete_id=<?= $row['id'] ?>"
                                               onclick="return confirm('Are you sure you want to delete this record?');"
                                               class="btn btn-danger btn-sm m-1"
                                               title="Delete record">
                                                <i class="bi bi-trash-fill"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </form>
     <div class="me-2 text-end">
     <button class="btn btn-primary me-3" onclick="window.print()">🖨️ Print</button>
   </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="viewModalLabel">Submission Details</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label fw-bold">Full Name:</label>
          <p id="modalFullName" class="form-control-static"></p>
        </div>
        <div class="mb-3">
          <label class="form-label fw-bold">Email:</label>
          <p id="modalEmail" class="form-control-static"></p>
        </div>
        <div class="mb-3">
          <label class="form-label fw-bold">Phone:</label>
          <p id="modalPhone" class="form-control-static"></p>
        </div>
        <div class="mb-3">
          <label class="form-label fw-bold">Message:</label>
          <p id="modalMessage" class="form-control-static"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// View Modal Handler
document.getElementById('viewModal').addEventListener('show.bs.modal', function(event) {
    const button = event.relatedTarget;
    document.getElementById('modalFullName').textContent = button.getAttribute('data-fullname');
    document.getElementById('modalEmail').textContent = button.getAttribute('data-email');
    document.getElementById('modalPhone').textContent = button.getAttribute('data-phone');
    document.getElementById('modalMessage').textContent = button.getAttribute('data-message');
});

// Checkbox toggle by date group
document.querySelectorAll('.selectAll').forEach(cb => {
    cb.addEventListener('change', function() {
        const date = this.dataset.date;
        document.querySelectorAll(`input[type="checkbox"][data-date="${date}"]`).forEach(c => {
            c.checked = this.checked;
        });
    });
});

// Initialize tooltips
const tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
tooltipTriggerList.map(triggerEl => {
    return new bootstrap.Tooltip(triggerEl, {
        trigger: 'hover'
    });
});
</script>
<?php include_once("footer2.php") ?>
</body>
</html>