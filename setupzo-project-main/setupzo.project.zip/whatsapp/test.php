<?php
// DB connection
$host = 'localhost';
$user = 'root';         // your DB username
$pass = '';             // your DB password
$db   = 'dld'; // your DB name

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_form'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $conn->query("INSERT INTO submissions (name, is_new) VALUES ('$name', 1)");
    $message = "Form submitted!";
}

// Handle badge clear
if (isset($_POST['clear_badge'])) {
    $conn->query("UPDATE submissions SET is_new = 0 WHERE is_new = 1");
    $message = "Badge cleared!";
}

// Get unread submission count
$result = $conn->query("SELECT COUNT(*) AS count FROM submissions WHERE is_new = 1");
$row = $result->fetch_assoc();
$newCount = $row['count'];

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form with Badge (MySQL)</title>
     <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
    <style>
        .badge {
            background: red;
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
        }
        .admin-panel {
            background: #f0f0f0;
            padding: 10px;
            margin-bottom: 20px;
        }
        form {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<!-- Admin Panel -->
<div class="admin-panel">
    <strong>Admin Panel:</strong>
    <span>New Applications:
        <?php if ($newCount > 0): ?>
            <span class="badge"><?php echo $newCount; ?></span>
        <?php else: ?>
            <span>No new submissions</span>
        <?php endif; ?>
    </span>

    <form method="POST" style="display:inline;">
        <button type="submit" name="clear_badge">Clear Badge</button>
    </form>
</div>

<!-- Message -->
<?php if (isset($message)): ?>
    <p><strong><?php echo $message; ?></strong></p>
<?php endif; ?>

<!-- Submission Form -->
<h3>Submit Form</h3>
<form method="POST">
    <input type="text" name="name" placeholder="Enter your name" required>
    <button type="submit" name="submit_form">Submit</button>
</form>

</body>
</html>