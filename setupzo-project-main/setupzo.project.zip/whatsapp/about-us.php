<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Setupzo – Expert Business Setup in Dubai, UAE</title>
  <meta name="description" content="Setupzo is your trusted partner for business setup in Dubai. We handle mainland & free zone company formation, registration, and visa services with simplicity.">
  <!-- ✅ Favicon Logo -->
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96" />
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg" />
  <link rel="shortcut icon" href="img/favicon.ico" />
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png" />
  <link rel="manifest" href="img/site.webmanifest" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  
  
  <style>
    .hero {
      min-height: 90vh;
      background-image: url('img/dubai.jpg');
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
      position: relative;
      display: flex;
      align-items: center;
    }
    h2 {
      text-align: justify;
      font-weight: 800;
    }
    p {
      text-align: justify;
    }
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, rgba(10, 77, 128, 0.85) 0%, rgba(10, 77, 128, 0.2) 50%, rgba(10, 77, 128, 0.85) 100%);
    }
    .hero-text {
      position: relative;
      color: white;
      text-align: justify;
      z-index: 2;
    }
    .hero-text h4 {
      font-size: 5rem;
      font-weight: 600;
    }
    .hero-text p {
      font-size: 1.3rem;
      font-weight: 700;
    }
    @media (max-width: 768px) {
      .hero-text h4 { font-size: 1.5rem; }
      .hero-text p { font-size: 0.95rem; }
    }
    @media (max-width: 576px) {
      .hero-text h4 { font-size: 1.3rem; }
      .hero-text p { font-size: 0.9rem; }
    }

    /* New Cards Styles */
    .info-card {
      display: flex;
      align-items: center;
      background: #fff;
      border-radius: 1rem;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      overflow: hidden;
      margin-bottom: 20px;
      min-height: 200px;
      transition: transform 0.3s ease;
      position: relative;
    }
    .info-card:hover { transform: translateY(-5px); }
    .info-icon {
      flex: 0 0 140px;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      color: #fff;
    }
    .info-content {
      padding: 25px;
      flex: 1;
    }
    .info-content h4 {
      color: #243378;
      font-weight: 700;
      margin-bottom: 12px;
    }
    .info-content p {
      margin: 0;
      color: #555;
      font-size: 1rem;
      line-height: 1.5;
    }
    .left-rounded {
      border-top-left-radius: 100px;
      border-bottom-left-radius: 100px;
    }
    .right-rounded {
      border-top-right-radius: 100px;
      border-bottom-right-radius: 100px;
    }
    .bg-blue { background: #0088B4; }
    .bg-red { background: #D92027; }
    .bg-yellow { background: #F4A52E; }
    .bg-darkblue { background: #004A8D; }
    @media (max-width: 768px) {
      .info-card {
        flex-direction: column;
        text-align: center;
      }
      .info-icon {
        width: 100%;
        height: 120px;
      }
      .left-rounded, .right-rounded { border-radius: 0; }
    }
    
    /*simple*/
      @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0px);
      }
    }
.w-90 {
      width: 90%;
    }
    h2 {
        text-align: justify;
        font-size: 20px;
        
    }
    h5 {
         text-align: justify;
         font-size: 15px;
    }
  </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<!-- Hero Section -->
<section>
  <div class="hero">
    <div class="overlay"></div>
    <div class="container hero-text">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10 col-11">
          <!-- Optional Hero Text -->
        </div>
      </div>
    </div>
  </div>
</section>

<div class="container mt-6">
  <h1 style="font-weight:600;">About Setupzo</h1>
</div>

<!-- About Section -->
<section class="pt-4">
  <div class="container">
    <h4 class="mb-4">About Setupzo</h4>
    <p>
      At Setupzo, we specialize in making business setup in Dubai, UAE simple, fast, and fully compliant. Whether you’re starting fresh with a new company formation or expanding into Dubai’s thriving market, we guide you every step of the way — from company registration and licensing to visa processing — so you can focus on your business growth.<br>
      Our mission is to help entrepreneurs, investors, and companies of all sizes unlock the endless opportunities that Dubai offers.
    </p>
  </div>
</section>

<!-- Mission & Vision New Cards -->
<div class="container py-5 bg-light">
  <div class="row">

    <!-- Our Mission -->
    <div class="col-md-6 d-flex">
      <div class="info-card w-100">
        <div class="info-icon bg-blue left-rounded">
          <svg width="50" height="50" fill="none" viewBox="0 0 24 24" stroke="white" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 6v6l4 2"/>
          </svg>
        </div>
        <div class="info-content">
          <h4>Who We Are</h4>
          <p>Setupzo has one clear vision is to remove the complexity from starting a business in Dubai. We saw too many investors struggling with paperwork, regulations, and unclear procedures, so we created a consultancy that puts clarity, transparency, and speed first. We set up your business in the UAE with zero hassle.
We believe that the right start leads to lasting success, and that’s why we don’t just process documents — we become your strategic partner from day one.

</p>
        </div>
      </div>
    </div>

    <!-- Our Vision -->
    <div class="col-md-6 d-flex">
      <div class="info-card w-100 flex-row-reverse">
        <div class="info-icon bg-red right-rounded">
          <svg width="50" height="50" fill="none" viewBox="0 0 24 24" stroke="white" stroke-width="2">
            <path d="M12 2a7 7 0 00-7 7c0 2.5 1.5 4.5 3 6v3h8v-3c1.5-1.5 3-3.5 3-6a7 7 0 00-7-7z"/>
            <path d="M10 22h4"/>
          </svg>
        </div>
        <div class="info-content">
          <h4>Our Team & Expertise</h4>
          <p>Setupzo has a team of experienced Dubai business setup consultants who have helped hundreds of entrepreneurs launch successfully. Our consultants are registered with relevant authorities and stay up-to-date on the UAE’s ever-changing business regulations.
We combine local knowledge with global business insight, ensuring that you not only meet all legal requirements but also position your company for long-term success.

</p>
        </div>
      </div>
    </div>

    <!-- Our Values -->
    <div class="col-md-6 d-flex">
      <div class="info-card w-100">
        <div class="info-icon bg-yellow left-rounded">
          <svg width="50" height="50" fill="none" viewBox="0 0 24 24" stroke="white" stroke-width="2">
            <path d="M4 12h4l2-4 2 8 2-6 2 6h4"/>
          </svg>
        </div>
        <div class="info-content">
          <h4>Our Commitment to Compliance & Quality</h4>
          <p>We operate with complete transparency and full compliance with UAE laws. At Setupzo, we work closely with the Department of Economic Development (DED), various free zone authorities, and other government entities to ensure your company is legally registered and ready to operate.
Every step we take is aimed at protecting your investment and helping you grow with confidence.
</p>
        </div>
      </div>
    </div>

    <!-- Company Culture -->
    <div class="col-md-6 d-flex">
      <div class="info-card w-100 flex-row-reverse">
        <div class="info-icon bg-darkblue right-rounded">
          <svg width="50" height="50" fill="none" viewBox="0 0 24 24" stroke="white" stroke-width="2">
            <circle cx="12" cy="8" r="3"/>
            <path d="M4 20c0-4 4-6 8-6s8 2 8 6"/>
          </svg>
        </div>
        <div class="info-content">
          <h4>Company Culture</h4>
          <p>We foster a culture of innovation where new ideas are encouraged and valued.
Collaboration is at the core, ensuring every team member’s voice matters.
Diversity drives our strength, bringing together unique perspectives and talents.
With integrity and dedication, we focus on delivering lasting value to our clients.</p>
        </div>
      </div>
    </div>
    

  </div>
</div>
<div class="container-fluid py-5 bg-light">
  <div class="w-90 mx-auto ">
    
    <!-- Heading -->
    <!--<h2><b>Company Formation & Registration Services in Dubai, UAE</b></h2>-->
    <!--<p class="mb-5" style="  text-align: justify;">-->
    <!--  At Setupzo, we specialize in complete company formation and registration services in Dubai, UAE, making the process seamless for both local entrepreneurs and foreign investors. Whether you need a mainland business setup, a free zone company formation, or help with company registration in Dubai, UAE, we handle everything from start to finish.-->
    <!--</p>-->
    <!--<h2 style="text-align:center"> <b>Our services include:</b></h2> <br>-->
    
    <!-- Cards Row -->
    <div class="row g-4">
      
      <!-- Card 1 -->
      <div class="col-md-6 col-lg-6 col-12"style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
          
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5> <b>What We Do</b></h5>
            <p style=" text-align: justify; ">We provide end-to-end business setup services for individuals and companies worldwide who want to establish a presence in Dubai. Our core services include:   
              <ul>
           <li>	Mainland Business Setup in Dubai, UAE – Full access to the UAE market with flexible business activities.</li>             
           <li>	Free Zone Company Formation in Dubai, UAE – 100% ownership, tax benefits, and industry-specific opportunities.</li>
           <li> Company Registration in Dubai, UAE – From trade name reservation to license issuance.</li>
           <li>	Dubai Business Visa Setup – Streamlined visa services for you and your employees.</li>
           <li>	Business Consultation in Dubai, UAE – Guidance on legal structures, market entry strategies, and cost optimization.</li>
           
           
       </ul>
       We don’t believe in a one-size-fits-all approach. Every business is unique, so we craft tailored solutions that align with your goals and budget.
       </p>
          </div>
        </div>
      </div>
      
      <!-- Card 2 -->
      <div class="col-md-6 col-lg-6 col-12"style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
          
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5><b>Why Choose Setupzo for Company Formation in Dubai, UAE</b> </h5>
            <p class="card-text" style=" text-align: justify;">When it comes to company formation in Dubai, UAE, you have plenty of options. But here’s why clients choose Setupzo:
             <ul>
           <li>	Local Expertise – We know UAE business laws and mainland, free zone regulations inside out.</li>             
           <li>	Transparent Pricing – No hidden charges, no last-minute surprises.</li>
           <li>	Fast Process – Get your business license in days, not weeks.</li>
           <li>	Global Reach – We work with entrepreneurs and corporations from over 30 countries.</li>
           <li>	Personal Support – One dedicated consultant for your entire process.</li>
           <li>	Our clients trust us because we focus on results — not just paperwork.</li>
       </ul>
        We guide you in choosing the right free zone for your goals – whether it’s JAFZA, DMCC, IFZA, or others.</p>
            
          </div>
        </div>
      </div> <br>
      
       <!-- Card 4 -->
      <div class="col-md-6 col-lg-6 col-12" style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
         
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5><b>Our Process</b></h5>
            <p class="card-text" style=" text-align: justify;">Starting your business setup in Dubai, UAE, with Setupzo is simple:
            <ul>
               <li>	Consultation – We discuss your goals and recommend the right setup option.</li>
               <li>	Choose Mainland or Free Zone – Based on your activity, budget, and market reach.</li>
               <li>	Company Registration – We handle trade name approval, licensing, and documentation.</li>
               <li>	Visa & Bank Account Setup – So you can start operations without delays.</li>
               <li>	Ongoing Support – We assist with renewals, compliance, and expansion.</li>
       </ul>
          </div>
        </div>
      </div>
      
      <!-- Card 3 -->
      <div class="col-md-6 col-lg-6 col-12" style="margin-top:10px;">
        <div class="card h-100 shadow-sm">
          
          <div class="card-body" style="background-color:#E4E5E8;">
            <h5><b>What We Offer</b></h5>
            <p class="card-text" style=" text-align: justify;"> 
             <ul>
                 
             <li>1.	Company Formation/Registration</li>
             <li>2.	Company License Renewals</li>
             <li>3.	UAE Local Sponsorship Services</li>
            <li>4.	Visa Services</li>
            <li>5.	Corporate PRO Services</li>
            <li>6.	Document Clearing Services</li>
            <li>7.	Accounting and Bookkeeping Services</li>
            <li>8.	External Audit Services</li>
             <li>9.	Internal Audit Services</li>
             <li>10.	Trademark Registration Services</li>
            <li>11.	Economic Substance Regulation Services</li>
            <li>12.	Ultimate Beneficial Owner Disclosure Services</li>
            <li>13.	VAT Registration and Consultation Services</li>
            <li>14.	AML Regulations</li>

           
       </ul>
       </p>
          
          </div>
        </div>
      </div>
      <section class="py-5 bg-light" id="testimonials">
  
    <div class="text-center mb-4">
      <h2 class="fw-bold mb-2">What Our Clients Say</h2>
      <p >We value our clients' feedback and success stories</p>
    </div>

    <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
      <!-- Indicators -->
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="0" class="active" aria-current="true"></button>
        <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="2"></button>
      </div>

      <!-- Carousel inner -->
      <div class="carousel-inner">

        <!-- Item 1 -->
        <div class="carousel-item active">
          <div class="card border-0 shadow-sm rounded-4 mx-auto" style="max-width: 700px;">
            <div class="card-body text-center p-4">
              
              <h5 class="mb-0">Ahmed R.</h5>
              
              <p class="mb-0 text-secondary">
               Setupzo made my Dubai business setup so easy. They handled everything, and I was operational within a week.
              </p>
              <div class="mt-2 text-warning">★★★★★</div>
            </div>
          </div>
        </div>

        <!-- Item 2 -->
        <div class="carousel-item">
          <div class="card border-0 shadow-sm rounded-4 mx-auto" style="max-width: 700px;">
            <div class="card-body text-center p-4">
             
              <h5 class="mb-0">Omar Siddiqui</h5>
             
              <p class="mb-0 text-secondary">
               I wanted a free zone company and had no idea where to start. Setupzo guided me through every step and saved me so much time.
              </p>
              <div class="mt-2 text-warning">★★★★★</div>
            </div>
          </div>
        </div>

        <!-- Item 3 -->
        <div class="carousel-item">
          <div class="card border-0 shadow-sm rounded-4 mx-auto" style="max-width: 700px;">
            <div class="card-body text-center p-4">
              
              <h5 class="mb-0">Maria Lopez</h5>
             
              <p class="mb-0 text-secondary">
                From consultation to company formation, everything was handled with utmost professionalism and care.
              </p>
              <div class="mt-2 text-warning">★★★★☆</div>
            </div>
          </div>
        </div>

      </div>

      <!-- Controls -->
      <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </div>
</section>
<div class="container">
    <h1 style="text-align:center;">FAQs</h1>
    <h4>How Can We Help You?</h4>
    <p>
    If you have any questions or concerns, our team of professionals is prepared to help. Share your goals, and we’ll help you achieve them.
    </p>
    
</div>
      
      
      
 
   
</div>
</div>
</div>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
