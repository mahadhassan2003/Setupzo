
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Setup Zo | Our Services</title>
     <!-- ✅ Favicon Logo -->
  <link rel="icon" type="image/png" href="img/ahmer-setupzoo-again.png" />


      <link rel="icon" href="img/ahmer-setupzoo-again.png" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/ahmer-setupzoo-again.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/ahmer-setupzoo-again.png">
  <link rel="apple-touch-icon" sizes="180x180" href="img/ahmer-setupzoo-again.png">
  <link rel="manifest" href="img/ahmer-setupzoo-again.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  <style>
    /*.navbar {*/
    /*  background: rgba(255, 255, 255, 0.3);*/
    /*  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);*/
    /*  backdrop-filter: blur(5.2px);*/
    /*  -webkit-backdrop-filter: blur(5.2px);*/
    /*}*/

    /*.nav-link {*/
    /*  color: #1e2355 !important;*/
    /*  font-weight: bold !important;*/
    /*}*/

    /* .mega-dropdown {*/
    /*  width: 100vw;*/
    /*  left: 0;*/
    /*  top: 100%;*/
    /*  position: absolute;*/
    /*  background: #fff;*/
    /*  padding: 30px;*/
    /*  display: none;*/
    /*  z-index: 9999;*/
    /*  box-shadow: 0 8px 20px rgba(0,0,0,0.1);*/
    /*  animation: fadeInDown 0.3s ease-in-out;*/
    /*}*/

    /*.mega-dropdown .dropdown-item {*/
    /*  font-weight: 500;*/
    /*  color: #1e2355;*/
    /*  transition: 0.3s;*/
    /*  white-space: nowrap;*/
    /*}*/

    /*.mega-dropdown .dropdown-item:hover {*/
    /*  background-color: #1e2355;*/
    /*  color: white;*/
    /*  padding-left: 10px;*/
    /*}*/

    /*.mega-dropdown h6 {*/
    /*  margin-bottom: 12px;*/
    /*  font-size: 14px;*/
    /*  color: #1e2355;*/
    /*  border-bottom: 1px solid #eee;*/
    /*  padding-bottom: 6px;*/
    /*}*/

    /*@keyframes fadeInDown {*/
    /*  from {*/
    /*    opacity: 0;*/
    /*    transform: translateY(-10px);*/
    /*  }*/
    /*  to {*/
    /*    opacity: 1;*/
    /*    transform: translateY(0px);*/
    /*  }*/
    /*}*/

    /*@media (max-width: 991px) {*/
    /*  .mega-dropdown {*/
    /*    display: none !important;*/
    /*    overflow-x: auto !important;*/
    /*    white-space: nowrap !important;*/
    /*    padding: 15px;*/
    /*  }*/

    /*  .mega-dropdown.show {*/
    /*    display: block !important;*/
    /*  }*/

    /*  .mega-dropdown .row {*/
    /*    display: flex !important;*/
    /*    flex-wrap: nowrap !important;*/
    /*  }*/

    /*  .mega-dropdown .col-md-2 {*/
    /*    flex: 0 0 auto !important;*/
    /*    width: 250px !important;*/
    /*    display: inline-block;*/
    /*    white-space: normal;*/
    /*    margin-right: 20px;*/
    /*  }*/
    /*}*/
    /*body {*/
    /*  font-family: 'Segoe UI', sans-serif;*/
    /*  background-color: #f7f9fc;*/
    /*  color: #1e2355;*/
    /*}*/
    .section-title {
      font-weight: bold;
      font-size: 2rem;
      margin-bottom: 80px;
      text-align: center;
    }
    .service-box {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 15px;
      padding: 25px;
      margin-bottom: 30px;
      box-shadow: 0 0 20px rgba(0,0,0,0.05);
      transition: all 0.3s ease;
    }
    .service-box:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    .service-box h4 {
      font-weight: bold;
      color: #1e2355;
      margin-bottom: 15px;
    }
    .service-box p {
      font-size: 15px;
      line-height: 1.7;
    }
    .highlight {
      color: #1e2355;
      font-weight: bold;
    }
  </style>
</head>
<body>
 <!-- Navbar Start -->
 <?php include_once('navbar.php');
 ?>
<!--<nav class="navbar navbar-expand-lg fixed-top">-->
<!--  <div class="container">-->
<!--    <a class="navbar-brand" href="index.php">-->
<!--      <img src="img/ahmer-setupzoo-again.png" width="100" alt="logo">-->
<!--    </a>-->
<!--    <button class="navbar-toggler me-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">-->
<!--      <i class="fa-solid fa-bars" style="color: #1e2355; font-size: 30px;"></i>-->
<!--    </button>-->
<!--    <div class="collapse navbar-collapse" id="navbarNav">-->
<!--      <ul class="navbar-nav mx-auto">-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="business-setup-dubai">Home</a>-->
<!--        </li>-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="about-us">About-Us</a>-->
<!--        </li>-->
<!--        <li class="nav-item dropdown px-2 position-static">-->
<!--          <a class="nav-link dropdown-toggle" href="services.php" id="servicesDropdown">Services</a>-->
<!--          <button class="btn btn-sm btn-outline-primary d-lg-none my-2" id="toggleMegaMenu">-->
<!--            Show Services-->
<!--          </button>-->

<!--          <div class="dropdown-menu mega-dropdown" id="megaMenu">-->
<!--            <div class="row">-->
<!--              <div class="col-md-2">-->
<!--                <h6>Company Formation</h6>-->
<!--                <a class="dropdown-item" href="start-mainland-company-in-uae">Mainland</a>-->
<!--                <a class="dropdown-item" href="free-zone-company-uae">Free Zone</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Visa & Immigration</h6>-->
<!--                <a class="dropdown-item" href="uae-residence-visa">Residence Visa</a>-->
<!--                <a class="dropdown-item" href="uae-golden-visa">Golden Visa</a>-->
<!--                <a class="dropdown-item" href="services-freelance-visa-uae-dubai">Freelance Visa</a>-->
<!--                <a class="dropdown-item" href="bank_account_open.php">Bank Account Opening</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Financial Services</h6>-->
<!--                <a class="dropdown-item" href="payroll_page.php">Payroll</a>-->
<!--                <a class="dropdown-item" href="vat_service.php">Corporate Tax & VAT</a>-->
<!--                <a class="dropdown-item" href="compilance.php">Compliance</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Legal Services</h6>-->
<!--                <a class="dropdown-item" href="pro-services-dubai">PRO Services</a>-->
<!--                <a class="dropdown-item" href="will-preparation-uae">Will Preparation</a>-->
<!--                <a class="dropdown-item" href="trademark-vs-copyright-uae">Trademark & Copyright</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Additional Services</h6>-->
<!--                <a class="dropdown-item" href="health_insurance.php">Health Insurance</a>-->
<!--                <a class="dropdown-item" href="police_clearance.php">Police Clearance</a>-->
<!--                <a class="dropdown-item" href="dm_page.php">DM Approval</a>-->
<!--                <a class="dropdown-item" href="emirates_page.php">Emirates ID Update</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Nominee Services</h6>-->
<!--                <a class="dropdown-item" href="contact-us.php">Shareholder</a>-->
<!--                <a class="dropdown-item" href="contact-us.php">Manager</a>-->
<!--              </div>-->
<!--            </div>-->
<!--          </div>-->
<!--        </li>-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="#">Blog</a>-->
<!--        </li>-->
<!--        <li class="nav-item px-2">-->
<!--          <a class="nav-link" href="contact-us.php">ContactUs</a>-->
<!--        </li>-->
<!--      </ul>-->
<!--      <a href="contactus.php" class="btn text-white py-2 px-3 ms-lg-4" style="background-color: #1e2355;">Apply Now</a>-->
<!--    </div>-->
<!--  </div>-->
</nav> <br><br>
<!-- Navbar End -->
<div class="container py-5">
   <p class="text-center mb-5"><h2 class="section-title" style="  margin-bottom: 20px;">Our Services at <span class="highlight">Setupzo</span></h2>
  At <strong>Setupzo</strong>, we provide everything you need to grow your business in the UAE. With professionalism, transparency, and unmatched expertise we are your one stop solution for business success.</p>
  <div class="row">
    <div class="col-md-6 col-lg-4">
      <div class="service-box">
        <h4>Company Formation (Mainland / Free Zone)</h4>
        <p>We help you set up your business smoothly, whether its in a Mainland or Free Zone. Setupzo ensures all legal, structural, and licensing processes are handled quickly and efficiently so you can start operating with confidence.</p>
      </div>
    </div>
    <div class="col-md-6 col-lg-4">
      <div class="service-box">
        <h4>Visa & Immigration</h4>
        <p>Whether you're looking for a Residence Visa, Golden Visa, or Freelance Visa, Setupzo streamlines the process. We also assist in opening a business bank account everything to make your UAE journey easier and faster.</p>
      </div>
    </div>
    <div class="col-md-6 col-lg-4">
      <div class="service-box">
        <h4>Financial Services</h4>
        <p>We manage Payroll, Corporate Tax & VAT registration, and Compliance regulations for you. Our expert accountants ensure your business meets all UAE financial requirements without stress.</p>
      </div>
    </div>
    <div class="col-md-6 col-lg-4">
      <div class="service-box">
        <h4>Legal Services</h4>
        <p>From PRO services to Will Preparation and Trademark & Copyright registration Setupzo handles it all. Our legal team ensures you are protected legally while you grow.</p>
      </div>
    </div>
    <div class="col-md-6 col-lg-4">
      <div class="service-box">
        <h4>Additional Services</h4>
        <p>Need Health Insurance, Police Clearance, DM Approvals, or Emirates ID updates? We do it all under one roof fast and reliable. No long queues or confusion, just results.</p>
      </div>
    </div>
    <div class="col-md-6 col-lg-4">
      <div class="service-box">
        <h4>Nominee Services</h4>
        <p>Protect your privacy and business structure with our Nominee Shareholder & Manager services. Setupzo ensures your business remains safe, secure, and flexible.</p>
      </div>
    </div>
  </div>
  <div class="text-center mt-5">
    <h4 class="fw-bold mb-3">Why Choose <span class="highlight">Setup Zo</span>?</h4>
    <p class="lead">We are more than just a service provider we are your strategic partner. Trusted by hundreds of businesses across UAE, our commitment is to deliver transparency, speed, and success in every step of your business journey.</p>
  </div>
</div>

<div class="container py-5">
  <h2 class="text-center mb-4 fw-bold">Why Choose <span class="highlight">Setupzo</span>?</h2>
  <div class="row text-center">
    <div class="col-md-6 col-lg-3 mb-4">
      <i class="fas fa-briefcase fa-2x mb-3 text-primary"></i>
      <h5 class="fw-bold">Expert Team</h5>
      <p>Highly experienced professionals in legal, financial & business setup services.</p>
    </div>
    <div class="col-md-6 col-lg-3 mb-4">
      <i class="fas fa-bolt fa-2x mb-3 text-primary"></i>
      <h5 class="fw-bold">Fast Processing</h5>
      <p>Quick and hassle-free documentation & approvals.</p>
    </div>
    <div class="col-md-6 col-lg-3 mb-4">
      <i class="fas fa-shield-alt fa-2x mb-3 text-primary"></i>
      <h5 class="fw-bold">Reliable & Secure</h5>
      <p>Your data and business setup are 100% protected with confidentiality.</p>
    </div>
    <div class="col-md-6 col-lg-3 mb-4">
      <i class="fas fa-thumbs-up fa-2x mb-3 text-primary"></i>
      <h5 class="fw-bold">Customer Satisfaction</h5>
      <p>We go the extra mile to ensure your complete satisfaction and success.</p>
    </div>
  </div>
</div>

<div class="container py-5">
  <h2 class="text-center fw-bold mb-4" style="">What Our Clients Say</h2>
  <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active text-center">
        <blockquote class="blockquote">
          <p class="mb-4">Setupzo made our company registration process seamless and efficient. Highly recommended</p>
          <footer class="blockquote-footer">Ali Raza, <cite>Tech Innovators</cite></footer>
        </blockquote>
      </div>
      <div class="carousel-item text-center">
        <blockquote class="blockquote">
          <p class="mb-4">Visa services were unbelievably smooth Thank you Setupzo for all the support</p>
          <footer class="blockquote-footer">Sarah Khan, <cite>Startup Hub</cite></footer>
        </blockquote>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>
</div>

<div class="py-5 text-white text-center" style="background-color: #1e2355;">
  <h2 class="mb-3">Ready to Start Your Business Journey?</h2>
  <p class="mb-4">Let <strong>Setupzo</strong> handle everything from A to Z </p>
  <a href="contactus.php" class="btn btn-light px-4 py-2 fw-bold">Apply Now</a>
</div>

<div class="container py-5">
  <h2 class="text-center mb-4 fw-bold">Frequently Asked Questions</h2>
  <div class="accordion" id="faqAccordion">
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
          What is the process to set up a company in UAE?
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          Setupzo guides you through choosing the right license type, legal structure, documentation, and approvals required all managed smoothly by our experts.
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
          How long does it take to get a UAE Residence Visa?
        </button>
      </h2>
      <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          It usually takes 5–10 working days after submission. Setupzo ensures your visa process is fast and free from delays.
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingThree">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
          Can I open a bank account with Setupzo's help?
        </button>
      </h2>
      <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          Yes! We assist in choosing the right bank, preparing documents, and scheduling appointments to make it stress-free.
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingFour">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour">
          What makes Setupzo different from other providers?
        </button>
      </h2>
      <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          Our personalized support, quick turnaround, and transparent pricing make us a trusted partner for business setup in the UAE.
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingFive">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive">
          Do you offer post-setup support as well?
        </button>
      </h2>
      <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
        <div class="accordion-body">
          Absolutely! We provide accounting, visa renewals, compliance checks, and much more even after your company is launched.
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once("footer.php") ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const dropdown = document.querySelector('.nav-item.dropdown');
    const megaMenu = document.getElementById('megaMenu');
    const toggleButton = document.getElementById('toggleMegaMenu');

    // Toggle mega menu on mobile
    if (window.innerWidth < 992 && toggleButton && megaMenu) {
      toggleButton.addEventListener('click', function (e) {
        e.preventDefault();
        megaMenu.classList.toggle('show');
        toggleButton.textContent = megaMenu.classList.contains('show') ? 'Hide Services' : 'Show Services';
      });
    }

    // Hover effect for desktop
    if (window.innerWidth >= 992 && dropdown && megaMenu) {
      let timer;
      dropdown.addEventListener('mouseenter', () => {
        clearTimeout(timer);
        megaMenu.style.display = 'block';
      });
      dropdown.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });
      megaMenu.addEventListener('mouseenter', () => {
        clearTimeout(timer);
      });
      megaMenu.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });
    }
  });
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>

