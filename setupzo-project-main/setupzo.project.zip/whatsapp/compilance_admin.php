<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$con = mysqli_connect("localhost", "u259563098_setupzo", "Setupzo123", "u259563098_setupzo");
if (!$con) {
    die("DB Connection failed: " . mysqli_connect_error());
}

// Initialize search query
$searchQuery = "";
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $con->real_escape_string($_GET['search']);
    $searchQuery = "WHERE fullname LIKE '%$searchTerm%' OR email LIKE '%$searchTerm%' OR phone LIKE '%$searchTerm%' OR company LIKE '%$searchTerm%'";
}

// Handle multi-delete POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_selected'])) {
    if (!empty($_POST['selected_ids'])) {
        $ids = array_map('intval', $_POST['selected_ids']);
        $id_list = implode(',', $ids);

        $res = $con->query("SELECT license, moa, residance, vat, carporate, bank, eid FROM compilance WHERE id IN ($id_list)");
        if ($res) {
            while ($row_del = $res->fetch_assoc()) {
                foreach (['license', 'moa', 'residance', 'vat', 'carporate', 'bank', 'eid'] as $fileCol) {
                    $filePath = __DIR__ . '/' . $row_del[$fileCol];
                    if (!empty($row_del[$fileCol]) && file_exists($filePath)) {
                        unlink($filePath);
                    }
                }
            }
        } else {
            echo "DB Select error: " . $con->error;
        }

        if (!$con->query("DELETE FROM compilance WHERE id IN ($id_list)")) {
            echo "DB Delete error: " . $con->error;
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        echo "⚠ No valid IDs selected for deletion.";
    }
}

// Handle single delete via GET id
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    if ($id > 0) {
        $res = $con->query("SELECT license, moa, residance, vat, carporate, bank, eid FROM compilance WHERE id = $id");
        if ($res) {
            $row_del = $res->fetch_assoc();
            foreach (['license', 'moa', 'residance', 'vat', 'carporate', 'bank', 'eid'] as $fileCol) {
                $filePath = __DIR__ . '/' . $row_del[$fileCol];
                if (!empty($row_del[$fileCol]) && file_exists($filePath)) {
                    unlink($filePath);
                }
            }
        }

        if (!$con->query("DELETE FROM compilance WHERE id = $id")) {
            echo "DB Delete error: " . $con->error;
        }

        header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    } else {
        echo "⚠ Invalid ID for deletion.";
    }
}

// Fetch all data
$result = $con->query("SELECT * FROM compilance $searchQuery ORDER BY created_at DESC");

$dataByDate = [];
while ($row = $result->fetch_assoc()) {
    $date = date('Y-m-d', strtotime($row['created_at']));
    $dataByDate[$date][] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Freezone Table Grouped by Date</title>
  <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
h3.date-heading {
    margin-top: 2rem;
    margin-bottom: 1rem;
    border-bottom: 2px solid #0d6efd;
    padding-bottom: 0.25rem;
}
thead tr th{
    background-color: #1e2355 !important;
    color: white !important;
}
</style>
</head>
<body style="font-family:times-new-roman">
     <?php include_once("navbar2.php") ?>
<div class="container mt-4">
    <h1>Compilance Applications</h1>
    
    <!-- Search Form -->
    <form method="get" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by name, email, phone or company..." 
                   value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button class="btn btn-outline-primary" type="submit">Search</button>
            <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
                <a href="<?= strtok($_SERVER['REQUEST_URI'], '?') ?>" class="btn btn-outline-danger">Clear</a>
            <?php endif; ?>
        </div>
    </form>
    
    <form method="post" id="multiDeleteForm">
        <div class="mb-3">
            <button type="submit" name="delete_selected" class="btn btn-danger" onclick="return confirm('Delete selected records?')">Delete Selected</button>
        </div>
        <?php if (empty($dataByDate)): ?>
            <p>No data found<?= isset($_GET['search']) ? ' matching your search' : '' ?>.</p>
        <?php else: ?>
            <?php foreach ($dataByDate as $date => $rows): ?>
                <h3 class="date-heading"><?= htmlspecialchars($date) ?></h3>
                <table class="table table-striped table-hover table-bordered align-middle">
                    <thead>
                        <tr>
                            <th><input type="checkbox" class="selectAll" data-date="<?= $date ?>" /></th>
                            <th>id</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>License</th>
                            <th>MOA</th>
                            <th>Residence</th>
                             <th>Vat</th>
                            <th>Corporate</th>
                            <th>Bank</th>
                            <th>Eid</th>
                            <th>Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($rows as $row): ?>
                            <tr>
                                <td><input type="checkbox" name="selected_ids[]" value="<?= $row['id'] ?>" data-date="<?= $date ?>" /></td>
                                <td><?= $i++ ?></td>
                                <td><?= htmlspecialchars($row['fullname']) ?></td>
                                <td><?= htmlspecialchars($row['email']) ?></td>
                                <td><?= htmlspecialchars($row['phone']) ?></td>
                                <td><div style="position: relative; display: inline-block;">
    <img src="<?php echo $row['license']; ?>" width="50px" height="50px" onclick="toggleMenu(this)" style="cursor:pointer;">
    <div class="img-options" style="display:none; position:absolute; background:white; border:1px solid #ccc; z-index:99;">
        <a href="<?php echo $row['passport_path']; ?>" target="_blank" style="display:block; padding:5px;">View Full Size</a>
        <a href="<?php echo $row['passport_path']; ?>" download style="display:block; padding:5px;">Download</a>
    </div>
</div></td>
                                <td><div style="position: relative; display: inline-block;">
    <img src="<?php echo $row['moa']; ?>" width="50px" height="50px" onclick="toggleMenu(this)" style="cursor:pointer;">
    <div class="img-options" style="display:none; position:absolute; background:white; border:1px solid #ccc; z-index:99;">
        <a href="<?php echo $row['passport_path']; ?>" target="_blank" style="display:block; padding:5px;">View Full Size</a>
        <a href="<?php echo $row['passport_path']; ?>" download style="display:block; padding:5px;">Download</a>
    </div>
</div></td>
                                <td><div style="position: relative; display: inline-block;">
    <img src="<?php echo $row['residance']; ?>" width="50px" height="50px" onclick="toggleMenu(this)" style="cursor:pointer;">
    <div class="img-options" style="display:none; position:absolute; background:white; border:1px solid #ccc; z-index:99;">
        <a href="<?php echo $row['photo_path']; ?>" target="_blank" style="display:block; padding:5px;">View Full Size</a>
        <a href="<?php echo $row['photo_path']; ?>" download style="display:block; padding:5px;">Download</a>
    </div>
</div></td>
                                <td><div style="position: relative; display: inline-block;">
    <img src="<?php echo $row['vat']; ?>" width="50px" height="50px" onclick="toggleMenu(this)" style="cursor:pointer;">
    <div class="img-options" style="display:none; position:absolute; background:white; border:1px solid #ccc; z-index:99;">
        <a href="<?php echo $row['passport_path']; ?>" target="_blank" style="display:block; padding:5px;">View Full Size</a>
        <a href="<?php echo $row['passport_path']; ?>" download style="display:block; padding:5px;">Download</a>
    </div>
</div></td>
                                <td><div style="position: relative; display: inline-block;">
    <img src="<?php echo $row['carporate']; ?>" width="50px" height="50px" onclick="toggleMenu(this)" style="cursor:pointer;">
    <div class="img-options" style="display:none; position:absolute; background:white; border:1px solid #ccc; z-index:99;">
        <a href="<?php echo $row['passport_path']; ?>" target="_blank" style="display:block; padding:5px;">View Full Size</a>
        <a href="<?php echo $row['passport_path']; ?>" download style="display:block; padding:5px;">Download</a>
    </div>
</div></td>
                                <td><div style="position: relative; display: inline-block;">
    <img src="<?php echo $row['bank']; ?>" width="50px" height="50px" onclick="toggleMenu(this)" style="cursor:pointer;">
    <div class="img-options" style="display:none; position:absolute; background:white; border:1px solid #ccc; z-index:99;">
        <a href="<?php echo $row['passport_path']; ?>" target="_blank" style="display:block; padding:5px;">View Full Size</a>
        <a href="<?php echo $row['passport_path']; ?>" download style="display:block; padding:5px;">Download</a>
    </div>
</div></td>
                                <td><div style="position: relative; display: inline-block;">
    <img src="<?php echo $row['eid']; ?>" width="50px" height="50px" onclick="toggleMenu(this)" style="cursor:pointer;">
    <div class="img-options" style="display:none; position:absolute; background:white; border:1px solid #ccc; z-index:99;">
        <a href="<?php echo $row['emirates_id_path']; ?>" target="_blank" style="display:block; padding:5px;">View Full Size</a>
        <a href="<?php echo $row['emirates_id_path']; ?>" download style="display:block; padding:5px;">Download</a>
    </div>
</div>
                        </td>
                         <td><?= htmlspecialchars($row['created_at']) ?></td>
                                 <td class="btn-group">
                                   <button
    type="button"
    class="btn btn-info btn-sm"
    data-bs-toggle="modal"
    data-bs-target="#viewModal"
    data-fullname="<?= htmlspecialchars($row['fullname'], ENT_QUOTES) ?>"
    data-email="<?= htmlspecialchars($row['email'], ENT_QUOTES) ?>"
    data-phone="<?= htmlspecialchars($row['phone'], ENT_QUOTES) ?>"
    data-license="<?= htmlspecialchars($row['license'], ENT_QUOTES) ?>"
    data-moa="<?= htmlspecialchars($row['moa'], ENT_QUOTES) ?>"
    data-residance="<?= htmlspecialchars($row['residance'], ENT_QUOTES) ?>"
    data-vat="<?= htmlspecialchars($row['vat'], ENT_QUOTES) ?>"
    data-carporate="<?= htmlspecialchars($row['carporate'], ENT_QUOTES) ?>"
    data-bank="<?= htmlspecialchars($row['bank'], ENT_QUOTES) ?>"
    data-eid="<?= htmlspecialchars($row['eid'], ENT_QUOTES) ?>"
    data-bs-toggle="popover"
    data-bs-trigger="hover focus"
    data-bs-placement="top"
    data-bs-content="View applicant details"
>View</button>


                                    <a href="https://wa.me/923191743832?text=Hello%20<?= urlencode($row['name']) ?>,%20I%20am%20contacting%20you%20regarding%20your%20application."
                                       target="_blank"
                                       class="btn btn-success btn-sm"
                                       data-bs-toggle="popover"
                                       data-bs-trigger="hover focus"
                                       data-bs-placement="top"
                                       data-bs-content="Send WhatsApp message"
                                    >Reply</a>

                                    <a href="?delete_id=<?= $row['id'] ?>"
                                       onclick="return confirm('Delete this record?');"
                                       class="btn btn-danger btn-sm"
                                       data-bs-toggle="popover"
                                       data-bs-trigger="hover focus"
                                       data-bs-placement="top"
                                       data-bs-content="Delete this record"
                                    >Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endforeach; ?>
        <?php endif; ?>
    </form>
</div>

<!-- Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold" id="viewModalLabel">Applicant Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h5 id="modalFullName"></h5>
        <p><strong>Email:</strong> <span id="modalEmail"></span></p>
        <p><strong>Phone:</strong> <span id="modalPhone"></span></p>
        <hr>
        <div class="d-flex justify-content-around">
            <div><p class="text-center fw-semibold">License Image</p><img id="modallicense" class="img-thumbnail" style="width:200px;"></div>
            <div><p class="text-center fw-semibold">MOA</p><img id="modal_moa" class="img-thumbnail" style="width:200px;"></div>
            <div><p class="text-center fw-semibold">Residance Visa</p><img id="modalresidance" class="img-thumbnail" style="width:200px;"></div>
            </div>
            <div class="d-flex justify-content-around">
             <div><p class="text-center fw-semibold">Vat</p><img id="modalvat" class="img-thumbnail" style="width:200px;"></div>
            <div><p class="text-center fw-semibold">Carporate</p><img id="modalcarporate" class="img-thumbnail" style="width:200px;"></div>
            <div><p class="text-center fw-semibold">Bank</p><img id="modalbank" class="img-thumbnail" style="width:200px;"></div>
            </div>
            <div class="d-flex justify-content-around">
              <div><p class="text-center fw-semibold">Emirates ID</p><img id="modaleid" class="img-thumbnail" style="width:200px;"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Populate modal with button data
var viewModal = document.getElementById('viewModal');
viewModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    document.getElementById('modalFullName').textContent = button.getAttribute('data-fullname');
    document.getElementById('modalEmail').textContent = button.getAttribute('data-email');
    document.getElementById('modalPhone').textContent = button.getAttribute('data-phone');
   document.getElementById('modallicense').src = button.getAttribute('data-license');
document.getElementById('modal_moa').src = button.getAttribute('data-moa');
document.getElementById('modalresidance').src = button.getAttribute('data-residance');
document.getElementById('modalvat').src = button.getAttribute('data-vat');
document.getElementById('modalcarporate').src = button.getAttribute('data-carporate');
document.getElementById('modalbank').src = button.getAttribute('data-bank');
document.getElementById('modaleid').src = button.getAttribute('data-eid');

});

// Checkbox toggle by date group
document.querySelectorAll('.selectAll').forEach(cb => {
    cb.addEventListener('change', function () {
        let date = this.dataset.date;
        document.querySelectorAll('input[type="checkbox"][data-date="' + date + '"]').forEach(c => c.checked = this.checked);
    });
});

// Initialize all popovers

const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
popoverTriggerList.map(triggerEl => new bootstrap.Popover(triggerEl));
function toggleMenu(img) {
    var menu = img.nextElementSibling;
    menu.style.display = (menu.style.display === 'block') ? 'none' : 'block';
}
</script>
<?php include_once("footer2.php") ?>
</body>
</html>