<?php
header('location:business-setup-dubai')
?>
<!--<!DOCTYPE html>-->
<!--<html lang="en">-->
<!--<head>-->
<!--    <meta name="description" content="Start your business in UAE with Setup Zo. Get company formation, visas, legal, and compliance support.">-->
<!--<meta name="keywords" content="UAE Business Setup, Company Formation Dubai, Visa Services UAE, Legal Support">-->
<!--<meta name="author" content="Setup Zo">-->
<!--<meta property="og:title" content="Start Your UAE Business Journey | Setup Zo">-->
<!--<meta property="og:description" content="Get legal licenses, visa support, company formation, and more.">-->
<!--<meta property="og:image" content="img/ahmer-setupzoo-again.png">-->

<!--    <meta charset="UTF-8">-->
<!--    <meta name="viewport" content="width=device-width, initial-scale=1.0">-->
<!--     css file link -->
<!--    <link rel="stylesheet" href="css.css">-->
<!--     bootstrap css cdn -->
<!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">-->
<!--     bootstrap java cdn -->
<!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>-->
<!--    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>-->
<!--    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>-->
<!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>-->
<!--     css file link -->
<!--    <link rel="stylesheet" href="css.css">-->
<!--     fontawsome cdn -->
<!--    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />-->
<!--     AOS animation -->
<!--    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">-->
<!--    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>-->
<!--     google font -->
<!--    <link rel="preconnect" href="https://fonts.googleapis.com">-->
<!--    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>-->
<!--    <link href="https://fonts.googleapis.com/css2?family=Playball&display=swap" rel="stylesheet">-->
<!--     google icon -->
<!--    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=location_on" />-->
<!--     jquery slide cdn -->
<!--    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>-->


<!--     Cube Portfolio CSS -->
<!--<link rel="stylesheet" href="path-to-your-assets/cubeportfolio/css/cubeportfolio.min.css">-->

<!-- jQuery Library -->
<!--<script src="https://code.jquery.com/jquery-latest.min.js"></script>-->

<!-- Cube Portfolio JS -->
<!--<script src="path-to-your-assets/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>-->
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.css" />-->
<!--    <title>Setupzo 2025- Setting up Business Setup UAE </title>-->
<!--    <meta name="description" content="Set up your business in Dubai with ease. We offer company formation, trade license, visa, PRO & Golden Visa services. Fast & reliable setup support.">-->

<!--      <link rel="icon" href="img/favicon.ico" type="image/x-icon">-->
<!--  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">-->
<!--  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">-->
<!--  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">-->
<!--  <link rel="manifest" href="img/site.webmanifest">-->
<!--  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"/>-->
<!--   Swiper Testimonial Slider Start -->
<!--<link-->
<!--  rel="stylesheet"-->
<!--  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"-->
<!--/>-->
<!--   <style>-->
   
<!--   .container1{-->
       /*background-image: url('img/bgimg2.jpg');*/
<!--       background-size: cover;-->
<!--       background-repeat: no-repeat;-->
<!--       background-position: center;-->
<!--   }-->
<!--    .footer{-->
<!--       background-image: url('img/worldmap.png'); -->
<!--    }-->
<!--    .container3{-->
<!--      background-image:url('img/bgimg2.jpg')-->
<!--    }-->
<!--    .container5{-->
<!--      background-image:url('img/freezone.png')-->
<!--    }-->
<!--    #submitBtn.loading {-->
<!--  position: relative;-->
<!--  pointer-events: none;-->
<!--  opacity: 0.7;-->
<!--}-->

<!--#submitBtn.loading::after {-->
<!--  content: "";-->
<!--  position: absolute;-->
<!--  top: 50%;-->
<!--  right: 10px;-->
<!--  width: 16px;-->
<!--  height: 16px;-->
<!--  border: 2px solid #fff;-->
<!--  border-top-color: transparent;-->
<!--  border-radius: 50%;-->
<!--  animation: spin 0.6s linear infinite;-->
<!--}-->

<!--@keyframes spin {-->
<!--  to {-->
<!--    transform: rotate(360deg);-->
<!--  }-->
<!--}-->
<!--#phone{-->
<!--    width: 280px;-->
<!--}-->
<!--    .nav-link {-->
<!--      color: #1e2355 !important;-->
      /*font-weight: bold !important;*/
<!--    }-->

<!--     .mega-dropdown {-->
<!--      width: 100vw;-->
<!--      left: 0;-->
<!--      top: 100%;-->
<!--      position: absolute;-->
<!--      background: #fff;-->
<!--      padding: 30px;-->
<!--      display: none;-->
<!--      z-index: 9999;-->
<!--      box-shadow: 0 8px 20px rgba(0,0,0,0.1);-->
<!--      animation: fadeInDown 0.3s ease-in-out;-->
<!--    }-->

<!--    .mega-dropdown .dropdown-item {-->
<!--      font-weight: 500;-->
<!--      color: #1e2355;-->
<!--      transition: 0.3s;-->
<!--      white-space: nowrap;-->
<!--    }-->

<!--    .mega-dropdown .dropdown-item:hover {-->
<!--      background-color: #1e2355;-->
<!--      color: white;-->
<!--      padding-left: 10px;-->
<!--    }-->

<!--    .mega-dropdown h6 {-->
<!--      margin-bottom: 12px;-->
<!--      font-size: 14px;-->
<!--      color: #1e2355;-->
<!--    }-->

<!--    @keyframes fadeInDown {-->
<!--      from {-->
<!--        opacity: 0;-->
<!--        transform: translateY(-10px);-->
<!--      }-->
<!--      to {-->
<!--        opacity: 1;-->
<!--        transform: translateY(0px);-->
<!--      }-->
<!--    }-->

    /* ✅ Responsive Mobile Scroll CSS */
<!--    @media (max-width: 991px) {-->
<!--      .mega-dropdown {-->
<!--        overflow-x: auto !important;-->
<!--        white-space: nowrap !important;-->
<!--        display: block !important;-->
<!--        padding: 15px;-->
<!--      }-->

<!--      .mega-dropdown .row {-->
<!--        display: flex !important;-->
<!--        flex-wrap: nowrap !important;-->
<!--      }-->

<!--      .mega-dropdown .col-md-2 {-->
<!--        flex: 0 0 auto !important;-->
<!--        width: 250px !important;-->
<!--        display: inline-block;-->
<!--        white-space: normal;-->
<!--        margin-right: 20px;-->
<!--      }-->
<!--    }-->
<!--    .testimonial-img {-->
<!--      width: 90px;-->
<!--      height: 90px;-->
<!--      object-fit: cover;-->
<!--      border: 3px solid #0d6efd;-->
<!--    }-->

<!--    .card-hover {-->
<!--      transition: all 0.4s ease;-->
<!--    }-->

<!--    .card-hover:hover {-->
<!--      transform: translateY(-10px);-->
<!--      box-shadow: 0 0 30px rgba(0, 0, 0, 0.15);-->
<!--    }-->

<!--    .swiper {-->
<!--      padding-bottom: 50px;-->
<!--    }-->

<!--    @media (max-width: 768px) {-->
<!--      .testimonial-img {-->
<!--        width: 70px;-->
<!--        height: 70px;-->
<!--      }-->
<!--    }-->
<!--  </style>-->
<!--</head>-->
<!--<body>-->
<!--     navbar -->
   
<!--     <nav class="navbar navbar-expand-lg fixed-top" style="z-index: 1;background-color: rgba(255, 255, 255, 0.3);">-->
<!--    <div class="container">-->
<!--      <a class="navbar-brand ms-3 logo" href="index.php">-->
<!--        <img src="img/ahmer-setupzoo-again.png" width="100px" alt="logo" />-->
<!--      </a>-->
<!--      <button class="navbar-toggler me-3" type="button" style="border-color: #1e2355;" data-toggle="collapse" data-target="#navbarNav">-->
<!--        <i class="fa-solid fa-bars" style="color: #1e2355;font-size: 30px;"></i>-->
<!--      </button>-->
<!--      <div class="collapse navbar-collapse" id="navbarNav">-->
<!--        <ul class="navbar-nav mx-auto" style="color:#1e2355">-->
<!--          <li class="nav-item">-->
<!--            <a class="nav-link" href="homepage.php" style="color:#1e2355"><b>Home</b></a>-->
<!--          </li>-->
<!--          <li class="nav-item">-->
<!--            <a class="nav-link" href="aboutus.php" style="color:#1e2355"><b>About Us</b></a>-->
<!--          </li> -->
          
<!--  Services Mega Dropdown -->
<!--       <li class="nav-item dropdown px-2 position-static">-->
<!--          <a class="nav-link dropdown-toggle" href="services.php" id="servicesDropdown" style=" font-weight: bold !important;">Services</a>-->
<!--          <div class="dropdown-menu mega-dropdown" id="megaMenu">-->
<!--            <div class="row">-->
<!--              <div class="col-md-2">-->
<!--                <h6>Company Formation</h6>-->
<!--                <a class="dropdown-item" href="mainland-page.php">Mainland</a>-->
<!--                <a class="dropdown-item" href="freezone-page.php">Free Zone</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Visa & Immigration</h6>-->
<!--                <a class="dropdown-item" href="residence_visa.php">Residence Visa</a>-->
<!--                <a class="dropdown-item" href="golden_visa.php">Golden Visa</a>-->
<!--                <a class="dropdown-item" href="freelancevisa_page.php">Freelance Visa</a>-->
<!--                <a class="dropdown-item" href="bank_account_open.php">Bank Account Opening</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Financial Services</h6>-->
<!--                <a class="dropdown-item" href="payroll_page.php">Payroll</a>-->
<!--                <a class="dropdown-item" href="vat_service.php">Corporate Tax & VAT</a>-->
<!--                <a class="dropdown-item" href="compilance.php">Compliance</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Legal Services</h6>-->
<!--                <a class="dropdown-item" href="pro.php">PRO Services</a>-->
<!--                <a class="dropdown-item" href="finalwill.php">Will Preparation</a>-->
<!--                <a class="dropdown-item" href="trademark&copyright.php">Trademark & Copyright</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Additional Services</h6>-->
<!--                <a class="dropdown-item" href="health_insurance.php">Health Insurance</a>-->
<!--                <a class="dropdown-item" href="police_clearance.php">Police Clearance</a>-->
<!--                <a class="dropdown-item" href="dm_page.php">DM Approval</a>-->
<!--                <a class="dropdown-item" href="emirates_page.php">Emirates ID Update</a>-->
<!--              </div>-->
<!--              <div class="col-md-2">-->
<!--                <h6>Nominee Services</h6>-->
<!--                <a class="dropdown-item" href="contactus.php">Shareholder</a>-->
<!--                <a class="dropdown-item" href="contactus.php">Manager</a>-->
<!--              </div>-->
<!--            </div>-->
<!--          </div>-->
<!--        </li>-->
        
<!--          <li class="nav-item">-->
<!--            <a class="nav-link" href="blogs.php" style="color:#1e2355"><b>Blog</b></a>-->
<!--          </li>-->
<!--          <li class="nav-item">-->
<!--            <a class="nav-link" href="contactus.php" style="color:#1e2355"><b>Contact</b></a>-->
<!--          </li>-->
<!--        </ul>-->

<!--       <a href="contactus.php" class="rounded btn text-white py-2 px-3 my-2 my-sm-0 mx-lg-5" style="margin-left: 8px; text-decoration: none;background-color: #1e2355;">-->
<!--  <b>Apply Now</b>-->
<!--</a>-->
<!--      </div>-->
<!--    </div>-->
<!--  </nav>-->
 
<!--       navbar end -->

<!--        container 1 start -->
<!--        <div class="container1">-->
<!--          <div class="containe1sub">-->
<!--          <div class="container1sub1 mx-auto pt-5">-->
<!--            <p class="hero-text">-->
<!--              Start Your UAE Business Journey with a Legal License, Your First Step to Success-->
<!--            </p>-->
<!--           <button class="buttons btn btn-warning py-2 px-3 my-2 my-sm-0" onclick="window.location.href='contactus.php'">-->
<!--  <b>Check Your Eligibility</b>-->
<!--</button>-->

<!--          </div>-->
        
<!--         cards start -->
<!-- <div class="container1sub2 mx-auto mt-5 pt-5">-->
<!--  <h2 class="hero-text1" style="text-align: center;">-->
<!--    <b>Apply Online Now</b>-->
<!--  </h2>-->
<!--  <div class="container1sub2sub row">-->

<!--     <div class="offercard">-->
<!--      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">-->
<!--      <p class="offerhead">Company Formation</p>-->
<!--      <div class="cradbtns">-->
<!--     <a class="buttons2 btn btn-warning py-2 px-0 my-2 my-sm-1" href="mainland-page.php">Mainland</a><br>-->
<!--     <a class="buttons2 btn btn-warning py-2 px-0 my-2 my-sm-1" href="freezone-page.php">Free Zone</a>-->
<!--      </div>-->
<!--     </div>-->

<!--     <div class="offercard">-->
<!--      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">-->

<!--      <p class="offerhead">Visa & Immigration Services</p>-->
<!--      <div class="cradbtns">-->
<!--         <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="residence_visa.php">Residence Visas</a><br>-->
<!--         <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="golden_visa.php">Golden Visa Program</a><br>-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="freelancevisa_page.php">Freelance Visas</a><br>-->
<!--      <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="bank_account_open.php">Bank Account Opening</a><br>-->
<!--        </div>-->
<!--     </div>-->

<!--     <div class="offercard">-->
<!--      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">-->
<!--      <p class="offerhead">Financial & Compliance Services</p>-->
<!--      <div class="cradbtns">-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="payroll_page.php">Accounting & Payroll</a><br>-->
         
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="vat_service.php">Corporate Tax & VAT</a><br>-->
<!--       <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="compilance.php">Compliance</a>-->
<!--        </div>-->
<!--     </div>-->

<!--     <div class="offercard">-->
<!--      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">-->
<!--      <p class="offerhead">Legal & Administrative Services</p>-->
<!--      <div class="cradbtns">-->
<!--         <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="pro.php">PRO Services</a><br>-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="finalwill.php">Will Preparation</a><br>-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="trademark&copyright.php">Trademark & Copyright Registration</a>-->
<!--        </div>-->
<!--     </div>-->

<!--     <div class="offercard">-->
<!--      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">-->
<!--      <p class="offerhead">Additional Services</p>-->
<!--      <div class="cradbtns">-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="health_insurance.php">Health Insurance</a><br>-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="police_clearance.php">Police Clearance Certificate</a><br>-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="dm_page.php">Dm Approval</a><br>-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="emirates_page.php">Emirates ID info Update</a>-->
<!--        </div>-->
<!--     </div>-->

<!--     <div class="offercard">-->
<!--      <img src="img/ahmer-setupzoo-gain-just.png"  width="60px" alt="icon">-->
<!--      <p class="offerhead">Nominee Services</p>-->
<!--      <div class="cradbtns">-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="contactus.php">Shareholder</a><br>-->
<!--        <a class="buttons2 btn btn-warning py-2 px-3 my-2 my-sm-1" href="contactus.php">Manager</a>-->
<!--        </div>-->
<!--     </div>-->

<!--    </div>-->
     
<!-- </div>-->
<!-- cards end -->
<!-- </div>-->
<!--</div>-->
<!--    container 1 end -->

<!-- container4 start -->
<!--<div class="container-fluid py-5 row mx-auto">-->
<!--  <div class="col-lg-5 col-md-9 col-sm-12 py-5 mx-auto">-->
<!--    <p class="smheading">Setupzo</p>-->
<!--    <p class="container4head">Why Setupzo?</p>-->
<!--    <p class="container4text">-->
<!--    Setupzo is not just a service for getting a business license  it is a smart and smooth starting point for long term business success in the UAE. Our clients come to us because we deliver more than just paperwork. We provide clarity, speed, and reliability.<br>-->
<!--With deep expertise in Free Zone, Mainland, company formation, our team offers every client personalized guidance, with zero confusion or delays. Thanks to our strong ties with UAE government departments and local authorities, your approvals come through faster, helping you get your business up and running quickly.<br>-->
<!--Whether you are a startup founder, an expanding company, or an international investor, Setupzo provides tailored licensing solutions that align with your business goals  efficiently, transparently, and with full legal compliance.-->
<!--    </p>-->
<!--  </div>-->
<!--   <div class="col-lg-5 col-md-9 col-sm-12 py-5 mx-auto mt-5 rounded">-->
       
<!--<div id="customCarousel" class="carousel slide" data-bs-ride="carousel">-->
<!--  <div class="carousel-inner">-->
<!--    <div class="carousel-item active">-->
<!--      <img src="img/wallpaperflare.com_wallpaper.jpg" class="d-block w-100 rounded" style="height:400px" alt="...">-->
<!--    </div>-->
<!--    <div class="carousel-item">-->
<!--      <img src="img/bgimg2.jpg" class="d-block w-100 rounded" style="height:400px" alt="img not found">-->
<!--    </div>-->
<!--    <div class="carousel-item">-->
<!--      <img src="img/bgimg2.jpg" class="d-block w-100 rounded" style="height:400px" alt="...">-->
<!--    </div>-->
<!--  </div>-->

<!--  <button class="carousel-control-prev" type="button" data-bs-target="#customCarousel" data-bs-slide="prev">-->
<!--    <span class="carousel-control-prev-icon" aria-hidden="true"></span>-->
<!--    <span class="visually-hidden">Previous</span>-->
<!--  </button>-->
<!--  <button class="carousel-control-next" type="button" data-bs-target="#customCarousel" data-bs-slide="next">-->
<!--    <span class="carousel-control-next-icon" aria-hidden="true"></span>-->
<!--    <span class="visually-hidden">Next</span>-->
<!--  </button>-->
<!--</div>-->

<!--  </div>-->
<!--</div>-->
<!-- Setup Zo Counter Section -->
<!-- Counter Section Start -->
<!--<section class="counter-section py-5" style="background: #f0f2f5;">-->
<!--  <div class="container">-->
<!--    <div class="row g-4 justify-content-center">-->
      
<!--      <div class="col-6 col-md-3">-->
<!--        <div class="card text-center shadow border-0 p-4" style="height: 180px;" data-aos="fade-up">-->
<!--          <h2 class="counter text-primary" data-count="1000">0</h2>-->
<!--          <p class="counter-title">Companies Formed</p>-->
<!--        </div>-->
<!--      </div>-->

<!--      <div class="col-6 col-md-3">-->
<!--        <div class="card text-center shadow border-0 p-4" style="height: 180px;" data-aos="fade-up" data-aos-delay="100">-->
<!--          <h2 class="counter text-success" data-count="500">0</h2>-->
<!--          <p class="counter-title">Visas Processed</p>-->
<!--        </div>-->
<!--      </div>-->

<!--      <div class="col-6 col-md-3">-->
<!--        <div class="card text-center shadow border-0 p-4" style="height: 180px;" data-aos="fade-up" data-aos-delay="200">-->
<!--          <h2 class="counter text-danger" data-count="1200">0</h2>-->
<!--          <p class="counter-title">Satisfied Clients</p>-->
<!--        </div>-->
<!--      </div>-->

<!--      <div class="col-6 col-md-3">-->
<!--        <div class="card text-center shadow border-0 p-4" style="height: 180px;" data-aos="fade-up" data-aos-delay="300">-->
<!--          <h2 class="counter text-warning" data-count="10">0</h2>-->
<!--          <p class="counter-title">Years of Experience</p>-->
<!--        </div>-->
<!--      </div>-->

<!--    </div>-->
<!--  </div>-->
<!--</section>-->
<!-- Counter Section End -->

<!--end-->


 
<!--<div class="container py-5">-->
<!--  <h2 class="text-center mb-5">Latest From Our Blog</h2>-->
<!--  <div class="row">-->
<!--    <div class="col-md-4 mb-4">-->
<!--      <div class="card h-100 shadow border-0">-->
<!--        <img src="img/blog1.jpg" class="card-img-top" alt="Business Setup in UAE">-->
<!--        <div class="card-body">-->
<!--          <h5 class="card-title">Step-by-Step Guide to Starting a Business in UAE</h5>-->
<!--          <p class="card-text">Learn everything you need to know before starting your company in Dubai or anywhere in UAE.</p>-->
<!--          <a href="#" class="btn btn-outline-primary btn-sm">Read More</a>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--    <div class="col-md-4 mb-4">-->
<!--      <div class="card h-100 shadow border-0">-->
<!--        <img src="img/blog2.jpg" class="card-img-top" alt="Visa Services">-->
<!--        <div class="card-body">-->
<!--          <h5 class="card-title">Understanding the UAE Visa Process</h5>-->
<!--          <p class="card-text">From residency to golden visas, get clarity on the UAE's evolving immigration policies.</p>-->
<!--          <a href="#" class="btn btn-outline-primary btn-sm">Read More</a>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--    <div class="col-md-4 mb-4">-->
<!--      <div class="card h-100 shadow border-0">-->
<!--        <img src="img/blog3.jpg" class="card-img-top" alt="Free Zone vs Mainland">-->
<!--        <div class="card-body">-->
<!--          <h5 class="card-title">Free Zone vs Mainland: Which is Right for You?</h5>-->
<!--          <p class="card-text">Explore the pros and cons of each business jurisdiction in UAE with real case examples.</p>-->
<!--          <a href="#" class="btn btn-outline-primary btn-sm">Read More</a>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->

<!-- Call to Action Section -->
<!--<div class="container py-5 text-center">-->
<!--  <h2 class="mb-5">What Our Clients Say</h2>-->
<!--  <div class="swiper testimonialSwiper">-->
<!--    <div class="swiper-wrapper">-->

<!--       Testimonial 1 -->
<!--      <div class="swiper-slide">-->
<!--        <div class="card border-0 shadow p-4 card-hover">-->
<!--          <img src="https://randomuser.me/api/portraits/men/34.jpg" class="testimonial-img rounded-circle mx-auto mb-3" alt="Client 1">-->
<!--          <p class="mb-2">Setupzo made my business registration simple and efficient. Great customer service!</p> <br>-->
<!--          <h6 class="mb-0">Ali Raza</h6>-->
<!--          <small>Entrepreneur</small>-->
<!--        </div>-->
<!--      </div>-->

<!--       Testimonial 2 -->
<!--      <div class="swiper-slide">-->
<!--        <div class="card border-0 shadow p-4 card-hover">-->
<!--          <img src="https://randomuser.me/api/portraits/women/49.jpg" class="testimonial-img rounded-circle mx-auto mb-3" alt="Client 2">-->
<!--          <p class="mb-2">Their team handled our visa process with precision. It was smooth, professional, and fully transparent. Highly recommended for UAE startup founders!</p>-->
<!--          <h6 class="mb-0">Mehwish Khan</h6>-->
<!--          <small>HR Director</small>-->
<!--        </div>-->
<!--      </div>-->

<!--       Testimonial 3 -->
<!--      <div class="swiper-slide">-->
<!--        <div class="card border-0 shadow p-4 card-hover">-->
<!--          <img src="https://randomuser.me/api/portraits/men/47.jpg" class="testimonial-img rounded-circle mx-auto mb-3" alt="Client 3">-->
<!--          <p class="mb-2">I needed legal and business setup help. Setupzo delivered everything faster than expected and even guided me afterward for banking and compliance.</p>-->
<!--          <h6 class="mb-0">Ravi Pratap</h6>-->
<!--          <small>Business Owner</small>-->
<!--        </div>-->
<!--      </div>-->

<!--       Testimonial 4 -->
<!--      <div class="swiper-slide">-->
<!--        <div class="card border-0 shadow p-4 card-hover">-->
<!--          <img src="https://randomuser.me/api/portraits/women/52.jpg" class="testimonial-img rounded-circle mx-auto mb-3" alt="Client 4">-->
<!--          <p class="mb-2">Professional, fast, and super cooperative. Setupzo took care of all the documents while I focused on my product.</p><br>-->
<!--          <h6 class="mb-0">Lina Jord</h6>-->
<!--          <small>Startup Founder</small>-->
<!--        </div>-->
<!--      </div>-->

<!--       Testimonial 5 -->
<!--      <div class="swiper-slide">-->
<!--        <div class="card border-0 shadow p-4 card-hover">-->
<!--         <img src="https://randomuser.me/api/portraits/men/36.jpg" class="testimonial-img rounded-circle mx-auto mb-3" alt="Client 5">-->
<!--          <p class="mb-2">They supported us through every step of the formation process. Their expert legal and documentation services helped us launch quickly in Dubai.</p>-->
<!--          <h6 class="mb-0">Tom Jason</h6>-->
<!--          <small>Consultant</small>-->
<!--        </div>-->
<!--      </div>-->

<!--    </div>-->
    
<!--     Pagination (optional) -->
<!--    <div class="swiper-pagination mt-3"></div>-->
<!--  </div>-->
<!--</div>-->

<!-- Swiper Testimonial Slider End -->

<!-- container 5 strat -->
<!--<div class="container5">-->
<!--  <div class="container5sub1 mx-auto py-5">-->
<!--    <p class="smheading">Contact Us</p>-->
<!--    <p class="container4head text-white">We love hearing from you</p>-->
<!--    <form class="form-container row g-3 mx-auto" id="contactForm" action="save_contact.php">-->
<!--      <div class="col-md-6 py-2">-->
<!--          <input type="text" class="form-control" id="name" placeholder="Enter your name" name="name" required>-->
<!--      </div>-->
<!--       <div class="mb-3 col-md-6 py-2 phone-input-container">-->
<!--        <input type="tel" class="form-control" id="phone" name="phone" required>-->
<!--        <input type="hidden" id="dial_code" name="dial_code">-->
<!--      </div>-->
<!--      <div class="col-md-12 py-2">-->
<!--        <input type="email" class="form-control" id="email" placeholder="Enter your email" name="email" required>-->
<!--      </div>-->
<!--      <div class="col-12 py-2">-->
<!--          <textarea class="form-control" id="comments" rows="4" placeholder="Description..." name="comments"></textarea>-->
<!--      </div>-->
<!--      <div class="col-12 py-2 text-center">-->
<!--         <button type="submit" class="buttons rounded px-5 btn submit w-100" id="submitBtn">-->
<!--  <span id="submitText">Submit</span>-->
<!--  <span id="processingText" style="display: none;">Processing...</span>-->
<!--</button>-->
<!--      </div>-->
<!--  </form>-->
    
<!--  </div>-->
<!-- </div>-->
<!-- container 5 end -->


<!--  Footer start -->
<!-- <div class="footer">-->

<!--  <div class="footer-container">-->
<!--     About Us Column -->
<!--    <div class="footer-column">-->
<!--           <img src="img/ahmer-setupzoo-[white-color.png" width="100px" alt="logo">-->
<!--      <p>Setupzo empowers entrepreneurs and investors with seamless company formation, visa processing, and smart administrative solutions.-->

<!--</p>-->
<!--    </div>-->
<!--     Special Facilities Column -->
<!--    <div class="footer-column">-->
<!--      <h2>Quick Links</h2>-->
<!--      <a href="index.php">Home</a>-->
<!--      <a href="contactus.php">Contact</a>-->
<!--      <a href="services.php">Services</a>-->
<!--      <a href="aboutus.php">About</a>-->
<!--    </div>-->
<!--     Contact Column -->
<!--    <div class="footer-column">-->
<!--      <h2>Contact Us</h2>-->
<!--         <p><i class="fas fa-map-marker-alt me-2"></i></p> -->
<!--        <p><a href="tel:+971568677227"><i class="fas fa-phone me-2 mx-2"></i>+971 56 867 7227</a></p>-->
<!--        <p><a href="mailto:info@setupzo.com"><i class="fas fa-envelope me-2 mx-2"></i>info@setupzo.com</a></p>-->
<!--         <p style="font-size:20px" class="text-white"><i class="fa-brands fa-instagram text-white mx-3"></i>-->
<!--      <i class="fa-brands fa-square-facebook mx-3"></i>-->
<!--    <i class="fa-brands fa-linkedin-in mx-3"></i></p>-->
<!--    </div>-->
<!--     Social Media Column -->
<!--  </div>-->
  
<!--  <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"></script>-->
<!--  <script>-->
    // Initialize phone input
<!--  const input = document.querySelector("#phone");-->
<!--  const iti = window.intlTelInput(input, {-->
<!--    initialCountry: "auto",-->
<!--    geoIpLookup: function(callback) {-->
<!--      fetch("https://ipinfo.io?token=b8604525b76188")-->
<!--        .then(response => response.json())-->
<!--        .then(data => {-->
<!--          const countryCode = data.country ? data.country : "US";-->
          callback(countryCode); // Do not convert to lowercase!
<!--        })-->
<!--        .catch(() => {-->
<!--          callback("US");-->
<!--        });-->
<!--    },-->
<!--    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"-->
<!--  });       -->
    // Initialize AOS
<!--    AOS.init();-->
    
    // Contact form submission
<!--    $('#contactForm').on('submit', function(e) {-->
        e.preventDefault(); // Prevent page reload

<!--        $.ajax({-->
<!--            type: 'POST',-->
<!--            url: 'save_contact.php',-->
<!--            data: $(this).serialize(),-->
<!--            success: function(response) {-->
                alert(response); // Show success or error
                $('#contactForm')[0].reset(); // Reset form
<!--            },-->
<!--            error: function() {-->
<!--                alert('An error occurred. Please try again.');-->
<!--            }-->
<!--        });-->
<!--    });-->

  // Validate phone before submit
<!--  document.querySelector("#contactForm").addEventListener("submit", function (e) {-->
<!--    if (!phoneInput.isValidNumber()) {-->
<!--      e.preventDefault();-->
<!--      alert("Please enter a valid phone number.");-->
<!--    } else {-->
      // Optionally replace raw value with full international format
<!--      phoneInputField.value = phoneInput.getNumber();-->
<!--    }-->
<!--  });-->
<!--  document.querySelector("#contactForm").addEventListener("submit", function (e) {-->
<!--  const submitBtn = document.getElementById("submitBtn");-->
<!--  const submitText = document.getElementById("submitText");-->
<!--  const processingText = document.getElementById("processingText");-->

  // Show processing state
<!--  submitBtn.classList.add("loading");-->
<!--  submitText.style.display = "none";-->
<!--  processingText.style.display = "inline";-->

  // Let the form submit normally OR handle AJAX here
  // If you're using AJAX, call `preventDefault()` and show success/failure message accordingly
<!--});-->

<!--    </script>-->
<!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script> -->
    
<!--     Lazy load images globally -->
<!--<script>-->
<!--  document.querySelectorAll('img').forEach(img => {-->
<!--    img.setAttribute('loading', 'lazy');-->
<!--  });-->
<!--</script>-->

<!-- Counter animation script -->
<!--<script>-->
<!--  document.addEventListener("DOMContentLoaded", () => {-->
<!--    const counters = document.querySelectorAll('.counter');-->
<!--    counters.forEach(counter => {-->
<!--      counter.innerText = '0';-->
<!--      const updateCounter = () => {-->
<!--        const target = +counter.innerText.replace(/\D/g, '') || +counter.dataset.target;-->
<!--        const current = +counter.innerText.replace(/\D/g, '') || 0;-->
<!--        const increment = target / 100;-->

<!--        if (current < target) {-->
<!--          counter.innerText = Math.ceil(current + increment);-->
<!--          setTimeout(updateCounter, 30);-->
<!--        } else {-->
<!--          counter.innerText = target + (counter.innerText.includes('%') ? '%' : '+');-->
<!--        }-->
<!--      };-->
<!--      updateCounter();-->
<!--    });-->
<!--  });-->
<!--</script>-->

<!-- Hover effect for offer cards -->
<!-- Optional: Add WhatsApp widget (replace link with your number) -->
<!--<script>-->
<!--  (function () {-->
<!--    var options = {-->
<!--      whatsapp: "+971568677227",-->
<!--      call_to_action: "Message us",-->
<!--      position: "right",-->
<!--    };-->
<!--    var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;-->
<!--    var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';-->
<!--    s.onload = function () { WhWidgetSendButton.init(host, proto, options); };-->
<!--    document.getElementsByTagName('head')[0].appendChild(s);-->
<!--  })();-->
<!--</script> -->
<!--counter-->
<!--<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>-->
<!--<script>-->
<!--  $('.counter').each(function () {-->
<!--    var $this = $(this),-->
<!--        countTo = $this.attr('data-count');-->
    
<!--    $({ countNum: $this.text() }).animate({-->
<!--      countNum: countTo-->
<!--    },-->
<!--    {-->
<!--      duration: 2000,-->
<!--      easing: 'swing',-->
<!--      step: function () {-->
<!--        $this.text(Math.floor(this.countNum));-->
<!--      },-->
<!--      complete: function () {-->
<!--        $this.text(this.countNum);-->
<!--      }-->
<!--    });-->
<!--  });-->
<!--</script>-->
<!--<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>-->
<!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>-->

<!--counters-->
<!--<script>-->
<!--document.addEventListener("DOMContentLoaded", () => {-->
<!--  const counters = document.querySelectorAll(".counter");-->
<!--  let started = false;-->

<!--  function runCounter() {-->
<!--    if (!started && window.scrollY + window.innerHeight > document.querySelector(".counter-section").offsetTop + 100) {-->
<!--      counters.forEach(counter => {-->
<!--        let target = +counter.getAttribute("data-count");-->
<!--        let count = 0;-->
<!--        let increment = target / 100;-->
<!--        let update = setInterval(() => {-->
<!--          count += increment;-->
<!--          if (count >= target) {-->
<!--            counter.innerText = target + "+";-->
<!--            clearInterval(update);-->
<!--          } else {-->
<!--            counter.innerText = Math.ceil(count);-->
<!--          }-->
<!--        }, 30);-->
<!--      });-->
<!--      started = true;-->
<!--    }-->
<!--  }-->

<!--  window.addEventListener("scroll", runCounter);-->
<!--});-->
<!--</script>-->
<!-- Swiper JS -->
<!--<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>-->

<!--<script>-->
<!--  var swiper = new Swiper(".testimonialSwiper", {-->
<!--    slidesPerView: 1,-->
<!--    spaceBetween: 30,-->
<!--    loop: true,-->
<!--    autoplay: {-->
<!--      delay: 2000,-->
<!--      disableOnInteraction: false,-->
<!--    },-->
<!--    pagination: {-->
<!--      el: ".swiper-pagination",-->
<!--      clickable: true,-->
<!--    },-->
<!--    breakpoints: {-->
<!--      768: {-->
<!--        slidesPerView: 2,-->
<!--      },-->
<!--      992: {-->
<!--        slidesPerView: 3,-->
<!--      },-->
<!--    },-->
<!--  });-->
<!--</script>-->

<!--nev-->
<!--<script>-->
<!--  document.addEventListener("DOMContentLoaded", function () {-->
<!--    const dropdown = document.querySelector('.nav-item.dropdown');-->
<!--    const megaMenu = document.getElementById('megaMenu');-->

<!--    if (window.innerWidth >= 992) {-->
<!--      let timer;-->

<!--      dropdown.addEventListener('mouseenter', () => {-->
<!--        clearTimeout(timer);-->
<!--        megaMenu.style.display = 'block';-->
<!--      });-->

<!--      dropdown.addEventListener('mouseleave', () => {-->
<!--        timer = setTimeout(() => {-->
<!--          megaMenu.style.display = 'none';-->
<!--        }, 200);-->
<!--      });-->

<!--      megaMenu.addEventListener('mouseenter', () => {-->
<!--        clearTimeout(timer);-->
<!--        megaMenu.style.display = 'block';-->
<!--      });-->

<!--      megaMenu.addEventListener('mouseleave', () => {-->
<!--        timer = setTimeout(() => {-->
<!--          megaMenu.style.display = 'none';-->
<!--        }, 200);-->
<!--      });-->
<!--    } else {-->
      // Mobile toggle menu
<!--      const toggle = dropdown.querySelector('.nav-link');-->

<!--      toggle.addEventListener('click', function (e) {-->
        // Only prevent default if mega menu is hidden
<!--        if (megaMenu.style.display !== 'block') {-->
          e.preventDefault(); // block default only if you want to toggle mega menu
<!--          megaMenu.style.display = 'block';-->
<!--        } else {-->
          // Allow default navigation to services.php
<!--          window.location.href = toggle.getAttribute('href');-->
<!--        }-->
<!--      });-->
<!--    }-->
<!--  });-->
<!--</script>-->
<!-- Swiper JS -->
<!--<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>-->
<!--<script>-->
<!--  const swiper = new Swiper(".testimonialSwiper", {-->
<!--    slidesPerView: 1,-->
<!--    spaceBetween: 30,-->
<!--    loop: true,-->
<!--    pagination: {-->
<!--      el: ".swiper-pagination",-->
<!--      clickable: true,-->
<!--    },-->
<!--    autoplay: {-->
<!--      delay: 4000,-->
<!--      disableOnInteraction: false,-->
<!--    },-->
<!--    breakpoints: {-->
<!--      768: {-->
<!--        slidesPerView: 2,-->
<!--      },-->
<!--      992: {-->
<!--        slidesPerView: 3,-->
<!--      }-->
<!--    }-->
<!--  });-->
<!--</script>-->


<!--</body>-->
<!--</html>-->