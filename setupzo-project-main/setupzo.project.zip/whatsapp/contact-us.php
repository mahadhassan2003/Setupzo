<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$alert = "";

// DB connection
$conn = new mysqli("localhost", "u259563098_setupzo", "Setupzo123", "u259563098_setupzo");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Show alert on success
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $alert = '<div class="alert alert-success text-center fw-bold">Your message has been sent successfully!</div>';
}

// Form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (!preg_match('/^\+?[0-9]{7,15}$/', $phone)) {
        echo "<script>alert('Invalid phone number format. Please enter 7 to 15 digits, optionally starting with +'); window.location.href = window.location.pathname;</script>";
        exit;
    }

    if (!$name || !$email || !$phone || !$message) {
        $alert = '<div class="alert alert-danger text-center fw-bold">All fields are required.</div>';
    } else {
        $stmt = $conn->prepare("SELECT id FROM contactus WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $alert = '<div class="alert alert-warning text-center fw-bold">You have already contacted us.</div>';
        } else {
            $stmt = $conn->prepare("INSERT INTO contactus (name, email, phone, messsage) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $phone, $message);
            $stmt->execute();

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'info@setupzo.com';
                $mail->Password = 'gupy jyfz qydd xzau';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;
                $mail->isHTML(true);

                $mail->setFrom('info@setupzo.com', 'Setup Zo');
                $mail->addAddress('info@setupzo.com', 'Admin');
                $mail->Subject = "New Contactus Form Submission";
                $mail->Body = "
                    <h3>New Contact Message</h3>
                    <p><strong>Name:</strong> $name</p>
                    <p><strong>Email:</strong> $email</p>
                    <p><strong>Phone:</strong> $phone</p>
                    <p><strong>Message:</strong> $message</p>
                ";
                $mail->send();

                $mail->clearAddresses();
                $mail->addAddress($email, $name);
                $mail->Subject = "Thank You for Contacting Setup Zo";
                $mail->Body = "
                    <html>
                    <body style='font-family: Arial, sans-serif;'>
                        <h2 style='color: #28a745;'>Thank You, $name!</h2>
                        <p>We have received your message:</p>
                        <blockquote style='background:#f8f9fa;padding:10px;border-left:3px solid #007bff;'>
                            $message
                        </blockquote>
                        <p>Our team will contact you at <strong>$email</strong> or <strong>$phone</strong> shortly.</p>
                        <p>Regards,<br><strong>Setup Zo Team</strong></p>
                    </body>
                    </html>
                ";
                $mail->send();

                header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
                exit;
            } catch (Exception $e) {
                $alert = '<div class="alert alert-warning text-center fw-bold">Message saved but email failed to send.</div>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Setupzo – Trusted Business Setup in Dubai, UAE</title>
     <meta name="description" content="Contact Setupzo for expert mainland & free zone business setup in Dubai. Call, email, or fill out our form to book a free consultation today.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css"/>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
        }
        .hero-image {
            height: 90vh;
            background-image: url('uploads/mainland.jpg');
            background-size: cover;
            background-position: center;
            position: relative;
            color: white;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .hero-text {
            background-color: rgba(0,0,0,0.5);
            padding: 40px;
            border-radius: 10px;
        }
        .contact-form-container {
            background: #f4f4f4;
            padding: 50px 20px;
        }
        .iti {
            width: 100%;
        }
    </style>
</head>
<body>
    
       <?php include 'navbar.php'; ?>
<!-- Hero Section -->
<div class="hero-image">
    <!--<div class="hero-text">-->
        <!--<h1 class="display-4 fw-bold">Contact Setup Zo</h1>-->
        <!--<p class="lead">We'd love to hear from you.</p>-->
    <!--</div>-->
</div>
 
 <div class="container mt-6">
  <h1 style="font-weight:600;"> Contact Setupzo</h1>
</div>
<div class="container py-3 bg-light">
<section class="pt-4">
  <div class="container">
    <h4>Contact Setupzo – Start Your Business Setup in Dubai, UAE Today</h4>
    <p style="text-align:justify;">
    At Setupzo, we make business setup in Dubai, UAE fast, simple, and fully compliant. Whether you need help with mainland company formation, free zone business setup, or company registration, our expert consultants are here to guide you every step of the way. Don't hesitate to get in touch with us today and take the first step toward launching your dream business in Dubai. 
    
    </p>
  </div>
</section>
<!--<div class="container py-3 bg-light">-->
<!--<section > -->
<!--  <div class="container">-->
<!--    <h4 >Get in Touch with Us</h4>-->
<!--    <p style="text-align:justify;">-->
<!--     We respond to all inquiries within 24 hours during working days. Fill out the quick form below or contact us directly our team is ready to assist you.  -->
    
<!--    </p>-->
<!--  </div>-->
<!--</section>-->
<!-- </div>-->
<section > 
<div class="container py-3 bg-light">
<div class="container">
     <h4 style="font-weight:600;">   Direct Contact Information</h4>
    
📞 Phone: +971568677227<br>
💬 WhatsApp: +971568677227<br>
📧 Email: info@setupzo.com<br>
🕒 Working Hours: Monday – Saturday, 9:00 AM – 6:00 PM<br>
</div>
</div>

</section>
<section > 
<div class="container py-3 bg-light">
<div class="container">
     <h4 style="font-weight:600;">  Why Contact Setupzo?</h4> 
      ✅ Fast Response – We reply within 24 hours<br>
      ✅ Free Initial Consultation – No obligation, just expert advice.<br>
      ✅ Expert Guidance – Mainland & free zone specialists.<br>
      ✅ International Client Support – Set up your Dubai business remotely.<br>

  
</div>
</section>

<section > 
<div class="container py-3 bg-light">
<div class="container">
     <h4 style="font-weight:600;">Let’s Get Started</h4> 
      <p style="text-align:justify;">Your Dubai business journey begins here. Whether you’re ready to start or just exploring your options, our consultants are here to make the process easy, transparent, and affordable.</p>
       <a href="#" class="btn text-white py-2 px-3 ms-lg-4" style="background-color: #1e2355;">Apply Now</a>
      
      
  
</div>
</section>

</div>
 
 
  

<!-- Contact Form -->
<div class="container contact-form-container">
    <!--<h2 class="text-center mb-4">Get In Touch</h2>-->
    <?php echo $alert; ?>
    <form method="POST" id="contactForm" class="col-md-8 offset-md-2">
        <div class="mb-3">
            <label class="form-label">Name:</label>
            <input type="text" name="name" class="form-control py-3" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Email:</label>
            <input type="email" name="email" class="form-control py-3" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone:</label>
            <input type="tel" name="phone" id="phone" class="form-control py-3" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Message:</label>
            <textarea name="message" rows="5" class="form-control" required></textarea>
        </div>
       <div class="d-grid">
  <button type="submit" id="submitBtn" class="btn btn-lg text-white" style="background-color:#1e2355; border-color:#1e2355;">
    Submit
  </button>
</div>
    </form>
</div>
<?php include_once("footer.php") ?>

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>
<script>
    const phoneInput = document.querySelector("#phone");
    const iti = window.intlTelInput(phoneInput, {
        initialCountry: "auto",
        geoIpLookup: function(callback) {
            fetch("https://ipinfo.io?token=b8604525b76188")
                .then(response => response.json())
                .then(data => {
                    const countryCode = data.country ? data.country : "US";
                    callback(countryCode);
                })
                .catch(() => callback("US"));
        },
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"
    });

    document.getElementById("contactForm").addEventListener("submit", function(e) {
        phoneInput.value = iti.getNumber();
        if (!iti.isValidNumber()) {
            alert("Please enter a valid phone number.");
            e.preventDefault();
            return;
        }

        const submitBtn = document.getElementById("submitBtn");
        submitBtn.disabled = true;
        submitBtn.textContent = "Sending...";
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
