<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>UAE Employee Visa | Setupzo</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
      * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 90vh; /* 80% of viewport height */
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Image covers full area */
      display: block;
    }
    .content-section {
         width: 90%;
      margin: auto;
    }
    .content-section h1{
      color: #1E2355;
    } 
    .FAQS h1{
      color: #1E2355;
    }

    .FAQS h5{
      color: black; 
    }
    .FAQS{
       width: 80%;
      margin: auto;
      padding: 20px;
      background-color: #ffffff; 
    }
    .FAQS p{
      padding-left: 20px;
    }
    
  </style>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<?php include_once("navbar.php") ?>
<!-- Image Section -->
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Full Cover Image">
  </div>

<div class="col-lg-10 col-md-10 col-sm-12 mx-auto py-5" style=" background-color:#FBFBFB;">
    <h4><b>EMPLOYEE VISA</b></h4><br>
  <h4><b>Start Your UAE Employment Journey Today, Simple & Efficient Process</b></h4>
<!--<h5 class="text-decoration-underline"><strong>Important: Kindly choose and use one of the following lines</strong></h5>-->
<p>Begin your professional journey in the UAE with Setupzo — we simplify the employee visa process so you can focus on your career growth and stability</p>
 <a href="employee.php" class="btn btn-primary py-2 my-2" style="background-color: #1e2355;">Apply Online</a>
  <h4><b>Benefits of the UAE Employee Visa</b></h4>
  <ul class=" mb-5">
    <li class=""><h6 class="fw-bold">Legal Employment Status:</h6>The UAE Employee Visa provides legal authorization to work for your sponsoring employer in the UAE, ensuring compliance with local labor laws.</li>
    <li class=""><h6 class="fw-bold">Residency Rights:</h6>Enjoy the right to live in the UAE for the duration of your employment contract, typically 2-3 years with options for renewal.</li>
    <li class=""><h6 class="fw-bold">Comprehensive Benefits:</h6>Employee visa holders often receive benefits including health insurance, annual leave, and end-of-service gratuity as per UAE labor law.</li>
    <li class=""><h6 class="fw-bold">Family Sponsorship:</h6>After meeting salary requirements, you can sponsor your immediate family members to live with you in the UAE.</li>
    <li class=""><h6 class="fw-bold">Banking Facilities:</h6>With an employee visa, you can open UAE bank accounts and access local financial services more easily.</li>
    <li class=""><h6 class="fw-bold">Career Stability:</h6>The visa provides a stable foundation for building your career in one of the world's most dynamic job markets.</li>
    <li class=""><h6 class="fw-bold">Access to Services:</h6>Employee visa holders can access healthcare, education, and other public services available to UAE residents.</li>
    <li class=""><h6 class="fw-bold">Pathway to Long-Term Residency:</h6>Successful employment in the UAE can lead to eligibility for long-term visas like the Golden Visa based on professional achievements.</li>
  </ul>

 <h4><b>Eligibility Criteria for the UAE Employee Visa</b></h4>
  <p>The UAE Employee Visa is available to foreign nationals who have secured employment with a UAE-based company. The sponsoring employer typically handles the visa application process.</p>
  <ul class=" mb-5">
    <li class=""><strong>Employment Contract:</strong> Valid job offer from a UAE-registered company</li>
    <li class=""><strong>Educational Qualifications:</strong> Relevant degrees or professional certifications for the position</li>
    <li class=""><strong>Professional Experience:</strong> Appropriate work experience as required for the role</li>
    <li class=""><strong>Health Requirements:</strong> Medical fitness as per UAE government standards</li>
    <li class=""><strong>Security Clearance:</strong> Clean criminal record from home country and previous residences</li>
  </ul>
<h4><b>UAE Employee Visa Duration Details</b></h4>
<p>The UAE Employee Visa is typically issued for standard durations tied to employment contracts, with options for renewal based on continued employment.</p>

 <h4><b>Types of UAE Employee Visa Validity:</b></h4>
  <ul class=" mb-5">
    <li class="">
        <h6 class="fw-bold">Standard Employee Visa</h6>
        <p>Issued for 2-3 years depending on the employment contract, renewable as long as employment continues.</p>
    </li>
    <li class="">
        <h6 class="fw-bold">Probationary Visa</h6>
        <p>Some employers may issue a 6-month probationary visa before converting to a standard employment visa.</p>
    </li>
     <li class="">
        <h6 class="fw-bold">Specialized Professional Visas</h6>
        <p>Certain professions like doctors, engineers, and teachers may have specific visa categories with different validity periods.</p>
    </li>
  </ul>

 <h4><b>Documents Required for Applying for the UAE Employee Visa</b></h4>
  <p>The specific documents required for an Employee Visa application are typically handled by the sponsoring employer, but employees need to provide certain personal documents.</p>
  <h4><b>General Documents Required from Employee:</b></h4>
  <ul class=" mb-5">
    <li class=""><strong>Passport Copies:</strong> Clear copies of your passport with at least 6 months validity.</li>
    <li class=""><strong>Photographs:</strong> Recent passport-sized color photographs with white background.</li>
    <li class=""><strong>Educational Certificates:</strong> Copies of relevant degrees or professional certifications, properly attested.</li>
    <li class=""><strong>Experience Certificates:</strong> Proof of previous employment and professional experience.</li>
    <li class=""><strong>Medical Test Results:</strong> Completed after entering UAE on entry permit.</li>
    <li class=""><strong>Security Clearance:</strong> Police clearance certificate from home country.</li>
  </ul>
<h4><b>Family Sponsorship with Employee Visa</b></h4>
  <p>The UAE Employee Visa allows you to sponsor your immediate family members to live with you in the country, subject to meeting certain requirements.
<br><br>
To sponsor your family, you typically need to earn a minimum salary (usually AED 4,000-5,000 per month depending on the emirate) and provide suitable accommodation. Sponsorship covers your spouse and children under 18 (extendable to sons up to 25 if they're students and unmarried daughters indefinitely).
 <br><br>
The process involves additional documentation including marriage certificates, birth certificates for children, and proof of meeting salary and housing requirements. Your employer may assist with the sponsorship process or you can handle it through typing centers or service providers.</p>
<h4><b>UAE Employee Visa Application Process Explained</b></h4>
<p> The UAE Employee Visa process involves several steps coordinated between the employer and employee. Here's a typical workflow:</p>
  <h4><b>Application Process</b></h4>
  <ol type="">
  <h6 class="fw-bold"><li>Step 1: Job Offer and Contract Signing</h6><p><ul>
    <li>
        Receive and sign an employment offer from a UAE-based company.
    </li>
    <li>The employer begins the visa application process with the Ministry of Human Resources and Emiratisation (MOHRE).</li>
   </ul></p></li>
   <h6 class="fw-bold"><li>Step 2: Entry Permit Application</h6><p><ul><li>Employer applies for your entry permit to legally enter the UAE for employment purposes.</li><li>Once approved, you can enter the UAE to complete remaining procedures.</li></ul></p></li>
     <h6 class="fw-bold"><li>Step 3: Medical Test and Emirates ID</h6><p><ul><li>Complete mandatory medical tests for communicable diseases.</li><li>Apply for Emirates ID, the UAE's national identification system.</li></ul></p></li>
     <h6 class="fw-bold"><li>Step 4: Visa Stamping and Labor Card</h6><p><ul><li>Your passport is stamped with the residence visa.</li><li>Employer obtains your labor card/work permit from MOHRE.</li></ul></p></li>
      <h6 class="fw-bold"><li>Step 5: Complete Onboarding</h6><p><ul><li>Finalize bank account opening, health insurance enrollment, and other onboarding processes.</li><li>Begin employment according to your contract terms.</li></ul></p></li>
  </ol>

<h4><b>UAE Employee Visa for New Hires</b></h4>
  <p>If you are being hired from outside the UAE, the process includes additional considerations:</p>
  <ul class=" mb-5">
    <li class="">You'll enter UAE on the entry permit issued by your employer.</li>
    <li class="">Medical tests and biometrics for Emirates ID must be completed within the UAE.</li>
    <li class="">The entire process typically takes 2-6 weeks depending on various factors.</li>
    <li class="">Your employer is responsible for most of the process and associated costs.</li>
    <p>At Setupzo, we assist both employers and employees with the visa application process, ensuring compliance with all UAE regulations.</p>
  </ul>

<h4><b>Ready to Begin Your UAE Employment Journey?</b></h4>
  <p class="">Take the first step toward a rewarding career in one of the world's most dynamic economies. The UAE Employee Visa offers you the opportunity to build your professional life while enjoying the benefits of UAE residency.
At Setupzo, we simplify the employment visa process, whether you're an employer seeking to hire international talent or a professional moving to the UAE. Contact us today to start your UAE employment journey with confidence.</p>


  <h2 class="fw-bold mt-5 mb-3">Frequently Asked Questions (FAQs)</h2>
 <div class="accordion" id="accordionExample">
  <!-- Item 1 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
        aria-expanded="true" aria-controls="collapseOne">
        What is a UAE Employee Visa?
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <p>A UAE Employee Visa is a residence permit that allows foreign nationals to legally work and live in the UAE under the sponsorship of their employer. It's typically valid for 2-3 years and tied to your employment contract.</p>
      </div>
    </div>
  </div>

  <!-- Item 2 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo"
        aria-expanded="false" aria-controls="collapseTwo">
        Who is responsible for the Employee Visa process?
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <p>The sponsoring employer is primarily responsible for initiating and managing the visa process, though the employee must provide necessary documents and complete certain steps like medical tests.</p>
      </div>
    </div>
  </div>

  <!-- Item 3 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree"
        aria-expanded="false" aria-controls="collapseThree">
        How long does the Employee Visa process take?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        The entire process typically takes 2-6 weeks from job offer to visa issuance, depending on document preparation, medical test results, and government processing times.
      </div>
    </div>
  </div>

  <!-- Item 4 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour"
        aria-expanded="false" aria-controls="collapseFour">
        What is the minimum salary to sponsor family?
      </button>
    </h2>
    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        The requirement varies by emirate but is typically AED 4,000-5,000 per month. Some emirates may require higher amounts for sponsoring male children above 18 years.
      </div>
    </div>
  </div>

  <!-- Item 5 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive"
        aria-expanded="false" aria-controls="collapseFive">
        Can I change jobs with an Employee Visa?
      </button>
    </h2>
    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        Yes, but there are specific procedures. You may need to complete a certain period with your current employer or obtain a no-objection certificate. The new employer would need to process a visa transfer.
      </div>
    </div>
  </div>

  <!-- Item 6 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix"
        aria-expanded="false" aria-controls="collapseSix">
        What happens if I lose my job?
      </button>
    </h2>
    <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        You typically have a grace period (usually 30-90 days) to either find new employment and transfer your visa or leave the country. New regulations allow for self-sponsorship options in some cases.
      </div>
    </div>
  </div>

  <!-- Item 7 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven"
        aria-expanded="false" aria-controls="collapseSeven">
        Is health insurance mandatory for Employee Visa holders?
      </button>
    </h2>
    <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        Yes, employers are required to provide health insurance coverage for their employees in most emirates. Dubai has particularly strict health insurance requirements.
      </div>
    </div>
  </div>

  <!-- Item 8 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingEight">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight"
        aria-expanded="false" aria-controls="collapseEight">
        Can I work for another company with my Employee Visa?
      </button>
    </h2>
    <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        No, your Employee Visa ties you to your sponsoring employer. To work for another company, you'd need to either transfer your visa or have the new company apply for a new visa.
      </div>
    </div>
  </div>

  <!-- Item 9 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingNine">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine"
        aria-expanded="false" aria-controls="collapseNine">
        What are the medical requirements for an Employee Visa?
      </button>
    </h2>
    <div id="collapseNine" class="accordion-collapse collapse" aria-labelledby="headingNine"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        All applicants must undergo medical tests for HIV, hepatitis, tuberculosis, and sometimes other conditions. Certain medical conditions may lead to visa denial or deportation.
      </div>
    </div>
  </div>

  <!-- Item 10 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingTen">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen"
        aria-expanded="false" aria-controls="collapseTen">
        How does Setupzo help with the Employee Visa process?
      </button>
    </h2>
    <div id="collapseTen" class="accordion-collapse collapse" aria-labelledby="headingTen"
      data-bs-parent="#accordionExample">
      <div class="accordion-body">
        Setupzo assists both employers and employees with the entire visa process—from document preparation and application submission to medical test coordination, Emirates ID processing, and visa renewals. We ensure compliance with all UAE regulations for a smooth experience.
      </div>
    </div>
  </div>
</div>

</div>
<?php include_once("footer.php") ?>
<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>