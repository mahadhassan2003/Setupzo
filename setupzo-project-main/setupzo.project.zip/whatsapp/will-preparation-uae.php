<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Setupzo | Will Preparation in UAE – Make a Will Easily | </title>
  <meta name="description" content="Make a will online in the UAE with Setupzo. Our experts simplify making a living will and legal will preparation to protect your assets and loved ones.">
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 90vh; /* 80% of viewport height */
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Image covers full area */
      display: block;
    }
    .content-section {
         width: 90%;
      margin: auto;
      background-color: #ffffff; 
    }
    .content-section h2{
    } 
    .FAQS h2{
      color: #1E2355;
    }

    .FAQS h5{
      color: black; 
    }
    .FAQS{
       width: 90%;
      margin: auto;
      background-color: #ffffff; 
    }
    .FAQS p{
      padding-left: 20px;
    }
    
  </style>
</head>
<body>
<?php include_once("navbar.php") ?>
<!-- Navbar -->

<!-- Image Section -->
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Full Cover Image">
  </div>



<!-- Content Section -->
<div class="content-section container col-lg-10 col-md-10 col-sm-12 pt-5" style=" background-color:#FBFBFB;">
    <h2 class="fw-bold">Will Preparation</h2>
    <br>
<h6>Professional Will Registration Services in Dubai and the UAE</h6>
<br>
 <h4><b>Protect Your Family and Assets Through Will Registration in the UAE </b></h4>
<p>Planning for the future can feel overwhelming, but it doesn’t have to be. Our expert will preparation service helps you create a legally valid will under DIFC’s common law system, ensuring your wishes are respected across all  Emirates in the UAE.</p>
 <h4><b>What is a will? </b></h4>
<p>A Will is a legally binding document that outlines how your assets, property, and personal belongings should be distributed after your death. It also allows you to appoint guardians for your minor children and specify any personal wishes you may have regarding your estate, funeral, or other final matters.</p>
<p>In the UAE, especially for non-Muslim expatriates, having a well-drafted Will is essential to ensure that your estate is distributed according to your own wishes, and not under Sharia law, which may otherwise apply by default. A Will provides you with peace of mind that your loved ones are protected and your intentions are respected.</p>
 <h4><b>The Importance of Registering Your Will Legally </b></h4>
 <h4><b>Advantages of Registered Wills </b></h4>
<p>Registering your Will in the UAE is a vital step to protect your assets and ensure your final wishes are legally recognized and enforced. At Setupzo, we simplify the Will registration process to help you avoid disputes among heirs and ensure that your estate, including property, bank accounts, and investments, is distributed exactly as you intend under UAE inheritance laws. For non-Muslim expatriates, our expert services ensure you benefit from additional protection by bypassing Shariah inheritance rules through the official Notary Public or DIFC Courts. </p>
<p>Including guardianship provisions for minor children in your Will provides peace of mind, ensuring their care is handled according to your wishes and preventing family conflicts. With Setupzo’s guidance, completing a legally sound and registered Will in Dubai is a smooth and stress-free experience, giving you clarity, control, and confidence for your loved ones during difficult times.</p>
 <h4><b>Key Benefits of Will Registration in the UAE </b></h4>
<ul>
    <li><h6 class="fw-bold">Legal Recognition and Enforcement</h6><p>A registered Will is officially recognized by Dubai Courts, ensuring your final wishes are legally binding and protected under UAE law.</p></li>
    <li><h6 class="fw-bold">Avoidance of Inheritance Disputes</h6><p>Clear documentation of your estate distribution helps prevent conflicts among heirs, providing a smooth and peaceful transfer of assets.</p></li>
     <li><h6 class="fw-bold">Protection for Non-Muslim Expats</h6><p>Will registration allows non-Muslim residents to bypass Shariah inheritance rules, ensuring their assets are distributed according to their personal wishes.</p></li>
     <li><h6 class="fw-bold">Simplified Probate Process</h6><p>A registered Will speeds up the probate process, reducing delays and making it easier for your family to settle your estate efficiently.</p></li>
    <li><h6 class="fw-bold">Appointment of Guardians for Minor Children</h6><p>You can legally appoint trusted guardians for your minor children, ensuring their care and upbringing are handled according to your preferences.</p></li>
   <li><h6 class="fw-bold">Nomination of Beneficiaries and Executors</h6><p>Registering your Will lets you clearly designate who inherits your assets and who is responsible for executing your wishes, giving you greater control over your estate.</p></li>
   <li><h6 class="fw-bold">Ability to Leave Specific Instructions</h6><p>You can include detailed directions regarding your property, investments, funeral arrangements, and other personal matters to avoid any confusion later.</p></li>
  <li><h6 class="fw-bold">Peace of Mind for You and Your Family</h6><p>8.Having a legally registered Will provides reassurance that your estate will be managed and distributed smoothly, reducing stress for your loved ones during difficult times.</p></li>
</ul>
 <h4><b>Wills for Muslims and Non-Muslims </b></h4>
<p>At Setupzo, we help both Muslim and non-Muslim residents prepare Wills that meet their specific needs. For Muslims, we ensure full compliance with Shariah and Faraid principles. For non-Muslims, we offer Wills that follow UAE civil law, protecting your assets without Shariah rules. Our goal is to make sure your estate is distributed fairly and according to your wishes, giving you peace of mind.</p>
<div class="row">
   <div class="col-lg-6 col-md-8 col-sm-12 mx-auto border py-5 rounded">
    <h4><b>Islamic Wills (Muslim Wills)</h4>
    <h4>Sharia-Compliant Will Registration</b></h4>
    <h6 class="fw-bold">Key Features</h6>
    <ul>
        <li>Complete compliance with Islamic (Shariah) inheritance laws</li>
        <li>Asset distribution as per Faraid principles</li>
        <li>Asset distribution as per Faraid principles</li>
        <li>Asset distribution as per Faraid principles</li>
        <li>Asset distribution as per Faraid principles</li>
    </ul>
    <h6 class="fw-bold">What’s Included:</h6>
    <ul>
     <li>Accurate Islamic inheritance calculation</li>
     <li>Appointment of Muslim guardians for minors</li>
     <li>Fair distribution among heirs</li>
     <li>Optional Wasiyya (up to 1/3 of estate)</li>
     <li>Zakat and charity provisions</li>
     <li>Sharia court verification</li>
    </ul>
   </div>
   <div class="col-lg-6 col-md-8 col-sm-12 mx-auto border rounded py-5">
     <h4><b>Islamic Wills (Muslim Wills) </h4>
    <h4>Sharia-Compliant Will Registration</b></h4>
     <h6 class="fw-bold">Key Features</h6>
    <ul>
        <li>Complete compliance with Islamic (Shariah) inheritance laws</li>
        <li>Asset distribution as per Faraid principles</li>
        <li>Asset distribution as per Faraid principles</li>
        <li>Asset distribution as per Faraid principles</li>
        <li>Asset distribution as per Faraid principles</li>
    </ul>
    <h6 class="fw-bold">What’s Included:</h6>
    <ul>
     <li>Accurate Islamic inheritance calculation</li>
     <li>Appointment of Muslim guardians for minors</li>
     <li>Fair distribution among heirs</li>
     <li>Optional Wasiyya (up to 1/3 of estate)</li>
     <li>Zakat and charity provisions</li>
     <li>Sharia court verification</li>
    </ul>
   </div>
</div>
 <h4><b>Documents Required for Will Registration in UAE </b></h4>
    <ul>
       <h4><b>Personal Identification </b></h4>
    <li> Passport copy of the testator (person making the Will)</li>
    <li> Emirates ID copy (if applicable)</li>
    <h4><b>Family & Beneficiary Information </b></h4>
    <li> Family declaration (marital status, children’s details)</li>
    <li> Passport copies of beneficiaries</li>
    <li> Emirates ID copies of beneficiaries (if applicable)</li>
    <h4><b>Executor & Guardian Details </b></h4>
    <li> Appointment details of executors and sub-executors</li>
    <li> Passport and Emirates ID copies of executors</li>
    <li> Guardian appointment details (for minor children)</li>
    <li> Passport and Emirates ID copies of guardians</li>
     <h4><b>Asset Documentation </b></h4>
    <li> List of all assets included in the Will (real estate, bank accounts, businesses)</li>
    <li>Title deeds for UAE properties</li>
    <li> Company ownership documents for business interests</li>
     <h4><b>Witness Information (For DIFC Wills) </b></h4>
    <li> Full details of two witnesses, including passport and Emirates ID copie</li>
     <h4><b>Additional Documents (If Applicable) </b></h4>
    <li>Funeral and burial instructions (optional)</li>
    <li>Contact details of next of kin</li>
    </ul>
     

    </div>
     <div class="container">
    <h2 class="mb-4 fw-bold">FAQs - Will Registration in the UAE</h2>
    
    <div class="accordion" id="faqAccordion">

      <!-- FAQ 1 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingOne">
          <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
            1. What is will registration in the UAE?
          </button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Will registration in the UAE is the legal process of documenting your wishes for asset distribution after death. Setupzo ensures your will is respected under UAE laws.
          </div>
        </div>
      </div>

      <!-- FAQ 2 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingTwo">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
            2. Who can register a will in the UAE?
          </button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Any expatriate or UAE resident can register a will. Setupzo especially helps expatriates secure their assets, as local laws may differ from their home countries.
          </div>
        </div>
      </div>

      <!-- FAQ 3 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingThree">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
            3. Is a registered will mandatory in the UAE?
          </button>
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            A registered will is not mandatory but highly recommended. Setupzo advises this to avoid disputes and ensure your wishes are honored.
          </div>
        </div>
      </div>

      <!-- FAQ 4 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingFour">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour">
            4. Where can I register my will in the UAE?
          </button>
        </h2>
        <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            You can register your will at DIFC Courts, Abu Dhabi Judicial Department, or other legal entities. Setupzo guides you through these recognized registration centers.
          </div>
        </div>
      </div>

      <!-- FAQ 5 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingFive">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive">
            5. What are the costs involved in registering a will?
          </button>
        </h2>
        <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Costs vary depending on the institution and will complexity. Setupzo provides transparent pricing tailored to your estate's needs.
          </div>
        </div>
      </div>

      <!-- FAQ 6 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingSix">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix">
            6. How long does it take to register a will?
          </button>
        </h2>
        <div id="collapseSix" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Registration usually takes from a few days up to two weeks. Setupzo assists in speeding up the process with complete documentation.
          </div>
        </div>
      </div>

      <!-- FAQ 7 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingSeven">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven">
            7. What documents are needed for will registration?
          </button>
        </h2>
        <div id="collapseSeven" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            You’ll need identification, asset details, and executor and beneficiary information. Setupzo helps you gather and prepare all required documents.
          </div>
        </div>
      </div>

      <!-- FAQ 8 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingEight">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight">
            8. Can I amend my will after registration?
          </button>
        </h2>
        <div id="collapseEight" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Yes, you can update your will anytime. Setupzo makes amending your will simple to reflect life changes like marriage or new assets.
          </div>
        </div>
      </div>

      <!-- FAQ 9 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingNine">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine">
            9. Is a will registered in my home country valid in the UAE?
          </button>
        </h2>
        <div id="collapseNine" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Usually not, due to different legal systems. Setupzo recommends registering a separate will in the UAE for full legal compliance.
          </div>
        </div>
      </div>

      <!-- FAQ 10 -->
      <div class="accordion-item">
        <h2 class="accordion-header" id="headingTen">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen">
            10. What happens if I die without a will in the UAE?
          </button>
        </h2>
        <div id="collapseTen" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Your assets will be distributed according to Sharia law or local rules, which may not match your wishes. Setupzo helps you avoid this uncertainty with proper will registration.
          </div>
        </div>
      </div>

    </div>
  </div>
<?php include_once("footer.php") ?>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>