<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - UAE Business Services</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
    }

    .hero {
      background: url('uploads/mainland.jpg') center center/cover no-repeat;
      height: 100vh;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
    }

    .hero h1 {
      font-size: 3.5rem;
      text-shadow: 2px 2px 5px rgba(0,0,0,0.5);
    }

    .hero p {
      font-size: 1.2rem;
    }

    .services-section i {
      font-size: 2.5rem;
      color: #0d6efd;
    }

    .testimonial-section {
      background-color: #f8f9fa;
      padding: 60px 0;
    }

    .testimonial-carousel .item blockquote {
      font-size: 1.1rem;
      font-style: italic;
      padding: 20px;
      background: #fff;
      border-left: 5px solid #0d6efd;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .brand-carousel img {
      max-height: 70px;
      object-fit: contain;
      filter: grayscale(100%);
      transition: filter 0.3s ease;
    }

    .brand-carousel img:hover {
      filter: none;
    }

    .faq-section h4 {
      font-weight: bold;
    }

    .call-to-action {
      background-color: #0d6efd;
      color: white;
      padding: 60px 0;
    }

    .contact-brief {
      background: #f0f8ff;
      padding: 60px 0;
    }
    .carid:hover{
      background-color:#EEEEEE;
    }
  </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<!-- Hero Section -->
<section class="hero">
  <div class="container">
    <h1>Empowering Your Business Journey in UAE</h1>
    <p class="lead mt-3">Freezone • Mainland • Visas • Payroll • Insurance • Compliance</p>
    <a href="services.php" class="btn btn-lg mt-4 fw-bold" style="background-color:#1e2355;color:white">Explore Services</a>
  </div>
</section>

<!-- Who We Are -->
<section class="py-5 bg-light">
  <div class="container">
    <h2 class="text-center mb-4">Who We Are</h2>
    <p class="text-center lead">
      We are UAE's trusted business services provider — helping local and international entrepreneurs launch and grow companies across Freezones and the Mainland. Our mission is to simplify company formation, visa processes, payroll, and compliance under one expert roof.
    </p>
  </div>
</section>

<!-- Mission & Vision -->
<section class="py-5">
  <div class="container">
    <div class="row g-5">
      <div class="col-md-6">
        <h3>Our Mission</h3>
        <p>
          To deliver reliable, scalable, and transparent services for business setup, employee compliance, and investor support across the UAE. We aim to be the backbone for SMEs and corporations looking to streamline operations and focus on growth.
        </p>
      </div>
      <div class="col-md-6">
        <h3>Our Vision</h3>
        <p>
          To be the most recommended partner for business services in the UAE — through innovation, efficiency, and client-focused delivery in every service we offer.
        </p>
      </div>
    </div>
  </div>
</section>

<!-- Our Services -->
<section id="services" class="py-5 bg-light services-section">
  <div class="container">
    <h2 class="text-center mb-5">Our Services</h2>
    <div class="row g-4 text-center">
      <div class="col-sm-6 col-md-4 rounded carid">
        <i class="bi bi-building"></i>
        <h5 class="mt-3">Freezone Business Setup</h5>
        <p>Affordable and fast Freezone registration with 100% ownership and zero tax.</p>
      </div>
      <div class="col-sm-6 col-md-4 rounded carid">
        <i class="bi bi-bank2"></i>
        <h5 class="mt-3">Mainland Licensing</h5>
        <p>Trade license, local sponsorship, and all PRO assistance under one roof.</p>
      </div>
      <div class="col-sm-6 col-md-4 rounded carid">
        <i class="bi bi-person-vcard"></i>
        <h5 class="mt-3">Golden & Residency Visas</h5>
        <p>Apply for long-term golden visas and residence visas for employees and investors.</p>
      </div>
      <div class="col-sm-6 col-md-4 rounded carid">
        <i class="bi bi-cash-coin"></i>
        <h5 class="mt-3">Payroll Compliance</h5>
        <p>Manage payroll in line with WPS & UAE laws, with tax reporting and secure payouts.</p>
      </div>
      <div class="col-sm-6 col-md-4 rounded carid">
        <i class="bi bi-heart-pulse"></i>
        <h5 class="mt-3">Health Insurance</h5>
        <p>Partnered with top insurers to offer employee and investor health coverage.</p>
      </div>
      <div class="col-sm-6 col-md-4 rounded carid">
        <i class="bi bi-gear-fill"></i>
        <h5 class="mt-3">PRO & Document Services</h5>
        <p>Emirates ID, labor contracts, attestation, renewals, and legal translation support.</p>
      </div>
    </div>
  </div>
</section>

<!-- Testimonials Carousel -->
<section class="testimonial-section">
  <div class="container">
    <h2 class="text-center mb-5">Client Testimonials</h2>
    <div class="owl-carousel owl-theme testimonial-carousel">
      <div class="item">
        <blockquote>
          “They made our Freezone registration effortless and fast. We were operating within 7 days!”
          <footer class="blockquote-footer mt-3">Sara K., <cite>CEO, TechNest FZ</cite></footer>
        </blockquote>
      </div>
      <div class="item">
        <blockquote>
          “Visa processing, payroll, insurance — all handled by one team. Very satisfied with the service.”
          <footer class="blockquote-footer mt-3">Ahmed T., <cite>Founder, Oasis Digital</cite></footer>
        </blockquote>
      </div>
      <div class="item">
        <blockquote>
          “Professional, timely, and extremely helpful. They know every rule and shortcut in the UAE business world.”
          <footer class="blockquote-footer mt-3">John L., <cite>Manager, Middle East Trading</cite></footer>
        </blockquote>
      </div>
    </div>
  </div>
</section>

<!-- Brand Carousel -->
<!-- <section class="py-5 bg-white">
  <div class="container">
    <h4 class="text-center mb-4">We Work With</h4>
    <div class="owl-carousel owl-theme brand-carousel">
      <div class="item"><img src="img/brands/brand1.png" class="img-fluid" alt="Brand 1"></div>
      <div class="item"><img src="img/brands/brand2.png" class="img-fluid" alt="Brand 2"></div>
      <div class="item"><img src="img/brands/brand3.png" class="img-fluid" alt="Brand 3"></div>
      <div class="item"><img src="img/brands/brand4.png" class="img-fluid" alt="Brand 4"></div>
      <div class="item"><img src="img/brands/brand5.png" class="img-fluid" alt="Brand 5"></div>
    </div>
  </div>
</section> -->

<!-- FAQs Section -->
<section class="faq-section py-5 bg-light">
  <div class="container">
    <h3 class="text-center mb-5">Frequently Asked Questions</h3>
    <div class="accordion" id="faqAccordion">
      <div class="accordion-item">
        <h4 class="accordion-header" id="faq1">
          <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapse1">How long does business setup take?</button>
        </h4>
        <div id="collapse1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
          <div class="accordion-body">Most Freezone setups complete within 5-7 business days. Mainland setups can take slightly longer depending on licensing needs.</div>
        </div>
      </div>
      <div class="accordion-item">
        <h4 class="accordion-header" id="faq2">
          <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse2">Can you assist with employee visas?</button>
        </h4>
        <div id="collapse2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">Yes. We handle employment visa applications, renewals, and cancellation services.</div>
        </div>
      </div>
      <div class="accordion-item">
        <h4 class="accordion-header" id="faq3">
          <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse3">Is health insurance mandatory?</button>
        </h4>
        <div id="collapse3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
          <div class="accordion-body">Yes. All employees and residents are required to have valid health insurance in UAE. We offer affordable options.</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Call To Action -->
<section class="call-to-action text-center">
  <div class="container">
    <h2 class="mb-3">Ready to Launch or Expand in the UAE?</h2>
    <p class="lead">Speak to our experts and get a personalized plan tailored to your business needs.</p>
    <a href="contactus.php" class="btn btn-light btn-lg mt-3 fw-bold" style="background-color:#1e2355;color:white;">Get In Touch</a>
  </div>
</section>

<!-- Contact Brief -->
<section class="contact-brief text-center">
  <div class="container">
    <h4>Need Support?</h4>
    <p class="mb-0">Email us at <a href="mailto:info@setupzo.com">info@setupzo.com</a> or call us at <strong>0568677227</strong>.</p>
  </div>
</section>

<?php include 'footer.php'; ?>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script>
  $(document).ready(function(){
    $(".testimonial-carousel").owlCarousel({
      loop:true,
      margin:20,
      nav:false,
      dots:true,
      autoplay:true,
      autoplayTimeout:5000,
      items:1
    });

    $(".brand-carousel").owlCarousel({
      loop:true,
      margin:20,
      nav:false,
      autoplay:true,
      autoplayTimeout:2000,
      responsive:{
        0:{ items:2 },
        600:{ items:3 },
        1000:{ items:5 }
      }
    });
  });
</script>

</body>
</html>
