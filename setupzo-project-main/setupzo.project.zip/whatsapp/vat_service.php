 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Responsive Layout with Navbar, Image & Content</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 90vh; /* 80% of viewport height */
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Image covers full area */
      display: block;
    }
    .content-section {
    width: 90%;
      margin: auto;
      background-color: #ffffff; 
    }
    .content-section h1{
      text-align:center ;
      color: #1E2355;
    } 
    .FAQS h1{
       text-align:center ;
      color: #1E2355;
    }

    .FAQS h5{
      color: black; 
    }
    .FAQS{
       width: 80%;
      margin: auto;
      padding: 20px;
      background-color: #ffffff; 
    }
    .FAQS p{
      padding-left: 20px;
    }
    
  </style>
</head>
<body>

<!-- Navbar -->
<!-- Image Section -->
 <?php include_once("navbar.php") ?>
<div class="image-container">
    <img src="uploads/mainland.jpg" class="img-fluid" alt="Full Cover Image">
  </div>



<!-- Content Section -->
<div class="content-section col-lg-10 col-md-10 col-sm-12 pt-5" style=" background-color:#FBFBFB;">
   <h4><b>VAT and CORPORATE</b>
 </h4>
 <h6 class="fw-bold">Tax Registration in UAE</h6>
  <p class="lh-base">Take the stress out of tax with expert guidance from Setupzo, your trusted partner for seamless VAT and Corporate Tax registration across the UAE. <br>
  <a href="vat.php" class="btn btn-primary py-2 my-4 mt-5" style="background-color: #1e2355;">Apply Online</a>
  <h4> <b>What is VAT and Corporate Tax?</b></h4>
  <p>VAT (Value Added Tax) is an indirect tax imposed on the sale of goods and services in the UAE. Introduced in 2018, the current VAT rate is 5%, and it's collected at each stage of the supply chain. The end consumer pays VAT, while businesses are responsible for collecting and submitting it to the Federal Tax Authority (FTA).<br>
  <br>
Corporate Tax, on the other hand, is a direct tax on business profits, introduced in the UAE from June 1, 2023. It applies to companies earning above a certain profit threshold. The standard corporate tax rate in the UAE is 9%, with a 0% rate for profits up to AED 375,000 to support small businesses and startups.</p>
 <h4> <b>Understanding the Registration Requirements </b></h4>
 <p>When it comes to VAT and Corporate Tax registration in the UAE, it's important to understand the criteria to ensure compliance. Here’s a breakdown of what you need to know.</p>
 <ul class=" mb-5">
 <li class=""><h6 class="fw-bold">Mandatory VAT Registration in UAE</h6>
  If your business operates in the UAE and your taxable supplies (goods or services) have exceeded AED 375,000 in the past 12 months, VAT registration is mandatory. This applies to both local and international sales. If you expect your taxable turnover to cross this threshold within the next 30 days, you are also required to register. Delaying VAT registration or failing to comply can result in significant penalties from the Federal Tax Authority (FTA), so it's important to keep your sales records up to date.</li>
 <li class=""><h6 class="fw-bold">Voluntary VAT Registration in UAE</h6>
 If your taxable supplies fall between AED 187,500 and AED 375,000, you can opt for voluntary VAT registration. This is a smart move for small businesses that want to reclaim VAT paid on purchases, helping improve cash flow. Voluntary registration also enhances your business credibility with clients and suppliers, as it shows you are tax-compliant and professionally managing your finances. It can be a strategic step toward future growth and expansion.</li>
 <li class=""><h6 class="fw-bold">Corporate Tax Registration Requirements in UAE</h6>
 All businesses in the UAE are required to register for Corporate Tax if their annual net profit exceeds AED 375,000. This rule applies to both mainland companies and free zone entities unless they qualify for a specific exemption. To register, you must obtain a Tax Registration Number (TRN) from the Federal Tax Authority (FTA). You’ll need your trade license and updated financial records when applying, so its important to prepare these documents in advance.</li>
 <li class=""><h6 class="fw-bold">Importance of Timely Compliance with UAE Tax Laws</h6>
 VAT and Corporate Tax registration have become a vital part of running a legal business in the UAE. Timely compliance not only helps you avoid fines but also builds your reputation as a transparent and trustworthy business. Being officially registered increases your business’s credibility with investors, customers, and government authorities. It also simplifies long-term financial planning, reporting, and growth strategies.
</li>
 </ul>
<h4><b>Documents Required for Tax Registration</b></h4>
<p>To register for taxes in the UAE, businesses must submit proper documentation through the FTA online portal. These documents help verify business identity, ownership, and financial eligibility.
    <br><br>
There are some documents common to both VAT and Corporate Tax registrations, while others are specific to each.</p>
<h4><b>List of Necessary Documents for VAT Registration</b></h4>
<h6>Here’s a checklist of required documents for VAT registration in the UAE:</h6>
<ul>
 <li> Rade License Copy</li>
 <li> Emirates ID and Passport of Business Owner(s)</li>
 <li> Memorandum of Association (MOA) or similar company formation document</li>
 <li> Bank Account Details (IBAN)</li>
 <li> Customs Registration (if applicable) </li>
 <li> Financial Statements or Turnover Proof (last 12 months)</li>
 <li> Description of Business Activities </li>
 <li> Contact Details and Company Address</li>
 <li> Authorized Signatory Documents</li>
</ul>

<h6 class="text-">And that's it! Your company license is now ready. Start your business journey with ease.</h6>
  </p>
   
 <h4>  <b>Documentation Required for Corporate Tax Registration</b> </h4>
 <p>For Corporate Tax registration in the UAE, you will need the following documents:</p>
<ul>
  <li> Trade License</li>
  <li> Emirates ID and Passport of Shareholders or Owners</li>
  <li> Memorandum of Association (MOA)</li>
  <li> Audited Financial Statements or Financial Summary</li>
  <li> Valid Email Address and Mobile Number</li>
  <li> Details of Business Activities</li>
  <li> UAE Corporate Bank Account Information</li>
  <li>Tenancy Contract or Address Proof</li>
</ul>
<p>Ensure your financial records are up to date, as the FTA requires accurate profit data for corporate tax assessment.</p>
  <!-- <h4 class="mb-4"><strong>FAQs</strong></h4>
  <div class="accordion" id="accordionExample">
    
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Q1: What is Dubai mainland license?
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Dubai mainland license is a legal authorization issued by the Department of Economic Development (DED) to businesses allowing them to operate legally within the Emirate.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Q2: Do I need a local sponsor for mainland business setup in Dubai?
        </button>
      </h2>
      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Many commercial activities now allow 100% foreign ownership, but some strategic sectors still require a local sponsor.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingThree">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Q3: How long does it take to get the Dubai mainland business license?
        </button>
      </h2>
      <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Typically 3 to 5 business days after document submission and approvals, but it may vary.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingFour">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          Q4: What is a Dubai mainland general trading license?
        </button>
      </h2>
      <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>It's for entrepreneurs wanting to sell multiple products across different or the same industries.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingFive">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
          Q5: What types of companies can be established in Dubai?
        </button>
      </h2>
      <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Free zone, mainland, and offshore companies—each with unique advantages and regulatory requirements.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingSix">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
          Q6: What business activities are eligible under a JAFZA license?
        </button>
      </h2>
      <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Includes trading in metal products like reinforcement steel bars, basic steel products, and metal ores.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingSeven">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
          Q7: Can an expat apply for an e-commerce license in the UAE?
        </button>
      </h2>
      <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Yes, an expat can apply directly for an e-commerce license without needing a prior business license.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingEight">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
          Q8: Can a Dubai resident sell products online with an e-trader license?
        </button>
      </h2>
      <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>No, an e-trader license is for offering professional services or selling goods; an e-commerce license is needed.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingNine">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
          Q9: Is the 2-year golden visa renewable?
        </button>
      </h2>
      <div id="collapseNine" class="accordion-collapse collapse" aria-labelledby="headingNine" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Yes, it is renewable every 2 years under the same category.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTen">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
          Q10: Steps to establish a company in Ajman Free Zone for dental imports?
        </button>
      </h2>
      <div id="collapseTen" class="accordion-collapse collapse" aria-labelledby="headingTen" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Identify shareholders, gather documents, meet visa requirements, and comply with Ajman Free Zone medical trading regulations.</p>
        </div>
      </div>
    </div> -->

  </div>
</div>

</div>
<?php include_once("footer.php") ?>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
