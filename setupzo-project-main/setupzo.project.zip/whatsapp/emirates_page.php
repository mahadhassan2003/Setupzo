<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Emirates ID Services | Setupzo</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
      * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 90vh; /* 80% of viewport height */
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Image covers full area */
      display: block;
    }
    .content-section {
         width: 90%;
      margin: auto;
    }
    .content-section h1{
      text-align:center ;
    } 
    .FAQS h1{
       text-align:center ;
      color: #1E2355;
    }

    .FAQS h5{
      color: black; 
    }
    .FAQS{
       width: 80%;
      margin: auto;
      padding: 20px;
      background-color: #ffffff; 
    }
    .FAQS p{
      padding-left: 20px;
    }
    
  </style>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<?php include_once("navbar.php") ?>
<!-- Image Section -->
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Full Cover Image">
  </div>

<div class="col-lg-10 col-md-10 col-sm-12 mx-auto py-5" style=" background-color:#FBFBFB;">
    <h4><b>EMIRATES ID INFO-UPDATE</b></h4>
  <h6>Complete Guide to Emirates ID Application, Renewal & Updates</h6>
<h4><b> Important: Kindly choose and use one of the following lines</b></h4>
<p>Simplify your Emirates ID process with Setupzo — we handle applications, renewals, and updates so you can enjoy seamless access to UAE services</p>
 <a href="emirates_id_page.php" class="btn btn-primary py-2 my-2" style="background-color: #1e2355;">Apply Online</a>
 <h4><b>Benefits of Emirates ID in the UAE</b></h4>
  <ul class=" mb-5">
    <li class=""><h6 class="fw-bold">Official Identification:</h6> The Emirates ID serves as your primary identification document for all government and private sector transactions in the UAE.</li>
    <li class=""><h6 class="fw-bold">Access to Services:</h6>Essential for accessing healthcare, banking, telecommunications, and all government services across the UAE.</li>
    <li class=""><h6 class="fw-bold">Residency Proof:</h6>Valid proof of your legal residency status in the country, linked to your visa.</li>
    <li class=""><h6 class="fw-bold">Smart Services:</h6>Enables use of UAE's smart government services and digital verification through the UAE Pass app.</li>
    <li class=""><h6 class="fw-bold">Travel Convenience:</h6>Used for expedited immigration processing at UAE airports through smart gates.</li>
    <li class=""><h6 class="fw-bold">Secure Biometric Data:</h6>Contains your fingerprint and facial recognition data for secure identity verification.</li>
    <li class=""><h6 class="fw-bold">Financial Transactions:</h6>Required for opening bank accounts, loan applications, and major financial dealings.</li>
    <li class=""><h6 class="fw-bold">Vehicle Registration:</h6>Mandatory for purchasing vehicles, obtaining driving licenses, and traffic-related services.</li>
  </ul>

<h4><b>Who Needs an Emirates ID?</b></h4>
  <p>The Emirates ID is mandatory for all UAE residents and citizens. Specific requirements include:</p>
  <ul class=" mb-5">
    <li class=""><strong>All UAE citizens</strong> (from birth)</li>
    <li class=""><strong>Resident expatriates</strong> (with valid UAE residence visa)</li>
    <li class=""><strong>GCC nationals</strong> residing in the UAE</li>
    <li class=""><strong>Newborns</strong> (must be registered within 30 days of birth)</li>
    <li class=""><strong>Dependents</strong> of residents and citizens</li>
    <li class=""><strong>Domestic workers</strong> sponsored by residents</li>
  </ul>

</div>
<?php include_once("footer.php") ?>
<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>