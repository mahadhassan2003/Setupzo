<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

// DB connection
$servername = "localhost"; // Hostinger pe usually localhost
$username = "u259563098_setupzo"; // Aapka MySQL user
$password = "Setupzo123"; // Jo password aapne MySQL user banate waqt diya
$dbname = "u259563098_setupzo"; // Aapka database name

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Upload folder
$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// File upload handler
function handleFileUpload($inputName) {
    global $uploadDir;
    if (isset($_FILES[$inputName]) && $_FILES[$inputName]['error'] === UPLOAD_ERR_OK) {
        $tmpPath = $_FILES[$inputName]['tmp_name'];
        $fileName = time() . '_' . basename($_FILES[$inputName]['name']);
        $destination = $uploadDir . $fileName;
        if (move_uploaded_file($tmpPath, $destination)) {
            return $destination;
        }
    }
    return null;
}

// Form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $dialCode = $_POST['dial_code'] ?? '';
    $fullPhone = $dialCode . $phone;
    $company = $_POST['company'] ?? '';

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format'); window.location.href = window.location.pathname;</script>";
        exit;
    }
    
    // Validate phone number format
    if (!preg_match('/^\+?[0-9]{7,15}$/', $fullPhone)) {
        echo "<script>alert('Invalid phone number format. Please enter 7 to 15 digits, optionally starting with +'); window.location.href = window.location.pathname;</script>";
        exit;
    }

    // Check for duplicate email
    $check = $pdo->prepare("SELECT COUNT(*) FROM freelance WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetchColumn() > 0) {
        echo "<script>alert('An application with this email already submitted.Please try Some different Email adress.'); window.location.href = window.location.pathname;</script>";
        exit;
    }

    // Upload files
    $passportPath = handleFileUpload('passport');
    $picturePath = handleFileUpload('picture');
    $emiratesIdPath = handleFileUpload('emirates_id');

    // Insert data into DB
    $stmt = $pdo->prepare("INSERT INTO freelance (name, email, phone, company, passport_path, photo_path, emirates_id_path) 
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $fullname,
        $email,
        $fullPhone,
        $company,
        $passportPath,
        $picturePath,
        $emiratesIdPath
    ]);

    // PHPMailer Config
    $smtpHost = 'smtp.gmail.com';
    $smtpUsername = 'info@setupzo.com';
    $smtpPassword = 'gupy jyfz qydd xzau';
    $fromEmail = 'info@setupzo.com';
    $fromName = 'Setup zo';

    // Send email to user
    try {
        $userMail = new PHPMailer(true);
        $userMail->isSMTP();
        $userMail->Host = $smtpHost;
        $userMail->SMTPAuth = true;
        $userMail->Username = $smtpUsername;
        $userMail->Password = $smtpPassword;
        $userMail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $userMail->Port = 465;

        $userMail->setFrom($fromEmail, $fromName);
        $userMail->addAddress($email, $fullname);
        $userMail->addReplyTo($fromEmail, $fromName);
        $userMail->isHTML(true);
        $userMail->Subject = 'Application Received';
        $userMail->Body = "
            <h3>Dear $fullname,</h3>
            <p>Thank you for your application to <strong>$company</strong> for Freelance Visa Services.</p>
            <p>We have received your details and documents. We will get back to you shortly.</p>
            <p>Best regards,<br>Team Setup zo</p>
        ";
        $userMail->send();
    } catch (Exception $e) {
        echo "<script>alert('Email to applicant failed. Error: " . addslashes($userMail->ErrorInfo) . "');</script>";
    }

    // Send email to admin
    try {
        $adminMail = new PHPMailer(true);
        $adminMail->isSMTP();
        $adminMail->Host = $smtpHost;
        $adminMail->SMTPAuth = true;
        $adminMail->Username = $smtpUsername;
        $adminMail->Password = $smtpPassword;
        $adminMail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $adminMail->Port = 465;

        $adminMail->setFrom($fromEmail, $fromName);
        $adminMail->addAddress('info@setupzo.com', 'Setup zo');
        $adminMail->isHTML(true);
        $adminMail->Subject = 'New Application Received For Freelance Visa';
        $adminMail->Body = "
            <h3>New Application Details</h3>
            <ul>
                <li><strong>Name:</strong> $fullname</li>
                <li><strong>Email:</strong> $email</li>
                <li><strong>Phone:</strong> $fullPhone</li>
                <li><strong>Company:</strong> $company</li>
            </ul>
        ";
        if ($passportPath) $adminMail->addAttachment($passportPath, 'Passport');
        if ($picturePath) $adminMail->addAttachment($picturePath, 'Picture');
        if ($emiratesIdPath) $adminMail->addAttachment($emiratesIdPath, 'Emirates ID');
        $adminMail->send();
    } catch (Exception $e) {
        echo "<script>alert('Email to admin failed. Error: " . addslashes($adminMail->ErrorInfo) . "');</script>";
    }
    
    sleep(2);
    echo "<script>alert('Application Submitted Successfully!'); window.location.href = window.location.pathname;</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin panel</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.8/build/css/intlTelInput.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.css" />
  <style>
    #submitBtn.loading {
      position: relative;
      pointer-events: none;
      opacity: 0.7;
    }

    #submitBtn.loading::after {
      content: "";
      position: absolute;
      top: 50%;
      right: 10px;
      width: 16px;
      height: 16px;
      border: 2px solid #fff;
      border-top-color: transparent;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
      transform: translateY(-50%);
    }

    @keyframes spin {
      to {
        transform: rotate(360deg);
      }
    }
    
    html, body {
      height: 100%;
      background:;
      margin: 0;
      padding: 0;
    }

    .form-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .form-box {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    
    .drop-zone {
      width: 100%;
      height: 100px;
      border: 2px dashed #aaa;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 10px;
      cursor: pointer;
      user-select: none;
      border-radius:15px;
    }
    
    .drop-zone.dragover {
      border-color: #333;
      background-color: #eee;
    }
    
    .file-name {
      font-size: 14px;
      color: #555;
      pointer-events: none;
    }

    .phone-input-container {
      width: 100%;
    }
    
    .iti {
      width: 100% !important;
    }
    
    .iti__selected-flag {
      padding: 0 6px 0 8px;
    }
    
    .iti__flag-container {
      width: 46px;
    }
    
    .iti input {
      width: 100% !important;
      padding-left: 60px !important;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .image-container {
      width: 100%;
      height: 90vh;
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    
    /* Hide the original phone input */
    #phone-input {
      display: none;
    }
  </style>
</head>
<body>
  <?php include_once("navbar.php") ?>
  <div class="image-container">
    <img src="uploads/mainland.jpg" class="img-fluid" alt="Full Cover Image">
  </div>
  
  <div class="col-lg-9 col-md-9 col-sm-10 mx-auto py-5" style=" background-color:#FBFBFB;">
    <h3 class="mb-3 ms-3" style="font-family:times new roman">Apply For Freelance Visa</h3>
    <form class="form-box mx-auto" action="freelance.php" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
      <div class="mb-3">
        <label for="fullname" class="form-label">Full Name as Passport</label>
        <input type="text" class="form-control form-control-lg" name="fullname" id="fullname" placeholder="Please enter you full name as passport" required>
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control form-control-lg" name="email" id="email" placeholder="Enter your valid gmail" required>
      </div>

      <div class="mb-3 phone-input-container">
        <label for="phone" class="form-label">Phone Number</label>
        <input type="tel" class="form-control form-control-lg" id="phone" name="phone" required>
        <input type="hidden" id="dial_code" name="dial_code">
      </div>

      <div class="mb-3">
        <label for="company" class="form-label">Any specific booking</label>
        <input type="text" class="form-control form-control-lg" name="company" id="company" required>
      </div>
      
      <label for="passport">Upload Passport</label>
      <br><br>
      <div class="drop-zone" id="passport-dropzone">
        <span class="file-name">Upload your passport picture</span>
        <input type="file" name="passport" id="passport" hidden accept="image/*,.pdf" required>
      </div>
      
      <label for="picture">Upload Your Personal Picture</label>
      <br><br>
      <div class="drop-zone" id="picture-dropzone">
        <span class="file-name">Upload Your Personal Picture</span>
        <input type="file" name="picture" id="picture" hidden accept="image/*" required>
      </div>
      
      <label for="emirates_id">Upload Emirates ID If have or visit visa</label>
      <br><br>
      <div class="drop-zone" id="emirates-dropzone">
        <span class="file-name">Upload Emirates ID If have or visit visa</span>
        <input type="file" name="emirates_id" id="emirates_id" hidden accept="image/*,.pdf">
      </div>

      <div class="mb-3">
        <button type="submit" class="btn btn-lg w-100" style="background-color: #1e2355;color:white" id="submitBtn">Submit</button>
      </div>
    </form>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"></script>
  <script>
    // Initialize phone input
  const input = document.querySelector("#phone");
  const iti = window.intlTelInput(input, {
    initialCountry: "auto",
    geoIpLookup: function(callback) {
      fetch("https://ipinfo.io?token=b8604525b76188")
        .then(response => response.json())
        .then(data => {
          const countryCode = data.country ? data.country : "US";
          callback(countryCode); // Do not convert to lowercase!
        })
        .catch(() => {
          callback("US");
        });
    },
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"
  });

    // Dropzone functionality
    document.querySelectorAll('.drop-zone').forEach(dropZone => {
      const fileInput = dropZone.querySelector('input[type="file"]');
      const fileNameDisplay = dropZone.querySelector('.file-name');

      dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
      });

      dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
      });

      dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
          fileInput.files = e.dataTransfer.files;
          fileNameDisplay.textContent = e.dataTransfer.files[0].name;
        }
      });

      dropZone.addEventListener('click', () => {
        fileInput.click();
      });

      fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
          fileNameDisplay.textContent = fileInput.files[0].name;
        } else {
          fileNameDisplay.textContent = dropZone.id === 'passport-dropzone' ? 
            'Upload your passport picture' : 
            (dropZone.id === 'picture-dropzone' ? 
              'Upload Your Personal Picture' : 
              'Upload Emirates ID If have or visit visa');
        }
      });
    });

    // Form validation
    function validateForm() {
      const submitBtn = document.getElementById('submitBtn');
      const phoneNumber = phoneInput.value.trim();
      const fullPhoneNumber = dialCodeInput.value + phoneNumber;
      
      // Validate phone number
      if (!/^[0-9]{7,15}$/.test(phoneNumber)) {
        alert('❌ Please enter a valid phone number (7-15 digits)');
        return false;
      }
      
      // Show loading state
      submitBtn.innerHTML = 'Processing...';
      submitBtn.classList.add('loading');
      submitBtn.disabled = true;
      
      return true;
    }
  </script>
  <?php include_once("footer.php") ?>
</body>
</html>