<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Submission Form</title>
      <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }
        
        .heading {
            font-family: 'Playfair Display', serif;
        }
        
        .form-container {
            box-shadow: 0 10px 30px -15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .form-container:hover {
            box-shadow: 0 15px 40px -10px rgba(0,0,0,0.15);
        }
        
        textarea {
            min-height: 150px;
            resize: vertical;
        }
        
        .preview-image {
            max-height: 200px;
            object-fit: cover;
        }
        
        .success-message {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.3s ease;
        }
        
        .success-message.show {
            opacity: 1;
            transform: translateY(0);
        }
        
        .tag {
            transition: all 0.2s ease;
        }
        
        .tag:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
<!-- Navbar -->
<!--<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #1e2355;">-->
<!--  <div class="container">-->
<!--    <a class="navbar-brand" href="#">-->
<!--      <img src="img/ahmer-setupzoo-again.png" alt="Logo" height="10px">-->
<!--    </a>-->
    <!-- Toggler button for mobile -->
<!--    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"-->
<!--            aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">-->
<!--      <span class="navbar-toggler-icon"></span>-->
<!--    </button>-->

    <!-- Navbar links -->
<!--    <div class="collapse navbar-collapse" id="navbarContent">-->
<!--      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">-->
<!--        <li class="nav-item">-->
<!--          <a class="nav-link" href="contact_admin.php">Home</a>-->
<!--        </li>-->

        <!-- Visa Services Dropdown -->
<!--        <li class="nav-item dropdown">-->
<!--          <a class="nav-link dropdown-toggle" href="#" id="visaDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">-->
<!--            Visa Services-->
<!--          </a>-->
<!--          <ul class="dropdown-menu" aria-labelledby="visaDropdown">-->
<!--            <li><a class="dropdown-item" href="mainland_admin.php">Mainland</a></li>-->
<!--            <li><a class="dropdown-item" href="freezone_admin.php">Freezone</a></li>-->
<!--            <li><a class="dropdown-item" href="residence_admin.php">Residence Visa</a></li>-->
<!--            <li><a class="dropdown-item" href="golden_admin.php">Golden Visa</a></li>-->
<!--            <li><a class="dropdown-item" href="freelance_admin.php">Freelance Visa</a></li>-->
<!--            <li><a class="dropdown-item" href="empolyee_admin.php">Employee Visa</a></li>-->
<!--          </ul>-->
<!--        </li>-->

        <!-- Other Services Dropdown -->
<!--        <li class="nav-item dropdown">-->
<!--          <a class="nav-link dropdown-toggle" href="#" id="servicesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">-->
<!--            Other Services-->
<!--          </a>-->
<!--          <ul class="dropdown-menu" aria-labelledby="servicesDropdown">-->
<!--            <li><a class="dropdown-item" href="payroll_admin.php">Payroll</a></li>-->
<!--            <li><a class="dropdown-item" href="vat_admin.php">VAT Corporate</a></li>-->
<!--            <li><a class="dropdown-item" href="compilance_admin.php">Compliance</a></li>-->
<!--            <li><a class="dropdown-item" href="health_admin.php">Health</a></li>-->
<!--            <li><a class="dropdown-item" href="police_admin.php">Police Clearance</a></li>-->
<!--            <li><a class="dropdown-item" href="dm_admin.php">DM Approval</a></li>-->
<!--            <li><a class="dropdown-item" href="emirates_admin.php">Emirates ID Updates</a></li>-->
<!--          </ul>-->
<!--        </li>-->

<!--        <li class="nav-item">-->
<!--          <a class="nav-link" href="contactus_admin.php">Contact Us</a>-->
<!--        </li>-->
<!--        <li class="nav-item">-->
<!--          <a class="nav-link" href="logout.php">Logout</a>-->
<!--        </li>-->
<!--      </ul>-->
<!--    </div>-->
<!--  </div>-->
<!--</nav>-->
<?php include_once("navbar2.php")?>
<!-- Image Section -->
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Full Cover Image">
  </div>
    <div class="max-w-4xl mx-auto">
        <div class="text-center mb-12">
            <h1 class="heading text-4xl font-bold text-gray-900 mb-4">Share Your Story</h1>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto">Write a blog post to inspire our community and share your knowledge with others.</p>
        </div>
        
        <?php
        // Database connection and form handling
      $servername = "localhost"; // Hostinger pe usually localhost
$username = "u259563098_setupzo"; // Aapka MySQL user
$password = "Setupzo123"; // Jo password aapne MySQL user banate waqt diya
$dbname = "u259563098_setupzo"; // Aapka database name

        
        // Initialize variables
        $formErrors = [];
        $successMessage = "";
        $title = $content = $author = $email = $category = "";
        $tags = [];
        
        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Validate and sanitize input
            $title = trim(htmlspecialchars($_POST["title"] ?? ""));
            $content = trim(htmlspecialchars($_POST["content"] ?? ""));
            $author = trim(htmlspecialchars($_POST["author"] ?? ""));
            $email = trim(htmlspecialchars($_POST["email"] ?? ""));
            $category = trim(htmlspecialchars($_POST["category"] ?? ""));
            $tags = isset($_POST["tags"]) ? array_map('trim', array_map('htmlspecialchars', $_POST["tags"])) : [];
            
            // Validate inputs
            if (empty($title)) {
                $formErrors['title'] = "Title is required";
            }
            
            if (empty($content)) {
                $formErrors['content'] = "Content is required";
            }
            
            if (empty($author)) {
                $formErrors['author'] = "Author name is required";
            }
            
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $formErrors['email'] = "Valid email is required";
            }
            
            if (empty($category)) {
                $formErrors['category'] = "Category is required";
            }
            
            // If no errors, proceed with database insertion
            if (empty($formErrors)) {
                try {
                    // Create connection
                    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    
                    // Prepare SQL and bind parameters
                    $stmt = $conn->prepare("INSERT INTO blog_posts (title, content, author, email, category, tags, created_at) 
                                          VALUES (:title, :content, :author, :email, :category, :tags, NOW())");
                    
                    $stmt->bindParam(':title', $title);
                    $stmt->bindParam(':content', $content);
                    $stmt->bindParam(':author', $author);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':category', $category);
                    $stmt->bindParam(':tags', implode(", ", $tags));
                    
                    $stmt->execute();
                    
                    $successMessage = "Your blog post has been submitted successfully!";
                    
                    // Reset form fields
                    $title = $content = $author = $email = $category = "";
                    $tags = [];
                    
                } catch(PDOException $e) {
                    $formErrors['database'] = "Error: " . $e->getMessage();
                }
                
                $conn = null;
            }
        }
        ?>
        
        <div class="form-container bg-white rounded-xl p-8 sm:p-10 shadow-md">
            <?php if (!empty($formErrors['database'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p class="font-bold">Database Error</p>
                    <p><?php echo $formErrors['database']; ?></p>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($successMessage)): ?>
                <div id="success-message" class="success-message show bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p class="font-bold">Success!</p>
                    <p><?php echo $successMessage; ?></p>
                </div>
                
                <script>
                    // Hide success message after 5 seconds
                    setTimeout(() => {
                        const element = document.getElementById('success-message');
                        element.classList.remove('show');
                        setTimeout(() => element.remove(), 300);
                    }, 5000);
                </script>
            <?php endif; ?>
            
            <form id="blogForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="space-y-6">
                    <!-- Title Field -->
                    <div>
                        <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Blog Title <span class="text-red-500">*</span></label>
                        <input type="text" id="title" name="title" value="<?php echo $title; ?>" 
                               class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200 <?php echo !empty($formErrors['title']) ? 'border-red-500' : ''; ?>" 
                               placeholder="Enter your blog title" required>
                        <?php if (!empty($formErrors['title'])): ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo $formErrors['title']; ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Content Field -->
                    <div>
                        <label for="content" class="block text-sm font-medium text-gray-700 mb-1">Content <span class="text-red-500">*</span></label>
                        <textarea id="content" name="content" 
                               class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200 <?php echo !empty($formErrors['content']) ? 'border-red-500' : ''; ?>" 
                               placeholder="Write your blog content here..." required><?php echo $content; ?></textarea>
                        <?php if (!empty($formErrors['content'])): ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo $formErrors['content']; ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Author and Email Fields -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <label for="author" class="block text-sm font-medium text-gray-700 mb-1">Author Name <span class="text-red-500">*</span></label>
                            <input type="text" id="author" name="author" value="<?php echo $author; ?>" 
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200 <?php echo !empty($formErrors['author']) ? 'border-red-500' : ''; ?>" 
                                   placeholder="Your name" required>
                            <?php if (!empty($formErrors['author'])): ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo $formErrors['author']; ?></p>
                            <?php endif; ?>
                        </div>
                        
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email <span class="text-red-500">*</span></label>
                            <input type="email" id="email" name="email" value="<?php echo $email; ?>" 
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200 <?php echo !empty($formErrors['email']) ? 'border-red-500' : ''; ?>" 
                                   placeholder="your@email.com" required>
                            <?php if (!empty($formErrors['email'])): ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo $formErrors['email']; ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Category Select Field -->
<div>
    <label for="category" class="block text-sm font-medium text-gray-700 mb-1">
        Category <span class="text-red-500">*</span>
    </label>
    <input type="text" id="category" name="category" value="<?php echo $category; ?>"
           class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200 <?php echo !empty($formErrors['category']) ? 'border-red-500' : ''; ?>"
           placeholder="Enter a category" required>
    <?php if (!empty($formErrors['category'])): ?>
        <p class="mt-1 text-sm text-red-600"><?php echo $formErrors['category']; ?></p>
    <?php endif; ?>
</div>

                    
                    <!-- Tags Checkbox Field -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tags</label>
                        <div class="mt-2 space-y-2">
                            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                                <div class="flex items-center">
                                    <input id="tag-tutorial" name="tags[]" type="checkbox" value="Tutorial" 
                                           <?php echo in_array('Tutorial', $tags) ? 'checked' : ''; ?> 
                                           class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="tag-tutorial" class="ml-2 text-sm text-gray-700 tag cursor-pointer">Tutorial</label>
                                </div>
                                <div class="flex items-center">
                                    <input id="tag-howto" name="tags[]" type="checkbox" value="How-To" 
                                           <?php echo in_array('How-To', $tags) ? 'checked' : ''; ?> 
                                           class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="tag-howto" class="ml-2 text-sm text-gray-700 tag cursor-pointer">How-To</label>
                                </div>
                                <div class="flex items-center">
                                    <input id="tag-beginners" name="tags[]" type="checkbox" value="Beginners" 
                                           <?php echo in_array('Beginners', $tags) ? 'checked' : ''; ?> 
                                           class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="tag-beginners" class="ml-2 text-sm text-gray-700 tag cursor-pointer">Beginners</label>
                                </div>
                                <div class="flex items-center">
                                    <input id="tag-advanced" name="tags[]" type="checkbox" value="Advanced" 
                                           <?php echo in_array('Advanced', $tags) ? 'checked' : ''; ?> 
                                           class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="tag-advanced" class="ml-2 text-sm text-gray-700 tag cursor-pointer">Advanced</label>
                                </div>
                                <div class="flex items-center">
                                    <input id="tag-tips" name="tags[]" type="checkbox" value="Tips" 
                                           <?php echo in_array('Tips', $tags) ? 'checked' : ''; ?> 
                                           class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="tag-tips" class="ml-2 text-sm text-gray-700 tag cursor-pointer">Tips</label>
                                </div>
                                <div class="flex items-center">
                                    <input id="tag-resources" name="tags[]" type="checkbox" value="Resources" 
                                           <?php echo in_array('Resources', $tags) ? 'checked' : ''; ?> 
                                           class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="tag-resources" class="ml-2 text-sm text-gray-700 tag cursor-pointer">Resources</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Featured Image Upload -->
                    <div>
                        <label for="featured-image" class="block text-sm font-medium text-gray-700 mb-1">Featured Image (Optional)</label>
                        <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                            <div class="space-y-1 text-center">
                                <div class="flex text-sm text-gray-600 justify-center">
                                    <label for="featured-image" class="relative cursor-pointer rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none">
                                        <span>Upload an image</span>
                                        <input id="featured-image" name="featured-image" type="file" class="sr-only" accept="image/*">
                                    </label>
                                </div>
                                <p class="text-xs text-gray-500">PNG, JPG, GIF up to 2MB</p>
                            </div>
                        </div>
                        <div id="image-preview" class="mt-2 hidden">
                            <img src="" alt="Preview of uploaded image" class="preview-image w-full rounded-md" src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/5345a52a-2a74-4dcd-917d-d952f9ac90e5.png">
                        </div>
                    </div>
                    
                    <!-- Submit Button -->
                    <div class="pt-2">
                        <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            Publish Blog Post
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php include_once("footer.php") ?>
    <!-- JavaScript for enhanced interactivity -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script>
        // Image preview functionality
        const imageInput = document.getElementById('featured-image');
        const imagePreview = document.getElementById('image-preview');
        const previewImage = imagePreview.querySelector('img');
        
        if (imageInput) {
            imageInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file && file.type.match('image.*')) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        previewImage.src = e.target.result;
                        imagePreview.classList.remove('hidden');
                    }
                    
                    reader.readAsDataURL(file);
                } else {
                    previewImage.src = '';
                    imagePreview.classList.add('hidden');
                }
            });
        }
        
        // Form submission feedback
        const form = document.getElementById('blogForm');
        if (form) {
            form.addEventListener('submit', function(e) {
                // You can add additional client-side validation here if needed
                const submitButton = form.querySelector('button[type="submit"]');
                if (submitButton) {
                    submitButton.innerHTML = `
                        <svg class="animate-spin -ml-1 mr-2 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
                                            Publish Blog Post
                `;
                }
            });
        }
    </script>
</body>
</html>
