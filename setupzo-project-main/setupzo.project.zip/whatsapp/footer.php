<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Footer</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
  <style>
    .footer{
       background-color:#1e2355; 
    }
  </style>
</head>
<body>

<!-- Footer Start --><!-- Visa Services Footer -->
<footer class="text-light">
  <div class="footer py-4">
    <div class="container mx-auto row">

      <!-- About -->
      <div class="col-md-4">
         <div class="footer-column text-center">
           <img src="img/ahmer-setupzoo-[white-color.png" width="100px" alt="logo" class="mx-auto"> <br><br>
      <p>It is an integrated customer service center to provide exceptional services to real estate investors.</p>
    </div>
      </div>

      <!-- Quick Links -->
      <div class="col-md-4 text-center">
        <h5 class="text-uppercase mb-4">Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="index.php" class="text-light text-decoration-none">Home</a></li><br>
          <li><a href="services.php" class="text-light text-decoration-none">Our Services</a></li><br>
          <li><a href="about-us.php" class="text-light text-decoration-none">About Us</a></li><br>
          <li><a href="contact-us.php" class="text-light text-decoration-none">Contact Us</a></li><br>
          <!-- <li><a href="faq.php" class="text-light text-decoration-none">FAQ</a></li> -->
        </ul>
      </div>

      <!-- Contact -->
      <div class="col-md-4 text-center">
        <h5 class="text-uppercase mb-4">Contact Us</h5>
        <!-- <p><i class="fas fa-map-marker-alt me-2"></i></p> -->
        <p><a href="tel:+971568677227" class="text-decoration-none text-white"><i class="fas fa-phone me-2 mx-2"></i>+971 56 867 7227</a></p>
        <p><a href="mailto:info@setupzo.com" class="text-decoration-none text-white"><i class="fas fa-envelope me-2 mx-2"></i>info@setupzo.com</a></p>
        <p style="font-size:20px;" class="text-white ms-1"><i class="fa-brands fa-instagram mx-4"></i>
      <i class="fa-brands fa-square-facebook mx-4"></i>
    <i class="fa-brands fa-linkedin-in mx-4"></i></p>


        <!-- <div class="mt-3">
          <a href="#" class="text-light me-3"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-linkedin-in"></i></a>
        </div> -->
      </div>

    </div>
  </div>
</footer>
 
<!-- Bootstrap & Font Awesome -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

</body>
</html>
