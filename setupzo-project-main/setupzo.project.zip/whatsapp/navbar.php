 



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Setup Zo | Navbar Only</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" crossorigin="anonymous" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playball&display=swap" rel="stylesheet">
    <!-- ✅ Favicon Logo -->
  <link rel="icon" type="image/png" href="img/ahmer-setupzoo-again.png" />
      <link rel="icon" href="img/ahmer-setupzoo-again.png" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/ahmer-setupzoo-again.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/ahmer-setupzoo-again.png">
  <link rel="apple-touch-icon" sizes="180x180" href="img/ahmer-setupzoo-again.png">
  <link rel="manifest" href="img/ahmer-setupzoo-again.png">
  <style>
    .navbar {
      background: rgba(255, 255, 255, 0.3);
     
      box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
      backdrop-filter: blur(5.2px);
      -webkit-backdrop-filter: blur(5.2px);
    }

    .nav-link {
      color: #1e2355 !important;
      font-weight: bold !important;
    }

    .mega-dropdown {
      width: 100vw;
      left: 0;
      top: 100%;
      position: absolute;
      background: #fff;
      padding: 30px;
      display: none;
      z-index: 9999;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      animation: fadeInDown 0.3s ease-in-out;
    }

    .mega-dropdown .dropdown-item {
      font-weight: 500;
      color: #1e2355;
      transition: 0.3s;
      white-space: nowrap;
    }

    .mega-dropdown .dropdown-item:hover {
      background-color: #1e2355;
      color: white;
      padding-left: 10px;
    }

    .mega-dropdown h6 {
      margin-bottom: 12px;
      font-size: 14px;
      color: #1e2355;
      border-bottom: 1px solid #eee;
      padding-bottom: 6px;
    }

    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0px);
      }
    }

    @media (max-width: 991px) {
      .mega-dropdown {
        display: none !important;
        overflow-x: auto !important;
        white-space: nowrap !important;
        padding: 15px;
      }

      .mega-dropdown.show {
        display: block !important;
      }

      .mega-dropdown .row {
        display: flex !important;
        flex-wrap: nowrap !important;
      }

      .mega-dropdown .col-md-2 {
        flex: 0 0 auto !important;
        width: 250px !important;
        display: inline-block;
        white-space: normal;
        margin-right: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <img src="img/ahmer-setupzoo-again.png" width="100" alt="Setupzo">
    </a>
    <button class="navbar-toggler me-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <i class="fa-solid fa-bars" style="color: #1e2355; font-size: 30px;"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item px-2">
          <a class="nav-link" href=".">Home</a>
        </li>
        <li class="nav-item px-2">
          <a class="nav-link" href="about-us.php">About Us</a>
        </li>
        <li class="nav-item dropdown px-2 position-static">
          <a class="nav-link dropdown-toggle" href="services.php" id="servicesDropdown">Services</a>
          <button class="btn btn-sm btn-outline-primary d-lg-none my-2" id="toggleMegaMenu">
            Show Services
          </button>

          <div class="dropdown-menu mega-dropdown" id="megaMenu">
            <div class="row">
              <div class="col-md-2">
                <h6>Company Formation</h6>
                <a class="dropdown-item" href="mainland-business-setup-in-dubai.php">Mainland</a>
                <a class="dropdown-item" href="business-setup-in-dubai-freezone.php">Free Zone</a>
              </div>
              <div class="col-md-2">
                <h6>Visa & Immigration</h6>
                <a class="dropdown-item" href="uae-residence-visa.php">Residence Visa</a>
                <a class="dropdown-item" href="uae-golden-visa.php">Golden Visa</a>
                <a class="dropdown-item" href="services-freelance-visa-uae-dubai.php">Freelance Visa</a>
                <a class="dropdown-item" href="bank_account_open.php">Bank Account Opening</a>
              </div>
              <div class="col-md-2">
                <h6>Financial Services</h6>
                <a class="dropdown-item" href="payroll_page.php">Payroll</a>
                <a class="dropdown-item" href="vat_service.php">Corporate Tax & VAT</a>
                <a class="dropdown-item" href="compilance.php">Compliance</a>
              </div>
              <div class="col-md-2">
                <h6>Legal Services</h6>
                <a class="dropdown-item" href="pro-services-dubai.php">PRO Services</a>
                <a class="dropdown-item" href="will-preparation-uae.php">Will Preparation</a>
                <a class="dropdown-item" href="trademark-vs-copyright-uae.php">Trademark & Copyright</a>
              </div>
              <div class="col-md-2">
                <h6>Additional Services</h6>
                <a class="dropdown-item" href="health_insurance.php">Health Insurance</a>
                <a class="dropdown-item" href="police_clearance.php">Police Clearance</a>
                <a class="dropdown-item" href="dm_page.php">DM Approval</a>
                <a class="dropdown-item" href="emirates_page.php">Emirates ID Update</a>
              </div>
              <div class="col-md-2">
                <h6>Nominee Services</h6>
                <a class="dropdown-item" href="contact-us.php">Shareholder</a>
                <a class="dropdown-item" href="contact-us.php">Manager</a>
              </div>
            </div>
          </div>
        </li>
        <li class="nav-item px-2">
          <a class="nav-link" href="#">Blog</a>
        </li>
        <li class="nav-item px-2">
          <a class="nav-link" href="contact-us.php">Contact Us</a>
        </li>
      </ul>
      <a href="contact-us.php" class="btn text-white py-2 px-3 ms-lg-4" style="background-color: #1e2355;">Apply Now</a>
    </div>
  </div>
</nav>
<!-- Navbar End -->

<!-- Scripts -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const dropdown = document.querySelector('.nav-item.dropdown');
    const megaMenu = document.getElementById('megaMenu');
    const toggleButton = document.getElementById('toggleMegaMenu');

    // Toggle mega menu on mobile
    if (window.innerWidth < 992 && toggleButton && megaMenu) {
      toggleButton.addEventListener('click', function (e) {
        e.preventDefault();
        megaMenu.classList.toggle('show');
        toggleButton.textContent = megaMenu.classList.contains('show') ? 'Hide Services' : 'Show Services';
      });
    }

    // Hover effect for desktop
    if (window.innerWidth >= 992 && dropdown && megaMenu) {
      let timer;
      dropdown.addEventListener('mouseenter', () => {
        clearTimeout(timer);
        megaMenu.style.display = 'block';
      });
      dropdown.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });
      megaMenu.addEventListener('mouseenter', () => {
        clearTimeout(timer);
      });
      megaMenu.addEventListener('mouseleave', () => {
        timer = setTimeout(() => {
          megaMenu.style.display = 'none';
        }, 200);
      });
    }
  });
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

</body>
</html>
