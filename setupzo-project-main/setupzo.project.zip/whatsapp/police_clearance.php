 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Responsive Layout with Navbar, Image & Content</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 90vh; /* 80% of viewport height */
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Image covers full area */
      display: block;
    }
    .content-section {
      width: 90%;
      margin: auto;
      background-color: #ffffff; 
    }
    .content-section h1{
      text-align:center ;
    } 
    .FAQS h1{
       text-align:center ;
      color: #1E2355;
    }

    .FAQS h5{
      color: black; 
    }
    .FAQS{
       width: 80%;
      margin: auto;
      padding: 20px;
      background-color: #ffffff; 
    }
    .FAQS p{
      padding-left: 20px;
    }
    h2{
        font-display: bold;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<!-- Image Section -->
 <?php include_once("navbar.php") ?>
<div class="image-container">
    <img src="uploads/mainland.jpg" class="img-fluid" alt="Full Cover Image">
  </div>



<!-- Content Section -->
<div class="content-section col-lg-10 col-md-10 col-sm-12 pt-5" style=" background-color:#FBFBFB;">
    <h4><b>Police Clearance Certificate</b></h4>
   <h6><b>Complete Process for Getting a Police Clearance Certificate in UAE</b>
 </h6>

  <p>Setupzo is here to help you easily navigate the police clearance process in Dubai, making sure everything is done right without any stress.</p><br>
  <a href="police.php" class="btn btn-primary py-2 my-4 mt-5" style="background-color: #1e2355;">Apply Online</a>
  <h4><b>What is a police clearance certificate Dubai:</b></h4>
  <p>A Police Clearance Certificate Dubai, also known as a Good Conduct Certificate, is an official document issued by the Dubai Police that confirms an individual’s clear criminal record within the UAE. This certificate verifies that the person has never been involved in any criminal activities or legal violations during their stay in Dubai, whether as a resident, worker, or citizen. It serves as proof of good conduct and integrity, showing that the individual has maintained a clean record from both a security and legal standpoint. The Police Clearance Certificate is often required for various purposes such as job applications, visa processing, immigration, and residency permits in the UAE and abroad. Obtaining this certificate assures authorities and employers of the person’s trustworthy background and law-abiding history during their time in the Emirates.</p>
  <h4><b>Importance of police clearance certificate </b></h4>
  <p>A Police Clearance Certificate is an important document that verifies your integrity and compliance with the law. Whether in the UAE or abroad, embassies, government authorities, educational institutions, licensing bodies and employers often require this certificate to confirm that your criminal record is clear. This certificate is essential for various processes such as job applications, visa processing, license approvals, and admissions. Having a Police Clearance Certificate demonstrates that you are a trustworthy individual with a clean legal background.</p>
  <h4><b>When Is a Police Clearance Certificate Needed in Dubai</b></h4>
  <p>You may be required to provide a Police Clearance Certificate from Dubai Police in several official and personal situations. Here are the most common scenarios where this document becomes essential:</p>
  <ul>
   <li> <h6 class="fw-bold">Job Applications</h6>1.Employers in Dubai and overseas often request a Good Conduct Certificate to ensure the applicant has no criminal record. It helps them assess the candidate’s integrity and suitability for the role. For many companies, it is a crucial part of the background screening process.</li>
    <li><h6 class="fw-bold">University or College Admissions</h6>2.Some educational institutions require a Police Clearance Certificate from students, especially when applying to programs related to law, public safety or government services. It serves as proof of good behaviour and legal compliance.</li>    
    <li><h6 class="fw-bold">Visa and Immigration Processes</h6>3.When applying for residency visas, work permits, or immigration clearance, many countries including the UAE demand a PCC from Dubai Police to verify the applicant has maintained a clean legal record. This step is vital for national security and public safety.</li>
    <li><h6 class="fw-bold">Professional Licensing</h6>4.Authorities issuing licenses for regulated professions may require a police clearance as part of the license approval process. It ensures that the individual meets ethical and legal standards.</li>
    <li><h6 class="fw-bold">Business Setup in the UAE</h6>5.If you are setting up a business in Dubai, government departments may request police clearance certificates from company owners or senior partners, depending on the type of business and its activities.</li>
    <li><h6 class="fw-bold">Banking and Financial Services</h6>6.While not always mandatory, certain banking institutions especially for corporate accounts may request a Good Conduct Certificate to verify the background of the account holder for security and compliance reasons.</li>
  </ul>

<h4><b> Documents Required for Police Clearance Certificate in Dubai</b></h4>
 <p>To apply for a Police Clearance Certificate (PCC) from Dubai Police, you need to submit a few essential documents. These help verify your identity and legal background. Here is the list of required documents:</p>
 <h6 class="fw-bold">For UAE Residents:</h6>
 <ul>
<li> Valid Emirates ID</li>
 <li>Recent passport-sized photograph</li>
<li> Copy of passport </li>
<li> UAE visa (if applicable)</li>
 </ul>
<h6 class="fw-bold">For Non-Residents:</h6>
 <ul>
 <li>Fingerprint form from your current country, attested by the UAE Embassy </li>
<li> Copy of your passport</li>
<li> Two recent passport-sized photographs </li>
 <li>Copy of your last UAE visa (if applicable) </li>
 <li>Clearly stated reason for the application </li>
</ul>

<p>At Setupzo, our legal experts are ready to assist you with the complete documentation and application process. We ensure smooth, error-free submission and professional guidance every step of the way.</p>
	
  <h2 class="mb-4 fw-bold"><strong>Frequently Asked Questions (FAQs)</strong></h2>
  <div class="accordion mb-5" id="accordionExample">
    
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Q1: What is a Police Clearance Certificate UAE?
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>A Police Clearance Certificate (PCC), also known as a Good Conduct Certificate, is an official document that confirms you have a clear criminal record and have never been involved in any legal issues in the UAE or any other country.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Q2:  Why is a Police Clearance Certificate UAE important?
        </button>
      </h2>
      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>This certificate is required for various purposes such as job applications, visa processing, business setup, and educational admissions to verify your integrity and clean background.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingThree">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Q3:  How can I obtain a Police Clearance Certificate UAE?
        </button>
      </h2>
      <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>You can apply online through the Ministry of Interior (MOI) or Dubai Police websites/apps, or apply offline at Dubai Police stations and smart service centers.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingFour">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          Q4:  What documents are needed for a Police Clearance Certificate UAE?
        </button>
      </h2>
      <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Generally, you will need a valid passport copy, UAE visa (if applicable), Emirates ID, recent passport-sized photos, and a completed application form. Non-residents may also need to provide a fingerprint form attested by the UAE embassy.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingFive">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
          Q5:  How much is the fee for Police Clearance Certificate Dubai?
        </button>
      </h2>
      <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>The standard fee is AED 50 when applying via the Ministry of Interior, but this may vary slightly based on the language of the certificate and your nationality.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingSix">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
          Q6:  How long does it take to get a Police Clearance Certificate UAE?
        </button>
      </h2>
      <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Online applications typically take 2-3 working days for approval. Offline applications may take a bit longer.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingSeven">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
          Q7:  Can I apply for a Police Clearance Certificate UAE if I am no longer residing in the UAE?
        </button>
      </h2>
      <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Yes, former residents and citizens can apply online or through UAE embassies abroad.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingEight">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
          Q8: How can I track my Police Clearance Certificate UAE application?
        </button>
      </h2>
      <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>You can track your application status online using the reference number on the Ministry of Interior or Dubai Police official websites.</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingNine">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
          Q9:  Is the Police Clearance Certificate UAE available in languages other than Arabic?
        </button>
      </h2>
      <div id="collapseNine" class="accordion-collapse collapse" aria-labelledby="headingNine" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Yes, the certificate is available in both English and Arabic. You can select your preferred language during the application process..</p>
        </div>
      </div>
    </div>

    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTen">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
          Q10: How can Setupzo assist me with the Police Clearance Certificate UAE process?
        </button>
      </h2>
      <div id="collapseTen" class="accordion-collapse collapse" aria-labelledby="headingTen" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <p>Setupzo provides complete support including document preparation, certified translation, and step-by-step guidance to ensure your application is processed smoothly and efficiently.</p>
        </div>
      </div>
    </div>

  </div>
</div>

</div>
<?php include_once("footer.php") ?>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
