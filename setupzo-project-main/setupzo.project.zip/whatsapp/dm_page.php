<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DM Approval Services | Setupzo</title>
   <link rel="icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
  <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
  <link rel="manifest" href="img/site.webmanifest">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
      * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      height: 100%;
    }

    .image-container {
      width: 100%;
      height: 90vh; /* 80% of viewport height */
      overflow: hidden;
    }

    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Image covers full area */
      display: block;
    }
    .content-section {
         width: 90%;
      margin: auto;
    }
    .content-section h1{
      text-align:center ;
    } 
    .FAQS h1{
       text-align:center ;
      color: #1E2355;
    }

    .FAQS h5{
      color: black; 
    }
    .FAQS{
       width: 80%;
      margin: auto;
      padding: 20px;
      background-color: #ffffff; 
    }
    .FAQS p{
      padding-left: 20px;
    }
    
  </style>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<?php include_once("navbar.php") ?>
<!-- Image Section -->
 <div class="image-container">
    <img src="uploads/mainland.jpg" alt="Full Cover Image">
  </div>

<div class="col-lg-10 col-md-10 col-sm-12 mx-auto py-5" style=" background-color:#FBFBFB;">
    <h4><b>Dubai Municipality Company 
Registration Made Easy</b></h4>
  <p>Trust Setupzo to get your business registered quickly and correctly, so you can focus on growing your dream.</p>
  <h4><b>Dubai Municipality Approval </b></h4>
  <p>Obtaining Dubai Municipality Approval is essential for any construction, renovation, or interior fit-out project in Dubai. This approval ensures that all plans meet Dubai’s strict building codes, safety regulations, and environmental guidelines. Without proper DM approval, projects risk legal penalties, delays, and even shutdowns. By working with a qualified architect or engineering consultant, businesses and property owners can navigate the approval process smoothly, from design submission to site inspection and final certification. Dubai Municipality Approval not only safeguards project quality but also boosts property value, enhances safety, and secures mandatory permits, making it a critical step for successful project completion.<br>
  </p>
  <a href="dm_approval_page.php" class="btn btn-primary py-2 my-2" style="background-color: #1e2355;">Apply Online</a><br><br>
  <h4><b>List of activities that need Dubai Municipality approval</b></h4>
<h6><strong>Here are the activities that need Dubai Municipality approval:</strong></h6>
<p>Navigate Dubai Municipality approvals with ease through Setupzo — we simplify the complex approval process for your construction, business, and development projects</p>
  <ul class=" mb-5">
    <li>Expanding or renovating a building.</li>
    <li>Running a medical clinic.</li>
    <li>Importing or exporting food products.</li>
    <li>Manufacturing or selling goods</li>
    <li>Operating a nightclub or entertainment venue.</li>
    <li>Organizing events.</li>
    <li>Transporting waste</li>
    <li>Storing dangerous goods</li>
    <li>Running Retail Store</li>
    <li>Operating a food or beverage establishment.</li>
    <li>Starting a construction project</li>
    <li>Getting a trade license.</li>
  </ul>

  <h4><b>Register Admin and Business Accounts on Dubai Municipality</b></h4>
  <p>Registering your Admin and Business user accounts on the Dubai Municipality portal is essential for accessing various municipal services and managing your company’s compliance smoothly. Follow these simple yet important steps to complete your registration successfully:</p>
  <h4><b>Registering an Admin Account</b></h4>

  <ul class=" mb-5">
    <li class=""><strong>Create an Admin Account</strong><br>Log in to the official Dubai Municipality portal and start by creating your company’s Admin account.</li>
    <li class=""><strong>Complete Company and Admin Details</strong><br>Fill in all required company information including license number, issuing authority, company address, license members, and importer code. Also, provide detailed admin user information such as personal details, identity proof, contact details, and verify your phone number and email address. Attach all necessary documents and accept the portal’s terms and conditions.</li>
    <li class=""><strong>Receive Registration Confirmation</strong><br>Once your details are submitted and verified, you will get a registration confirmation notice along with a reference number.</li>
    <li class=""><strong>Await Dubai Municipality Approval</strong><br>The Dubai Municipality team will review your application and verify all submitted details. After approval, you will receive an email with further instructions on how to proceed.</li>
    <li class=""><strong>Set Your Password</strong><br>Follow the instructions sent via email to set a secure password for your Admin account. You will receive a confirmation notification once your password is set.</li>
    <li class=""><strong>Log In to Your Admin Account</strong><br>Use your new credentials to log in to the Dubai Municipality portal and access administrative features and services.</li>
  </ul>
</div>
<?php include_once("footer.php") ?>
<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>